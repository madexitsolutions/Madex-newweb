<?php
/**
 * Branded e-mails sent by the plugin.
 *
 * Every mail goes out as HTML with a plain-text alternative and the sender
 * set in Einstellungen → Allgemein. The sender applies to these mails only,
 * never to other mails of the site.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Mailer {

    const BRAND = '#028D86';

    /** @var string Plain-text body for the current mail. */
    private static $alt_body = '';

    /**
     * @param string|string[] $to
     * @param string          $subject
     * @param array           $mail {
     *     @type string   $heading Title in the mail.
     *     @type string   $intro   Paragraph under the title.
     *     @type array    $rows    Label => value pairs for the details table.
     *     @type string   $note_title Optional heading of a free-text block.
     *     @type string   $note    Optional free text (e.g. the customer's message).
     *     @type string   $button_label Optional button label.
     *     @type string   $button_url   Optional button URL.
     *     @type string   $footer  Optional footer line.
     * }
     * @param string[]        $headers Extra headers (e.g. Reply-To).
     * @return bool
     */
    public static function send($to, $subject, $mail, $headers = array()) {
        $subject = preg_replace('/[\r\n]+/', ' ', (string) $subject);
        $headers = array_merge(array('Content-Type: text/html; charset=UTF-8', 'From: ' . self::from_header()), (array) $headers);

        self::$alt_body = self::text($mail);
        add_action('phpmailer_init', array(__CLASS__, 'add_alt_body'));
        $sent = wp_mail($to, $subject, self::html($subject, $mail), $headers);
        remove_action('phpmailer_init', array(__CLASS__, 'add_alt_body'));
        self::$alt_body = '';

        return (bool) $sent;
    }

    public static function add_alt_body($phpmailer) {
        if (self::$alt_body !== '') {
            $phpmailer->AltBody = self::$alt_body;
        }
    }

    /**
     * "Name <address>" from the settings, falling back to info@madex-it.ch.
     */
    public static function from_header() {
        $branding = get_option('madex_chatbot_branding', array());
        $name = !empty($branding['mail_from_name']) ? $branding['mail_from_name'] : 'Madex IT Solutions';
        $email = !empty($branding['mail_from_email']) && is_email($branding['mail_from_email']) ? $branding['mail_from_email'] : 'info@madex-it.ch';
        $name = trim(preg_replace('/[\r\n<>",]+/', '', $name));
        return $name . ' <' . $email . '>';
    }

    private static function text($mail) {
        $lines = array();
        if (!empty($mail['heading'])) {
            $lines[] = $mail['heading'];
            $lines[] = str_repeat('=', min(60, mb_strlen($mail['heading'])));
            $lines[] = '';
        }
        if (!empty($mail['intro'])) {
            $lines[] = $mail['intro'];
            $lines[] = '';
        }
        foreach ((array) ($mail['rows'] ?? array()) as $label => $value) {
            $lines[] = $label . ': ' . ($value === '' ? '–' : $value);
        }
        if (!empty($mail['note'])) {
            $lines[] = '';
            $lines[] = ($mail['note_title'] ?? '') . ':';
            $lines[] = $mail['note'];
        }
        if (!empty($mail['button_url'])) {
            $lines[] = '';
            $lines[] = ($mail['button_label'] ?? '') . ': ' . $mail['button_url'];
        }
        if (!empty($mail['footer'])) {
            $lines[] = '';
            $lines[] = '-- ';
            $lines[] = $mail['footer'];
        }
        return implode("\n", $lines);
    }

    private static function html($subject, $mail) {
        $brand = self::BRAND;
        $font = "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";

        $rows = '';
        foreach ((array) ($mail['rows'] ?? array()) as $label => $value) {
            $value = (string) $value;
            if ($value === '') {
                $display = '–';
            } elseif (is_email($value)) {
                $display = '<a href="mailto:' . esc_attr($value) . '" style="color:' . $brand . ';text-decoration:none;">' . esc_html($value) . '</a>';
            } elseif (preg_match('/^\+?[0-9 ()\/.-]{6,}$/', $value)) {
                $display = '<a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $value)) . '" style="color:' . $brand . ';text-decoration:none;">' . esc_html($value) . '</a>';
            } else {
                $display = esc_html($value);
            }
            $rows .= '<tr>'
                . '<td style="padding:10px 0;border-bottom:1px solid #edf0f0;color:#5e6b73;font-size:14px;width:150px;vertical-align:top;">' . esc_html($label) . '</td>'
                . '<td style="padding:10px 0;border-bottom:1px solid #edf0f0;color:#36454f;font-size:14px;font-weight:600;vertical-align:top;">' . $display . '</td>'
                . '</tr>';
        }

        $note = '';
        if (!empty($mail['note'])) {
            $note = '<p style="margin:24px 0 8px;color:#5e6b73;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;">' . esc_html($mail['note_title'] ?? '') . '</p>'
                . '<div style="padding:14px 16px;border-radius:8px;background:#f4f8f8;color:#36454f;font-size:14px;line-height:1.6;">' . nl2br(esc_html($mail['note'])) . '</div>';
        }

        $button = '';
        if (!empty($mail['button_url'])) {
            $button = '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:28px 0 4px;"><tr><td style="border-radius:8px;background:' . $brand . ';">'
                . '<a href="' . esc_url($mail['button_url']) . '" style="display:inline-block;padding:13px 24px;color:#ffffff;font-size:15px;font-weight:700;text-decoration:none;border-radius:8px;">' . esc_html($mail['button_label'] ?? '') . '</a>'
                . '</td></tr></table>';
        }

        $footer = !empty($mail['footer']) ? esc_html($mail['footer']) : 'Madex IT Solutions · Buchenstrasse 36 · 8212 Neuhausen am Rheinfall';

        return '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . esc_html($subject) . '</title></head>'
            . '<body style="margin:0;padding:0;background:#f2f4f4;font-family:' . $font . ';">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f2f4f4;"><tr><td align="center" style="padding:32px 16px;">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e3e7e7;">'
            . '<tr><td style="background:' . $brand . ';padding:20px 32px;color:#ffffff;font-size:16px;font-weight:700;letter-spacing:.01em;">Madex IT Solutions</td></tr>'
            . '<tr><td style="padding:32px;font-family:' . $font . ';">'
            . (!empty($mail['heading']) ? '<h1 style="margin:0 0 10px;color:#36454f;font-size:22px;line-height:1.3;">' . esc_html($mail['heading']) . '</h1>' : '')
            . (!empty($mail['intro']) ? '<p style="margin:0 0 20px;color:#4a5862;font-size:15px;line-height:1.6;">' . esc_html($mail['intro']) . '</p>' : '')
            . ($rows !== '' ? '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-top:1px solid #edf0f0;">' . $rows . '</table>' : '')
            . $note
            . $button
            . '</td></tr>'
            . '<tr><td style="padding:18px 32px;background:#fafbfb;border-top:1px solid #edf0f0;color:#8a959b;font-size:12px;line-height:1.5;">' . $footer . '</td></tr>'
            . '</table></td></tr></table></body></html>';
    }
}
