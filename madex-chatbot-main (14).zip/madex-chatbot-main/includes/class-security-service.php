<?php
/**
 * Security Service Class
 * 
 * Handles rate limiting, spam prevention, and security measures
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Security_Service {
    
    /**
     * Transient prefix for rate limiting
     */
    const RATE_LIMIT_PREFIX = 'madex_rate_';
    
    /**
     * Get client IP address
     */
    public static function get_client_ip() {
        $ip = '';

        // Forwarding headers are client-controlled and would let anyone bypass
        // rate limits and IP blocks. Only REMOTE_ADDR is trusted unless the
        // site owner explicitly opts in (e.g. behind Cloudflare) via filter.
        $headers = array('REMOTE_ADDR');
        if (apply_filters('madex_chatbot_trust_proxy_headers', false)) {
            array_unshift($headers, 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR');
        }

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                // Handle comma-separated IPs (X-Forwarded-For)
                if (strpos($ip, ',') !== false) {
                    $ips = explode(',', $ip);
                    $ip = trim($ips[0]);
                }
                break;
            }
        }
        
        // Validate IP
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
        
        return '0.0.0.0';
    }
    
    /**
     * Generate a unique identifier for the current user/visitor
     */
    public static function get_user_identifier() {
        $user_id = get_current_user_id();
        
        if ($user_id > 0) {
            return 'user_' . $user_id;
        }
        
        // For guests, key on the IP only: including the user agent would let a
        // client reset its limits by rotating the header.
        return 'guest_' . md5(wp_salt('nonce') . self::get_client_ip());
    }
    
    /**
     * Check if request is rate limited
     * 
     * @param string $action Action being rate-limited
     * @param int $max_requests Maximum requests allowed
     * @param int $time_window Time window in seconds
     * @return array ['allowed' => bool, 'remaining' => int, 'reset_in' => int]
     */
    public static function check_rate_limit($action, $max_requests = 10, $time_window = 60) {
        $identifier = self::get_user_identifier();
        $transient_key = self::RATE_LIMIT_PREFIX . $action . '_' . $identifier;
        
        $data = get_transient($transient_key);
        
        if ($data === false) {
            // First request - initialize counter
            $data = array(
                'count' => 1,
                'started' => time()
            );
            set_transient($transient_key, $data, $time_window);
            
            return array(
                'allowed' => true,
                'remaining' => $max_requests - 1,
                'reset_in' => $time_window
            );
        }
        
        $elapsed = time() - $data['started'];
        $remaining_time = $time_window - $elapsed;
        
        if ($remaining_time <= 0) {
            // Window expired, reset
            $data = array(
                'count' => 1,
                'started' => time()
            );
            set_transient($transient_key, $data, $time_window);
            
            return array(
                'allowed' => true,
                'remaining' => $max_requests - 1,
                'reset_in' => $time_window
            );
        }
        
        // Within window
        if ($data['count'] >= $max_requests) {
            return array(
                'allowed' => false,
                'remaining' => 0,
                'reset_in' => $remaining_time
            );
        }
        
        // Increment counter
        $data['count']++;
        set_transient($transient_key, $data, $remaining_time);
        
        return array(
            'allowed' => true,
            'remaining' => $max_requests - $data['count'],
            'reset_in' => $remaining_time
        );
    }
    
    /**
     * Check message rate limit (messages per minute)
     */
    public static function check_message_rate_limit() {
        $security_settings = get_option('madex_chatbot_security', array());
        
        $max_per_minute = isset($security_settings['rate_limit_per_minute']) 
            ? intval($security_settings['rate_limit_per_minute']) 
            : 5;
        
        return self::check_rate_limit('message', $max_per_minute, 60);
    }
    
    /**
     * Check session rate limit (new sessions per hour)
     * @deprecated Session rate limiting disabled - use message rate limiting instead
     */
    public static function check_session_rate_limit() {
        // Session rate limiting disabled - always allow new sessions
        // Rate limiting is enforced per-message (per minute and per day limits)
        return array('allowed' => true, 'remaining' => 999, 'reset_in' => 0);
    }
    
    /**
     * Check daily message limit
     * Guests: 100 messages per day (default)
     * Logged-in users: Unlimited (0 = no limit)
     */
    public static function check_daily_limit() {
        $security_settings = get_option('madex_chatbot_security', array());
        
        // Logged-in users have unlimited messages
        if (is_user_logged_in()) {
            return array('allowed' => true, 'remaining' => 999, 'reset_in' => 0);
        }
        
        // Guest daily limit (default 100)
        $max_per_day = isset($security_settings['guest_messages_per_day']) 
            ? intval($security_settings['guest_messages_per_day']) 
            : 100;
        
        // Check if daily limit is disabled (0 = unlimited)
        if ($max_per_day === 0) {
            return array('allowed' => true, 'remaining' => 999, 'reset_in' => 0);
        }
        
        return self::check_rate_limit('daily', $max_per_day, 86400);
    }
    
    /**
     * Check cooldown between messages
     */
    public static function check_message_cooldown() {
        $security_settings = get_option('madex_chatbot_security', array());
        
        $cooldown_seconds = isset($security_settings['message_cooldown']) 
            ? intval($security_settings['message_cooldown']) 
            : 2;
        
        if ($cooldown_seconds <= 0) {
            return array('allowed' => true, 'wait' => 0);
        }
        
        $identifier = self::get_user_identifier();
        $transient_key = self::RATE_LIMIT_PREFIX . 'cooldown_' . $identifier;
        
        $last_message_time = get_transient($transient_key);
        
        if ($last_message_time !== false) {
            $elapsed = time() - $last_message_time;
            if ($elapsed < $cooldown_seconds) {
                return array(
                    'allowed' => false,
                    'wait' => $cooldown_seconds - $elapsed
                );
            }
        }
        
        // Set the cooldown
        set_transient($transient_key, time(), $cooldown_seconds);
        
        return array('allowed' => true, 'wait' => 0);
    }
    
    /**
     * Validate message content
     */
    public static function validate_message($message) {
        $errors = array();
        $security_settings = get_option('madex_chatbot_security', array());
        
        // Check minimum length
        $min_length = isset($security_settings['min_message_length']) 
            ? intval($security_settings['min_message_length']) 
            : 1;
        
        if (strlen(trim($message)) < $min_length) {
            $errors[] = __('Die Nachricht ist zu kurz.', 'madex-chatbot');
        }
        
        // Check maximum length
        $max_length = isset($security_settings['max_message_length']) 
            ? intval($security_settings['max_message_length']) 
            : 1000;
        
        if (strlen($message) > $max_length) {
            $errors[] = sprintf(__('Die Nachricht ist zu lang (maximal %d Zeichen).', 'madex-chatbot'), $max_length);
        }
        
        // Check for spam patterns
        if (self::is_spam_message($message)) {
            $errors[] = __('Die Nachricht wurde als Spam erkannt.', 'madex-chatbot');
        }
        
        // Check for excessive repetition
        if (self::has_excessive_repetition($message)) {
            $errors[] = __('Die Nachricht enthält zu viele Wiederholungen.', 'madex-chatbot');
        }
        
        return $errors;
    }
    
    /**
     * Check if message looks like spam
     */
    private static function is_spam_message($message) {
        $message_lower = strtolower($message);
        
        // Spam patterns
        $spam_patterns = array(
            '/\b(viagra|cialis|casino|lottery|winner|congratulations.*won|claim.*prize)\b/i',
            '/\b(click here|buy now|free money|make money fast)\b/i',
            '/(https?:\/\/[^\s]+){3,}/i', // More than 3 URLs
            '/(.)\1{10,}/i', // Same character repeated 10+ times
        );
        
        foreach ($spam_patterns as $pattern) {
            if (preg_match($pattern, $message)) {
                return true;
            }
        }
        
        // Check for excessive caps (more than 70% uppercase in messages > 10 chars)
        if (strlen($message) > 10) {
            $uppercase_count = preg_match_all('/[A-Z]/', $message);
            $letter_count = preg_match_all('/[a-zA-Z]/', $message);
            
            if ($letter_count > 0 && ($uppercase_count / $letter_count) > 0.7) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check for excessive word/phrase repetition
     */
    private static function has_excessive_repetition($message) {
        $words = str_word_count(strtolower($message), 1);
        
        if (count($words) < 5) {
            return false;
        }
        
        $word_counts = array_count_values($words);
        
        foreach ($word_counts as $word => $count) {
            // Skip common words
            if (in_array($word, array('the', 'a', 'an', 'is', 'are', 'to', 'and', 'or', 'i', 'you', 'it'))) {
                continue;
            }
            
            // If a word appears more than 5 times and makes up > 30% of message
            if ($count > 5 && ($count / count($words)) > 0.3) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if IP is blocked
     */
    public static function is_ip_blocked() {
        $ip = self::get_client_ip();
        $blocked_ips = get_option('madex_chatbot_blocked_ips', array());
        
        if (in_array($ip, $blocked_ips)) {
            return true;
        }
        
        // Check for CIDR ranges
        foreach ($blocked_ips as $blocked) {
            if (strpos($blocked, '/') !== false && self::ip_in_range($ip, $blocked)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if IP is in CIDR range
     */
    private static function ip_in_range($ip, $cidr) {
        list($subnet, $bits) = explode('/', $cidr);
        $ip = ip2long($ip);
        $subnet = ip2long($subnet);
        $mask = -1 << (32 - $bits);
        $subnet &= $mask;
        return ($ip & $mask) == $subnet;
    }
    
    /**
     * Block an IP address
     */
    public static function block_ip($ip, $reason = '') {
        $blocked_ips = get_option('madex_chatbot_blocked_ips', array());
        
        if (!in_array($ip, $blocked_ips)) {
            $blocked_ips[] = $ip;
            update_option('madex_chatbot_blocked_ips', $blocked_ips);
            
            // Log the block
            self::log_security_event('ip_blocked', array(
                'ip' => $ip,
                'reason' => $reason
            ));
        }
    }
    
    /**
     * Log security event
     */
    public static function log_security_event($event_type, $data = array()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'madex_security_log';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            return;
        }
        
        $wpdb->insert(
            $table_name,
            array(
                'event_type' => $event_type,
                'ip_address' => self::get_client_ip(),
                'user_id' => get_current_user_id(),
                'data' => json_encode($data),
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%s', '%s')
        );
    }
    
    /**
     * Perform all security checks
     * 
     * @return array ['passed' => bool, 'error' => string|null]
     */
    public static function perform_security_checks($message = '') {
        // Check if IP is blocked
        if (self::is_ip_blocked()) {
            self::log_security_event('blocked_attempt', array('reason' => 'ip_blocked'));
            return array(
                'passed' => false,
                'error' => __('Zugriff verweigert.', 'madex-chatbot'),
                'code' => 'ip_blocked'
            );
        }
        
        // Check daily limit
        $daily = self::check_daily_limit();
        if (!$daily['allowed']) {
            self::log_security_event('rate_limited', array('type' => 'daily'));
            return array(
                'passed' => false,
                'error' => __('Das Tageslimit für Nachrichten ist erreicht. Bitte versuchen Sie es morgen erneut.', 'madex-chatbot'),
                'code' => 'daily_limit'
            );
        }
        
        // Check per-minute rate limit
        $rate = self::check_message_rate_limit();
        if (!$rate['allowed']) {
            self::log_security_event('rate_limited', array('type' => 'per_minute'));
            return array(
                'passed' => false,
                'error' => sprintf(__('Zu viele Nachrichten. Bitte warten Sie %d Sekunden.', 'madex-chatbot'), $rate['reset_in']),
                'code' => 'rate_limited'
            );
        }
        
        // Check cooldown
        $cooldown = self::check_message_cooldown();
        if (!$cooldown['allowed']) {
            return array(
                'passed' => false,
                'error' => sprintf(__('Bitte warten Sie %d Sekunden zwischen den Nachrichten.', 'madex-chatbot'), $cooldown['wait']),
                'code' => 'cooldown'
            );
        }
        
        // Validate message content if provided
        if (!empty($message)) {
            $validation_errors = self::validate_message($message);
            if (!empty($validation_errors)) {
                self::log_security_event('validation_failed', array('errors' => $validation_errors));
                return array(
                    'passed' => false,
                    'error' => implode('. ', $validation_errors),
                    'code' => 'validation_failed'
                );
            }
        }
        
        return array('passed' => true, 'error' => null);
    }
    
    /**
     * Get security statistics
     */
    public static function get_security_stats() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'madex_security_log';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            return array(
                'blocked_today' => 0,
                'rate_limited_today' => 0,
                'total_blocked_ips' => count(get_option('madex_chatbot_blocked_ips', array()))
            );
        }
        
        $today = current_time('Y-m-d');
        
        $blocked_today = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE event_type = 'blocked_attempt' AND DATE(created_at) = %s",
            $today
        ));
        
        $rate_limited_today = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE event_type = 'rate_limited' AND DATE(created_at) = %s",
            $today
        ));
        
        return array(
            'blocked_today' => intval($blocked_today),
            'rate_limited_today' => intval($rate_limited_today),
            'total_blocked_ips' => count(get_option('madex_chatbot_blocked_ips', array()))
        );
    }
}
