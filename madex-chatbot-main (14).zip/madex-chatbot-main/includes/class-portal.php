<?php
/**
 * Standalone Madex management portal (default: /chatadm).
 *
 * The portal never renders the WordPress theme, admin bar or wp-content URLs.
 * Every route is authorised on the server through Madex_Portal_Auth; the
 * hidden path is not a security boundary. Pages are served with a strict CSP
 * (no inline scripts or styles), so all charts use SVG attributes and all
 * behaviour lives in assets/portal/portal.js.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Portal {

    private static $instance = null;

    /** @var array|null Active session context for the current request. */
    private $session = null;

    /** @var WP_User|null */
    private $user = null;

    /** @var bool Whether the current auth page needs the QR library. */
    private $needs_qr = false;

    /** Static assets served through the portal path (published => source). */
    private static $assets = array(
        'portal.css' => array('assets/portal/portal.css', 'text/css; charset=UTF-8'),
        'portal.js' => array('assets/portal/portal.js', 'application/javascript; charset=UTF-8'),
        'qrcode.js' => array('assets/vendor/qrcode-generator.js', 'application/javascript; charset=UTF-8'),
        'manrope-latin.woff2' => array('assets/fonts/manrope-latin-variable.woff2', 'font/woff2'),
        'manrope-latin-ext.woff2' => array('assets/fonts/manrope-latin-ext-variable.woff2', 'font/woff2'),
        'logo.png' => array('assets/images/logo-madex.png', 'image/png'),
        'icon.png' => array('assets/images/icon-madex.png', 'image/png'),
        'favicon.png' => array('assets/images/favicon-madex.png', 'image/png'),
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', array($this, 'maybe_handle_request'), 20);
    }

    /* ==================================================================
     * Routing
     * ================================================================== */

    public function maybe_handle_request() {
        if (wp_doing_ajax() || wp_doing_cron() || (defined('REST_REQUEST') && REST_REQUEST) || is_admin()) {
            return;
        }

        $request_path = isset($_SERVER['REQUEST_URI']) ? (string) wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH) : '';
        $request_path = '/' . ltrim(rawurldecode($request_path), '/');
        $base = Madex_Portal_Auth::base_path();

        if ($request_path !== $base && strpos($request_path, $base . '/') !== 0) {
            return;
        }

        $route = trim(substr($request_path, strlen($base)), '/');
        if (strpos($route, '..') !== false) {
            $route = '404';
        }

        // Static assets: cacheable, no session required, no secrets.
        if (strpos($route, 'assets/') === 0) {
            $this->serve_asset(substr($route, 7));
        }

        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        show_admin_bar(false);

        // Upgrade to HTTPS when the site supports it; otherwise refuse.
        if (!is_ssl()) {
            if (wp_parse_url(home_url('/'), PHP_URL_SCHEME) === 'https') {
                wp_safe_redirect(Madex_Portal_Auth::url($route), 301);
                exit;
            }
            Madex_Portal_Auth::send_secure_headers();
            status_header(403);
            $this->render_auth_page(__('Sichere Verbindung erforderlich', 'madex-chatbot'), function () {
                $this->state_card('lock', 'error', __('Sichere Verbindung erforderlich', 'madex-chatbot'), __('Das Management-Portal ist nur über HTTPS erreichbar. Bitte wenden Sie sich an Ihre Administration.', 'madex-chatbot'));
            });
            exit;
        }

        Madex_Portal_Auth::send_secure_headers();
        header('X-Content-Type-Options: nosniff', true);

        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';
        if ($method === 'POST' && !$this->same_origin()) {
            $this->render_error_page(403, __('Anfrage abgelehnt', 'madex-chatbot'), __('Die Anfrage stammt nicht von dieser Seite. Bitte laden Sie das Portal neu.', 'madex-chatbot'));
        }

        $parts = $route === '' ? array('') : explode('/', $route);
        $page = $parts[0];

        switch ($page) {
            case '':
                $this->route_root();
                break;
            case 'login':
                $method === 'POST' ? $this->handle_login() : $this->page_login();
                break;
            case '2fa':
                $method === 'POST' ? $this->handle_two_factor() : $this->page_two_factor();
                break;
            case 'recovery':
                $method === 'POST' ? $this->handle_recovery() : $this->page_recovery();
                break;
            case 'logout':
                $method === 'POST' ? $this->handle_logout() : $this->redirect('login');
                break;
            case 'overview':
            case 'chats':
            case 'appointments':
            case 'reports':
            case 'live':
            case 'export.csv':
            case 'api':
                $this->dispatch_app($page, $parts, $method);
                break;
            default:
                $this->render_error_page(404, __('Seite nicht gefunden', 'madex-chatbot'), __('Diese Seite existiert nicht.', 'madex-chatbot'));
        }
        exit;
    }

    private function dispatch_app($page, $parts, $method) {
        $is_api = $page === 'api';
        $touch = !$is_api || !empty($_GET['active']);
        $session = Madex_Portal_Auth::get_active_session($touch);

        if (is_wp_error($session)) {
            $code = $session->get_error_code();
            if ($is_api) {
                $this->json(array('error' => 'auth', 'redirect' => Madex_Portal_Auth::url('login', array('state' => 'expired'))), 401);
            }
            if ($code === 'madex_portal_invalid_auth_state') {
                $this->redirect('2fa');
            }
            if ($code === 'madex_portal_forbidden') {
                $this->redirect('login', array('state' => 'denied'));
            }
            if ($code === 'madex_portal_session_expired') {
                $this->redirect('login', array('state' => 'expired'));
            }
            $this->redirect('login');
        }

        $this->session = $session;
        $this->user = get_userdata((int) $session['user_id']);

        if ($method === 'POST') {
            if (!Madex_Portal_Auth::verify_form_token(isset($_POST['_token']) ? (string) wp_unslash($_POST['_token']) : '')) {
                $this->render_error_page(403, __('Sitzung ungültig', 'madex-chatbot'), __('Das Formular ist abgelaufen. Bitte laden Sie die Seite neu und versuchen Sie es erneut.', 'madex-chatbot'));
            }
            if ($page === 'appointments' && isset($parts[1]) && $parts[1] === 'update') {
                $this->handle_appointment_update();
            }
            if ($page === 'appointments' && isset($parts[1]) && $parts[1] === 'resend') {
                $this->handle_appointment_resend();
            }
            $this->render_error_page(405, __('Nicht erlaubt', 'madex-chatbot'), __('Diese Aktion ist nicht verfügbar.', 'madex-chatbot'));
        }

        switch ($page) {
            case 'overview':
                $this->page_overview();
                break;
            case 'chats':
                $this->page_chats();
                break;
            case 'appointments':
                $this->page_appointments();
                break;
            case 'reports':
                $this->page_reports();
                break;
            case 'live':
                $this->page_live();
                break;
            case 'export.csv':
                $this->export_csv();
                break;
            case 'api':
                if (isset($parts[1]) && $parts[1] === 'live') {
                    $this->api_live();
                }
                $this->json(array('error' => 'not_found'), 404);
        }
    }

    private function route_root() {
        $active = Madex_Portal_Auth::get_active_session(false);
        if (!is_wp_error($active)) {
            $this->redirect('overview');
        }
        if (!is_wp_error(Madex_Portal_Auth::get_preauth_session())) {
            $this->redirect('2fa');
        }
        $this->redirect('login');
    }

    /* ==================================================================
     * Authentication pages
     * ================================================================== */

    private function page_login($error = null, $username = '') {
        if (!is_wp_error(Madex_Portal_Auth::get_active_session(false))) {
            $this->redirect('overview');
        }

        $state = isset($_GET['state']) ? sanitize_key(wp_unslash($_GET['state'])) : '';

        if ($state === 'logged_out' && $error === null) {
            $this->render_auth_page(__('Sicher abgemeldet', 'madex-chatbot'), function () {
                $this->state_card('check', 'success', __('Sicher abgemeldet', 'madex-chatbot'), __('Ihre Sitzung wurde beendet. Schliessen Sie das Browserfenster auf geteilten Geräten.', 'madex-chatbot'), wp_date('d.m.Y · H:i'), __('Erneut anmelden', 'madex-chatbot'), Madex_Portal_Auth::url('login'));
            });
            return;
        }
        if ($state === 'denied' && $error === null) {
            status_header(403);
            $this->render_auth_page(__('Kein Zugriff', 'madex-chatbot'), function () {
                $this->state_card('x', 'error', __('Kein Zugriff', 'madex-chatbot'), __('Für dieses Konto ist das Management-Portal nicht freigegeben.', 'madex-chatbot'), __('Kontakt: Administration', 'madex-chatbot'), __('Zur Anmeldung', 'madex-chatbot'), Madex_Portal_Auth::url('login'));
            });
            return;
        }

        if ($error !== null) {
            status_header((int) $error['status']);
            if ($error['status'] === 429) {
                header('Retry-After: ' . (int) $error['retry_after']);
            }
        }

        $this->render_auth_page(__('Anmelden', 'madex-chatbot'), function () use ($error, $username, $state) {
            ?>
            <form class="auth-form" method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('login')); ?>" data-auth-form novalidate>
                <h1 class="auth-title" tabindex="-1"><?php esc_html_e('Anmelden', 'madex-chatbot'); ?></h1>
                <?php if ($state === 'expired' && $error === null) : ?>
                    <div class="notice notice--neutral" role="status"><?php echo $this->icon('clock'); ?><div><b><?php esc_html_e('Sitzung abgelaufen', 'madex-chatbot'); ?></b><span><?php esc_html_e('Sie wurden nach Inaktivität abgemeldet. Bitte melden Sie sich erneut an.', 'madex-chatbot'); ?></span></div></div>
                <?php elseif ($state === 'setup_expired' && $error === null) : ?>
                    <div class="notice notice--neutral" role="status"><?php echo $this->icon('clock'); ?><div><b><?php esc_html_e('Zeit abgelaufen', 'madex-chatbot'); ?></b><span><?php esc_html_e('Der Bestätigungsschritt ist abgelaufen. Bitte melden Sie sich erneut an.', 'madex-chatbot'); ?></span></div></div>
                <?php endif; ?>
                <?php $this->render_auth_error($error); ?>
                <label class="field">
                    <span class="field__label"><?php esc_html_e('Benutzername oder E-Mail', 'madex-chatbot'); ?></span>
                    <input class="input" name="username" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" required maxlength="254" value="<?php echo esc_attr($username); ?>" <?php echo $username === '' ? 'autofocus' : ''; ?>>
                </label>
                <label class="field">
                    <span class="field__label"><?php esc_html_e('Passwort', 'madex-chatbot'); ?></span>
                    <span class="input-group">
                        <input class="input" name="password" type="password" autocomplete="current-password" required maxlength="4096" data-password <?php echo $username !== '' ? 'autofocus' : ''; ?>>
                        <button type="button" class="input-group__btn" data-toggle-password aria-pressed="false"><?php esc_html_e('Anzeigen', 'madex-chatbot'); ?></button>
                    </span>
                </label>
                <button type="submit" class="btn btn--primary btn--lg btn--block" data-submit-label="<?php esc_attr_e('Wird geprüft …', 'madex-chatbot'); ?>"><?php esc_html_e('Weiter', 'madex-chatbot'); ?></button>
                <p class="auth-hint"><?php esc_html_e('Kein Zugang? Wenden Sie sich an Ihre Administration.', 'madex-chatbot'); ?></p>
            </form>
            <?php
        });
    }

    private function handle_login() {
        $username = isset($_POST['username']) ? sanitize_text_field(wp_unslash($_POST['username'])) : '';
        $password = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';

        $result = Madex_Portal_Auth::begin_password_auth($username, $password);
        if (is_wp_error($result)) {
            $this->page_login($this->auth_error($result), $username);
            return;
        }
        $this->redirect('2fa');
    }

    private function page_two_factor($error = null) {
        if (!is_wp_error(Madex_Portal_Auth::get_active_session(false))) {
            $this->redirect('overview');
        }

        $challenge = Madex_Portal_Auth::get_current_challenge();
        if (is_wp_error($challenge)) {
            $this->redirect('login', $challenge->get_error_code() === 'madex_portal_session_expired' ? array('state' => 'setup_expired') : array());
        }

        if ($error !== null) {
            status_header((int) $error['status']);
        }

        if ($challenge['type'] === 'enroll') {
            $payload = Madex_Portal_Auth::get_enrollment_payload('Madex Management');
            if (is_wp_error($payload)) {
                $payload = Madex_Portal_Auth::start_totp_enrollment('Madex Management');
            }
            if (is_wp_error($payload)) {
                $this->redirect('login', array('state' => 'setup_expired'));
            }

            $this->needs_qr = true;
            $this->render_auth_page(__('Authenticator einrichten', 'madex-chatbot'), function () use ($payload, $error) {
                $key = trim(chunk_split($payload['secret'], 4, ' '));
                ?>
                <div class="auth-form auth-form--wide">
                    <ol class="auth-steps" aria-label="<?php esc_attr_e('Einrichtung', 'madex-chatbot'); ?>">
                        <li class="is-current" aria-current="step"><?php esc_html_e('Scannen', 'madex-chatbot'); ?></li>
                        <li><?php esc_html_e('Bestätigen', 'madex-chatbot'); ?></li>
                        <li><?php esc_html_e('Codes sichern', 'madex-chatbot'); ?></li>
                    </ol>
                    <h1 class="auth-title" tabindex="-1"><?php esc_html_e('Authenticator einrichten', 'madex-chatbot'); ?></h1>
                    <p class="auth-lead"><?php esc_html_e('Zum Schutz des Portals ist eine Zwei-Faktor-Anmeldung erforderlich. Scannen Sie den Code mit Google Authenticator oder einer kompatiblen App.', 'madex-chatbot'); ?></p>
                    <div class="enroll">
                        <figure class="qr" data-qr="<?php echo esc_attr($payload['otpauth_uri']); ?>">
                            <canvas width="200" height="200" role="img" aria-label="<?php esc_attr_e('QR-Code für die Authenticator-App', 'madex-chatbot'); ?>"></canvas>
                            <noscript><?php esc_html_e('Bitte geben Sie den Schlüssel manuell ein.', 'madex-chatbot'); ?></noscript>
                        </figure>
                        <div class="enroll__manual">
                            <span class="field__label"><?php esc_html_e('Oder Schlüssel manuell eingeben', 'madex-chatbot'); ?></span>
                            <div class="copy-field">
                                <code class="copy-field__value" data-copy-source><?php echo esc_html($key); ?></code>
                                <button type="button" class="btn btn--ghost btn--sm" data-copy data-copied-label="<?php esc_attr_e('Kopiert ✓', 'madex-chatbot'); ?>"><?php esc_html_e('Kopieren', 'madex-chatbot'); ?></button>
                            </div>
                            <p class="field__hint"><?php esc_html_e('Kontoname: Madex Management · Zeitbasiert (TOTP) · 6 Ziffern', 'madex-chatbot'); ?></p>
                        </div>
                    </div>
                    <form method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('2fa')); ?>" class="stack" data-auth-form novalidate>
                        <input type="hidden" name="mode" value="enroll">
                        <?php $this->render_auth_error($error); ?>
                        <?php $this->otp_field(__('Code aus der App zur Bestätigung', 'madex-chatbot'), $error !== null); ?>
                        <button type="submit" class="btn btn--primary btn--lg btn--block" data-submit-label="<?php esc_attr_e('Wird geprüft …', 'madex-chatbot'); ?>"><?php esc_html_e('Bestätigen', 'madex-chatbot'); ?></button>
                    </form>
                    <?php $this->cancel_form(); ?>
                </div>
                <?php
            });
            return;
        }

        $this->render_auth_page(__('Bestätigungscode', 'madex-chatbot'), function () use ($error) {
            ?>
            <form class="auth-form" method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('2fa')); ?>" data-auth-form novalidate>
                <input type="hidden" name="mode" value="totp">
                <h1 class="auth-title" tabindex="-1"><?php esc_html_e('Bestätigungscode', 'madex-chatbot'); ?></h1>
                <p class="auth-lead"><?php esc_html_e('Geben Sie den 6-stelligen Code aus Ihrer Authenticator-App ein.', 'madex-chatbot'); ?></p>
                <?php $this->render_auth_error($error); ?>
                <?php $this->otp_field(__('Bestätigungscode', 'madex-chatbot'), $error !== null); ?>
                <button type="submit" class="btn btn--primary btn--lg btn--block" data-submit-label="<?php esc_attr_e('Wird geprüft …', 'madex-chatbot'); ?>"><?php esc_html_e('Bestätigen', 'madex-chatbot'); ?></button>
                <a class="btn btn--text btn--block" href="<?php echo esc_url(Madex_Portal_Auth::url('recovery')); ?>"><?php esc_html_e('Wiederherstellungscode verwenden', 'madex-chatbot'); ?></a>
            </form>
            <?php $this->cancel_form(); ?>
            <?php
        });
    }

    private function handle_two_factor() {
        $mode = isset($_POST['mode']) ? sanitize_key(wp_unslash($_POST['mode'])) : 'totp';
        $code = isset($_POST['code']) ? preg_replace('/\D+/', '', (string) wp_unslash($_POST['code'])) : '';

        if ($mode === 'enroll') {
            $result = Madex_Portal_Auth::confirm_totp_enrollment($code);
            if (is_wp_error($result)) {
                $this->handle_second_factor_error($result, 'page_two_factor');
                return;
            }
            $this->page_recovery_codes($result['recovery_codes']);
            return;
        }

        $result = Madex_Portal_Auth::verify_totp_challenge($code);
        if (is_wp_error($result)) {
            $this->handle_second_factor_error($result, 'page_two_factor');
            return;
        }
        $this->redirect('overview');
    }

    private function page_recovery($error = null) {
        if (is_wp_error(Madex_Portal_Auth::get_current_challenge())) {
            $this->redirect('login');
        }
        if ($error !== null) {
            status_header((int) $error['status']);
        }
        $this->render_auth_page(__('Wiederherstellungscode', 'madex-chatbot'), function () use ($error) {
            ?>
            <form class="auth-form" method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('recovery')); ?>" data-auth-form novalidate>
                <h1 class="auth-title" tabindex="-1"><?php esc_html_e('Wiederherstellungscode', 'madex-chatbot'); ?></h1>
                <p class="auth-lead"><?php esc_html_e('Kein Zugriff auf Ihre Authenticator-App? Verwenden Sie einen Ihrer einmaligen Wiederherstellungscodes. Jeder Code funktioniert nur einmal.', 'madex-chatbot'); ?></p>
                <?php $this->render_auth_error($error); ?>
                <label class="field">
                    <span class="field__label"><?php esc_html_e('Wiederherstellungscode', 'madex-chatbot'); ?></span>
                    <input class="input input--mono<?php echo $error ? ' is-invalid' : ''; ?>" name="recovery_code" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" required maxlength="40" placeholder="xxxx-xxxx-xxxx-xxxx" autofocus <?php echo $error ? 'aria-invalid="true"' : ''; ?>>
                </label>
                <button type="submit" class="btn btn--primary btn--lg btn--block" data-submit-label="<?php esc_attr_e('Wird geprüft …', 'madex-chatbot'); ?>"><?php esc_html_e('Anmelden', 'madex-chatbot'); ?></button>
                <a class="btn btn--text btn--block" href="<?php echo esc_url(Madex_Portal_Auth::url('2fa')); ?>"><?php esc_html_e('Zurück zum Authenticator-Code', 'madex-chatbot'); ?></a>
            </form>
            <?php
        });
    }

    private function handle_recovery() {
        $code = isset($_POST['recovery_code']) ? sanitize_text_field(wp_unslash($_POST['recovery_code'])) : '';
        $result = Madex_Portal_Auth::verify_recovery_challenge($code);
        if (is_wp_error($result)) {
            $this->handle_second_factor_error($result, 'page_recovery');
            return;
        }
        $this->redirect('overview');
    }

    private function handle_second_factor_error($error, $page_method) {
        $code = $error->get_error_code();
        if (in_array($code, array('madex_portal_auth_required', 'madex_portal_forbidden'), true)) {
            $this->redirect('login');
        }
        if (in_array($code, array('madex_portal_session_expired', 'madex_portal_setup_expired'), true)) {
            $this->redirect('login', array('state' => 'setup_expired'));
        }
        $this->{$page_method}($this->auth_error($error));
    }

    private function page_recovery_codes($codes) {
        $this->render_auth_page(__('Codes sichern', 'madex-chatbot'), function () use ($codes) {
            $text = implode("\n", array_map('strval', $codes));
            ?>
            <div class="auth-form auth-form--wide">
                <ol class="auth-steps" aria-label="<?php esc_attr_e('Einrichtung', 'madex-chatbot'); ?>">
                    <li class="is-complete"><?php esc_html_e('Scannen', 'madex-chatbot'); ?></li>
                    <li class="is-complete"><?php esc_html_e('Bestätigen', 'madex-chatbot'); ?></li>
                    <li class="is-current" aria-current="step"><?php esc_html_e('Codes sichern', 'madex-chatbot'); ?></li>
                </ol>
                <h1 class="auth-title" tabindex="-1"><?php esc_html_e('Codes sicher aufbewahren', 'madex-chatbot'); ?></h1>
                <div class="notice notice--warning" role="status"><?php echo $this->icon('alert'); ?><div><b><?php esc_html_e('Diese Codes werden nur einmal angezeigt.', 'madex-chatbot'); ?></b><span><?php esc_html_e('Mit jedem Code können Sie sich einmal anmelden, falls Ihr Telefon nicht verfügbar ist.', 'madex-chatbot'); ?></span></div></div>
                <ul class="recovery-codes" data-copy-source data-download-name="madex-wiederherstellungscodes.txt" data-download-text="<?php echo esc_attr("Madex Management – Wiederherstellungscodes\n" . wp_date('d.m.Y H:i') . "\n\n" . $text); ?>">
                    <?php foreach ($codes as $code) : ?><li><?php echo esc_html($code); ?></li><?php endforeach; ?>
                </ul>
                <div class="btn-row">
                    <button type="button" class="btn btn--secondary" data-download><?php echo $this->icon('download'); ?><?php esc_html_e('Herunterladen', 'madex-chatbot'); ?></button>
                    <button type="button" class="btn btn--secondary" data-copy data-copied-label="<?php esc_attr_e('Kopiert ✓', 'madex-chatbot'); ?>"><?php echo $this->icon('copy'); ?><?php esc_html_e('Kopieren', 'madex-chatbot'); ?></button>
                </div>
                <label class="check">
                    <input type="checkbox" data-confirm-codes>
                    <span><?php esc_html_e('Ich habe die Codes gespeichert.', 'madex-chatbot'); ?></span>
                </label>
                <a class="btn btn--primary btn--lg btn--block is-disabled" href="<?php echo esc_url(Madex_Portal_Auth::url('overview')); ?>" data-finish-setup aria-disabled="true"><?php esc_html_e('Einrichtung abschliessen', 'madex-chatbot'); ?></a>
            </div>
            <?php
        });
    }

    private function handle_logout() {
        // Pre-auth sessions have no form token; active sessions must present one.
        if (!is_wp_error(Madex_Portal_Auth::get_active_session(false))
            && !Madex_Portal_Auth::verify_form_token(isset($_POST['_token']) ? (string) wp_unslash($_POST['_token']) : '')) {
            $this->redirect('overview');
        }
        Madex_Portal_Auth::logout();
        $this->redirect('login', array('state' => 'logged_out'));
    }

    private function auth_error($error) {
        $data = $error->get_error_data();
        $status = is_array($data) && isset($data['status']) ? (int) $data['status'] : 400;
        $retry = is_array($data) && isset($data['retry_after']) ? (int) $data['retry_after'] : 0;
        $code = $error->get_error_code();

        if ($code === 'madex_portal_rate_limited') {
            $locked = $retry > 120;
            return array(
                'status' => 429,
                'retry_after' => $retry,
                'kind' => $locked ? 'locked' : 'rate',
                'title' => $locked ? __('Vorübergehend gesperrt', 'madex-chatbot') : __('Zu viele Versuche', 'madex-chatbot'),
                'body' => $locked
                    ? __('Der Zugang ist aus Sicherheitsgründen vorübergehend gesperrt.', 'madex-chatbot')
                    : __('Bitte warten Sie, bevor Sie es erneut versuchen.', 'madex-chatbot'),
            );
        }
        if ($code === 'madex_portal_invalid_credentials') {
            return array('status' => 401, 'retry_after' => 0, 'kind' => 'error', 'title' => __('Anmeldung fehlgeschlagen.', 'madex-chatbot'), 'body' => __('Benutzername oder Passwort ist nicht korrekt.', 'madex-chatbot'));
        }
        if ($code === 'madex_portal_invalid_verification') {
            return array('status' => 401, 'retry_after' => 0, 'kind' => 'error', 'title' => __('Code ungültig.', 'madex-chatbot'), 'body' => __('Der Code ist ungültig oder abgelaufen. Bitte verwenden Sie den aktuellen Code.', 'madex-chatbot'));
        }
        if ($code === 'madex_portal_https_required') {
            return array('status' => 403, 'retry_after' => 0, 'kind' => 'error', 'title' => __('Sichere Verbindung erforderlich.', 'madex-chatbot'), 'body' => __('Bitte rufen Sie das Portal über HTTPS auf.', 'madex-chatbot'));
        }
        return array('status' => max(400, $status), 'retry_after' => 0, 'kind' => 'error', 'title' => __('Anmeldung nicht möglich.', 'madex-chatbot'), 'body' => __('Bitte versuchen Sie es erneut.', 'madex-chatbot'));
    }

    private function render_auth_error($error) {
        if ($error === null) {
            return;
        }
        if (in_array($error['kind'], array('rate', 'locked'), true)) {
            $minutes = (int) ceil($error['retry_after'] / 60);
            ?>
            <div class="notice notice--<?php echo $error['kind'] === 'locked' ? 'error' : 'warning'; ?>" role="alert">
                <?php echo $this->icon($error['kind'] === 'locked' ? 'ban' : 'hourglass'); ?>
                <div>
                    <b><?php echo esc_html($error['title']); ?></b>
                    <span><?php echo esc_html($error['body']); ?></span>
                    <span class="notice__meta" data-countdown="<?php echo esc_attr($error['retry_after']); ?>" data-countdown-done="<?php esc_attr_e('Sie können es jetzt erneut versuchen.', 'madex-chatbot'); ?>">
                        <?php
                        echo esc_html($error['kind'] === 'locked'
                            ? sprintf(__('Erneut möglich in ca. %d Min. · Kontakt: Administration', 'madex-chatbot'), $minutes)
                            : sprintf(__('Erneut möglich in %s', 'madex-chatbot'), gmdate('i:s', $error['retry_after'])));
                        ?>
                    </span>
                </div>
            </div>
            <?php
            return;
        }
        ?>
        <div class="notice notice--error" role="alert"><?php echo $this->icon('x'); ?><div><b><?php echo esc_html($error['title']); ?></b><span><?php echo esc_html($error['body']); ?></span></div></div>
        <?php
    }

    private function otp_field($label, $invalid) {
        ?>
        <label class="field">
            <span class="field__label"><?php echo esc_html($label); ?></span>
            <input class="input input--otp<?php echo $invalid ? ' is-invalid' : ''; ?>" name="code" type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required autofocus placeholder="••••••" data-otp <?php echo $invalid ? 'aria-invalid="true"' : ''; ?>>
        </label>
        <?php
    }

    private function cancel_form() {
        ?>
        <form method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('logout')); ?>" class="auth-cancel">
            <button type="submit" class="btn btn--text btn--sm"><?php esc_html_e('Abbrechen und abmelden', 'madex-chatbot'); ?></button>
        </form>
        <?php
    }

    private function state_card($icon, $tone, $title, $body, $meta = '', $cta = '', $cta_url = '') {
        ?>
        <div class="auth-form state-card">
            <span class="state-card__icon state-card__icon--<?php echo esc_attr($tone); ?>"><?php echo $this->icon($icon); ?></span>
            <h1 class="auth-title" tabindex="-1"><?php echo esc_html($title); ?></h1>
            <p class="auth-lead"><?php echo esc_html($body); ?></p>
            <?php if ($meta !== '') : ?><p class="state-card__meta"><?php echo esc_html($meta); ?></p><?php endif; ?>
            <?php if ($cta !== '') : ?><a class="btn btn--primary btn--lg btn--block" href="<?php echo esc_url($cta_url); ?>"><?php echo esc_html($cta); ?></a><?php endif; ?>
        </div>
        <?php
    }

    /* ==================================================================
     * App pages
     * ================================================================== */

    private function page_overview() {
        $range = $this->range_param(array(1, 7, 30), 7);
        $stats = Madex_Business_Service::get_dashboard_stats($range);
        $report = Madex_Business_Service::get_report_series(max(7, $range === 1 ? 14 : $range));
        $live = Madex_Business_Service::get_live_activity();
        $recent = Madex_Business_Service::list_appointments(array('per_page' => 5));
        $failed = Madex_Business_Service::list_appointments(array('email_status' => 'failed', 'per_page' => 1));
        $twofa = Madex_Portal_Auth::get_2fa_status((int) $this->session['user_id']);
        $range_label = $range === 1 ? __('heute', 'madex-chatbot') : sprintf(__('letzte %d Tage', 'madex-chatbot'), $range);

        $this->render_app_page('overview', __('Übersicht', 'madex-chatbot'), function () use ($range, $stats, $report, $live, $recent, $failed, $twofa, $range_label) {
            $first = $this->user && $this->user->first_name ? $this->user->first_name : ($this->user ? $this->user->display_name : '');
            ?>
            <header class="page-head">
                <div>
                    <h1 class="page-title" tabindex="-1"><?php echo esc_html($this->greeting() . ($first !== '' ? ', ' . $first : '')); ?></h1>
                    <p class="page-sub"><?php echo esc_html($this->long_date()); ?> · <span class="live-dot" data-live-stamp><?php esc_html_e('Live', 'madex-chatbot'); ?></span></p>
                </div>
                <?php $this->segmented('overview', 'range', array(1 => __('Heute', 'madex-chatbot'), 7 => __('7 Tage', 'madex-chatbot'), 30 => __('30 Tage', 'madex-chatbot')), $range); ?>
            </header>

            <section class="kpi-grid" aria-label="<?php esc_attr_e('Kennzahlen', 'madex-chatbot'); ?>">
                <?php
                $this->kpi(__('Gespräche', 'madex-chatbot'), $stats['conversations_range'], $range_label);
                $this->kpi(__('Gespräche heute', 'madex-chatbot'), $stats['conversations_today'], __('seit 00:00', 'madex-chatbot'));
                $this->kpi(__('Aktive Chats', 'madex-chatbot'), $stats['active_chats'], __('gerade jetzt', 'madex-chatbot'), 'live');
                $this->kpi(__('Neue Terminanfragen', 'madex-chatbot'), $stats['new_appointments'], __('nicht bearbeitet', 'madex-chatbot'), $stats['new_appointments'] > 0 ? 'accent' : '');
                $this->kpi(__('Bestätigte Termine', 'madex-chatbot'), $stats['confirmed_upcoming'], __('ab heute', 'madex-chatbot'));
                $this->kpi(__('Ungelöste Anfragen', 'madex-chatbot'), $stats['unresolved'], __('ohne bestätigte Info', 'madex-chatbot'));
                $this->kpi(__('Neue Interessenten', 'madex-chatbot'), $stats['prospects'], $range_label);
                $this->kpi(__('Bestehende Kunden', 'madex-chatbot'), $stats['existing_clients'], $range_label);
                ?>
            </section>

            <div class="grid grid--chart">
                <section class="card">
                    <div class="card__head"><h2 class="card__title"><?php esc_html_e('Gespräche & Terminanfragen', 'madex-chatbot'); ?></h2><?php $this->chart_legend(); ?></div>
                    <?php $this->line_chart($report['series']); ?>
                </section>
                <section class="card card--live" aria-live="polite">
                    <canvas class="globe" data-globe aria-hidden="true"></canvas>
                    <div class="card__head"><h2 class="card__title"><?php esc_html_e('Live', 'madex-chatbot'); ?></h2><span class="pulse-label"><span class="pulse" aria-hidden="true"></span><?php esc_html_e('Auto-Refresh 15 s', 'madex-chatbot'); ?></span></div>
                    <p class="live-count"><b data-live-count><?php echo esc_html($live['active_count']); ?></b><span><?php esc_html_e('aktive Gespräche', 'madex-chatbot'); ?></span></p>
                    <ul class="live-chips" data-live-list>
                        <?php foreach (array_slice($live['active'], 0, 3) as $item) : ?>
                            <li><a href="<?php echo esc_url(Madex_Portal_Auth::url('chats', array('id' => $item['public_id']))); ?>"><span class="dot" aria-hidden="true"></span><?php echo esc_html($this->live_chip_text($item)); ?></a></li>
                        <?php endforeach; ?>
                        <?php if (empty($live['active'])) : ?><li class="live-chips__empty"><?php esc_html_e('Gerade keine aktiven Gespräche.', 'madex-chatbot'); ?></li><?php endif; ?>
                    </ul>
                </section>
            </div>

            <div class="grid grid--three">
                <section class="card">
                    <h2 class="card__title"><?php esc_html_e('Häufige Anliegen', 'madex-chatbot'); ?></h2>
                    <?php $this->bar_list($this->topic_rows($report), __('Noch keine Anliegen erfasst.', 'madex-chatbot')); ?>
                </section>
                <section class="card">
                    <h2 class="card__title"><?php esc_html_e('Kunden vs. Interessenten', 'madex-chatbot'); ?></h2>
                    <?php $this->donut($stats['existing_clients'], $stats['prospects']); ?>
                </section>
                <section class="card">
                    <?php
                    $items = array();
                    if (!empty($failed['items'])) {
                        $item = $failed['items'][0];
                        $items[] = array('error', 'x', sprintf(_n('%d E-Mail fehlgeschlagen', '%d E-Mails fehlgeschlagen', $failed['total'], 'madex-chatbot'), $failed['total']), $item['reference'] . ', ' . ($item['company'] ?: $item['customer_name']), Madex_Portal_Auth::url('appointments', array('ref' => $item['reference'])), __('Öffnen', 'madex-chatbot'));
                    }
                    if ($stats['stale_new'] > 0) {
                        $items[] = array('warning', 'clock', __('Seit über 2 Tagen offen', 'madex-chatbot'), sprintf(_n('%d neue Anfrage', '%d neue Anfragen', $stats['stale_new'], 'madex-chatbot'), $stats['stale_new']), Madex_Portal_Auth::url('appointments', array('status' => 'new')), __('Ansehen', 'madex-chatbot'));
                    }
                    if ($stats['unresolved'] > 0) {
                        $items[] = array('neutral', 'help', __('Unbeantwortet', 'madex-chatbot'), sprintf(_n('%d Gespräch ohne bestätigte Info', '%d Gespräche ohne bestätigte Info', $stats['unresolved'], 'madex-chatbot'), $stats['unresolved']), Madex_Portal_Auth::url('chats', array('filter' => 'unresolved')), __('Ansehen', 'madex-chatbot'));
                    }
                    if ($twofa['recovery_codes_remaining'] <= 2) {
                        $items[] = array('warning', 'key', __('Wiederherstellungscodes', 'madex-chatbot'), sprintf(__('Nur noch %d Codes übrig – Administration kontaktieren', 'madex-chatbot'), $twofa['recovery_codes_remaining']), '', '');
                    }
                    ?>
                    <div class="card__head"><h2 class="card__title"><?php esc_html_e('Benötigt Aufmerksamkeit', 'madex-chatbot'); ?></h2><?php if ($items) : ?><span class="count-badge count-badge--error"><?php echo esc_html(count($items)); ?></span><?php endif; ?></div>
                    <?php if (empty($items)) : ?>
                        <div class="empty empty--inline"><?php echo $this->icon('check'); ?><p><?php esc_html_e('Alles erledigt. Nichts benötigt gerade Ihre Aufmerksamkeit.', 'madex-chatbot'); ?></p></div>
                    <?php else : ?>
                        <ul class="attention">
                            <?php foreach ($items as $item) : ?>
                                <li class="attention__item attention__item--<?php echo esc_attr($item[0]); ?>">
                                    <span class="attention__icon"><?php echo $this->icon($item[1]); ?></span>
                                    <span class="attention__text"><b><?php echo esc_html($item[2]); ?></b> · <?php echo esc_html($item[3]); ?></span>
                                    <?php if ($item[4] !== '') : ?><a href="<?php echo esc_url($item[4]); ?>"><?php echo esc_html($item[5]); ?></a><?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </section>
            </div>

            <section class="card card--flush">
                <div class="card__head card__head--pad"><h2 class="card__title"><?php esc_html_e('Neueste Terminanfragen', 'madex-chatbot'); ?></h2><a class="link-strong" href="<?php echo esc_url(Madex_Portal_Auth::url('appointments')); ?>"><?php esc_html_e('Alle anzeigen →', 'madex-chatbot'); ?></a></div>
                <?php $this->appointment_table($recent['items']); ?>
            </section>
            <?php
        });
    }

    private function page_chats() {
        $state = isset($_GET['state']) ? sanitize_key(wp_unslash($_GET['state'])) : '';
        $state = in_array($state, array('live', 'closed'), true) ? $state : '';
        $type = isset($_GET['type']) ? sanitize_key(wp_unslash($_GET['type'])) : '';
        $type = in_array($type, array('client', 'prospect'), true) ? $type : '';
        $search = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
        $page = isset($_GET['p']) ? max(1, absint($_GET['p'])) : 1;
        $selected = isset($_GET['id']) ? sanitize_text_field(wp_unslash($_GET['id'])) : '';
        $unresolved = isset($_GET['filter']) && sanitize_key(wp_unslash($_GET['filter'])) === 'unresolved';

        $list = Madex_Business_Service::list_conversations(array('state' => $state, 'customer_type' => $type, 'search' => $search, 'unresolved' => $unresolved, 'page' => $page, 'per_page' => 20));
        $detail = $selected !== '' ? Madex_Business_Service::get_conversation($selected) : null;
        if (is_wp_error($detail)) {
            $detail = null;
        }
        $filters = array('state' => $state, 'type' => $type, 'q' => $search, 'filter' => $unresolved ? 'unresolved' : '');

        $this->render_app_page('chats', __('Chats', 'madex-chatbot'), function () use ($list, $detail, $state, $type, $search, $filters, $page) {
            ?>
            <header class="page-head">
                <div>
                    <h1 class="page-title" tabindex="-1"><?php esc_html_e('Chats', 'madex-chatbot'); ?></h1>
                    <p class="page-sub"><?php echo esc_html(sprintf(_n('%d Gespräch', '%d Gespräche', $list['total'], 'madex-chatbot'), $list['total'])); ?></p>
                </div>
            </header>
            <div class="split<?php echo $detail ? ' has-detail' : ''; ?>">
                <section class="card card--flush split__list" aria-label="<?php esc_attr_e('Gesprächsliste', 'madex-chatbot'); ?>">
                    <div class="list-toolbar">
                        <nav class="pills" aria-label="<?php esc_attr_e('Status filtern', 'madex-chatbot'); ?>">
                            <?php
                            foreach (array('' => __('Alle', 'madex-chatbot'), 'live' => __('Live', 'madex-chatbot'), 'closed' => __('Beendet', 'madex-chatbot')) as $key => $label) {
                                $this->pill(Madex_Portal_Auth::url('chats', array_filter(array_merge($filters, array('state' => $key)))), $label, $state === $key);
                            }
                            ?>
                            <span class="pills__sep" aria-hidden="true"></span>
                            <?php
                            foreach (array('' => __('Alle Typen', 'madex-chatbot'), 'client' => __('Kunden', 'madex-chatbot'), 'prospect' => __('Interessenten', 'madex-chatbot')) as $key => $label) {
                                $this->pill(Madex_Portal_Auth::url('chats', array_filter(array_merge($filters, array('type' => $key)))), $label, $type === $key);
                            }
                            ?>
                            <span class="pills__sep" aria-hidden="true"></span>
                            <?php $this->pill(Madex_Portal_Auth::url('chats', array_filter(array_merge($filters, array('filter' => $filters['filter'] === 'unresolved' ? '' : 'unresolved')))), __('Ohne bestätigte Info', 'madex-chatbot'), $filters['filter'] === 'unresolved'); ?>
                        </nav>
                        <?php $this->search_form('chats', $search, __('Suchen nach Inhalt oder Thema …', 'madex-chatbot'), array('state' => $state, 'type' => $type, 'filter' => $filters['filter'])); ?>
                    </div>
                    <?php if (empty($list['items'])) : ?>
                        <div class="empty"><?php echo $this->icon('chat'); ?><b><?php esc_html_e('Keine Gespräche gefunden', 'madex-chatbot'); ?></b><p><?php esc_html_e('Sobald Besucher den Chat nutzen, erscheinen die Gespräche hier.', 'madex-chatbot'); ?></p></div>
                    <?php else : ?>
                        <ul class="row-list">
                            <?php foreach ($list['items'] as $item) : $active = $detail && $detail['public_id'] === $item['public_id']; ?>
                                <li>
                                    <a class="row-link<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo esc_url(Madex_Portal_Auth::url('chats', array_filter(array_merge($filters, array('id' => $item['public_id'], 'p' => $page > 1 ? $page : ''))))); ?>" <?php echo $active ? 'aria-current="true"' : ''; ?>>
                                        <span class="row-link__top">
                                            <b><?php echo esc_html(sprintf(__('Besucher %s', 'madex-chatbot'), $item['visitor'])); ?></b>
                                            <?php if ($item['is_live']) : ?><span class="tag tag--live"><span class="dot" aria-hidden="true"></span><?php esc_html_e('Live', 'madex-chatbot'); ?></span><?php endif; ?>
                                            <time datetime="<?php echo esc_attr($this->iso($item['last_seen'])); ?>"><?php echo esc_html($this->relative($item['last_seen'])); ?></time>
                                        </span>
                                        <span class="row-link__meta"><?php echo esc_html(implode(' · ', array_filter(array($this->customer_type_label($item['customer_type']), $item['topic_label'], sprintf(_n('%d Nachricht', '%d Nachrichten', $item['user_messages'], 'madex-chatbot'), $item['user_messages']))))); ?><?php if ($item['fallbacks'] > 0) : ?> · <span class="text-warning"><?php esc_html_e('ohne bestätigte Info', 'madex-chatbot'); ?></span><?php endif; ?></span>
                                        <?php if ($item['preview'] !== '') : ?><span class="row-link__preview">„<?php echo esc_html($item['preview']); ?>“</span><?php endif; ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php $this->pagination('chats', $filters, $list); ?>
                    <?php endif; ?>
                </section>
                <section class="card split__detail" aria-label="<?php esc_attr_e('Gesprächsdetail', 'madex-chatbot'); ?>">
                    <?php if (!$detail) : ?>
                        <div class="empty"><?php echo $this->icon('arrow-left'); ?><b><?php esc_html_e('Gespräch auswählen', 'madex-chatbot'); ?></b><p><?php esc_html_e('Wählen Sie links ein Gespräch, um den Verlauf zu sehen.', 'madex-chatbot'); ?></p></div>
                    <?php else : ?>
                        <a class="back-link" href="<?php echo esc_url(Madex_Portal_Auth::url('chats', array_filter($filters))); ?>"><?php echo $this->icon('arrow-left'); ?><?php esc_html_e('Zurück zur Liste', 'madex-chatbot'); ?></a>
                        <div class="detail-head">
                            <div>
                                <span class="mono-label"><?php echo esc_html(sprintf(__('Besucher %s', 'madex-chatbot'), $detail['visitor'])); ?></span>
                                <h2 class="detail-title"><?php echo esc_html($detail['topic_label'] !== '' ? $detail['topic_label'] : __('Allgemeine Anfrage', 'madex-chatbot')); ?></h2>
                                <p class="detail-sub"><?php echo esc_html($this->customer_type_label($detail['customer_type'])); ?> · <?php echo esc_html(sprintf(__('gestartet %s', 'madex-chatbot'), $this->datetime($detail['created_at']))); ?></p>
                            </div>
                            <?php if ($detail['is_live']) : ?><span class="tag tag--live"><span class="dot" aria-hidden="true"></span><?php esc_html_e('Live', 'madex-chatbot'); ?></span><?php else : ?><span class="tag"><?php esc_html_e('Beendet', 'madex-chatbot'); ?></span><?php endif; ?>
                        </div>
                        <?php if ($detail['contact']) : ?>
                            <dl class="facts">
                                <div><dt><?php esc_html_e('Kontakt', 'madex-chatbot'); ?></dt><dd><?php echo esc_html($detail['contact']['customer_name']); ?><?php echo $detail['contact']['company'] !== '' ? ' · ' . esc_html($detail['contact']['company']) : ''; ?></dd></div>
                                <?php if ($detail['contact']['email'] !== '') : ?><div><dt><?php esc_html_e('E-Mail', 'madex-chatbot'); ?></dt><dd><a href="mailto:<?php echo esc_attr($detail['contact']['email']); ?>"><?php echo esc_html($detail['contact']['email']); ?></a></dd></div><?php endif; ?>
                                <?php if ($detail['contact']['phone'] !== '') : ?><div><dt><?php esc_html_e('Telefon', 'madex-chatbot'); ?></dt><dd><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $detail['contact']['phone'])); ?>"><?php echo esc_html($detail['contact']['phone']); ?></a></dd></div><?php endif; ?>
                                <?php if ($detail['contact']['reference'] !== '') : ?><div><dt><?php esc_html_e('Terminanfrage', 'madex-chatbot'); ?></dt><dd><a href="<?php echo esc_url(Madex_Portal_Auth::url('appointments', array('ref' => $detail['contact']['reference']))); ?>" class="mono"><?php echo esc_html($detail['contact']['reference']); ?></a></dd></div><?php endif; ?>
                            </dl>
                        <?php else : ?>
                            <p class="privacy-note"><?php echo $this->icon('shield'); ?><?php esc_html_e('Anonymes Gespräch – es wurden keine Kontaktdaten hinterlassen.', 'madex-chatbot'); ?></p>
                        <?php endif; ?>
                        <ol class="transcript" aria-label="<?php esc_attr_e('Verlauf', 'madex-chatbot'); ?>">
                            <?php foreach ($detail['messages'] as $message) : ?>
                                <li class="bubble bubble--<?php echo esc_attr($message['sender']); ?><?php echo $message['is_fallback'] ? ' bubble--fallback' : ''; ?>">
                                    <span class="visually-hidden"><?php echo $message['sender'] === 'user' ? esc_html__('Besucher:', 'madex-chatbot') : esc_html__('Assistent:', 'madex-chatbot'); ?></span>
                                    <span class="bubble__text"><?php echo nl2br(esc_html($message['content'])); ?></span>
                                    <span class="bubble__meta"><?php echo esc_html($this->time_only($message['created_at'])); ?><?php if ($message['is_fallback']) : ?> · <?php esc_html_e('Keine bestätigte Info', 'madex-chatbot'); ?><?php endif; ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ol>
                    <?php endif; ?>
                </section>
            </div>
            <?php
        });
    }

    private function page_appointments() {
        $status = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : '';
        $statuses = Madex_Business_Service::status_options();
        $status = array_key_exists($status, $statuses) ? $status : '';
        $search = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
        $page = isset($_GET['p']) ? max(1, absint($_GET['p'])) : 1;
        $ref = isset($_GET['ref']) ? sanitize_text_field(wp_unslash($_GET['ref'])) : '';
        $notice = isset($_GET['notice']) ? sanitize_key(wp_unslash($_GET['notice'])) : '';

        $list = Madex_Business_Service::list_appointments(array('status' => $status, 'search' => $search, 'page' => $page, 'per_page' => 20));
        $detail = $ref !== '' && preg_match('/^MDX-[A-Z0-9]+$/', $ref) ? Madex_Business_Service::get_appointment($ref) : null;
        if (is_wp_error($detail)) {
            $detail = null;
        }
        $counts = array();
        foreach ($statuses as $key => $label) {
            $counts[$key] = Madex_Business_Service::list_appointments(array('status' => $key, 'per_page' => 1))['total'];
        }
        $filters = array('status' => $status, 'q' => $search);

        $this->render_app_page('appointments', __('Terminanfragen', 'madex-chatbot'), function () use ($list, $detail, $status, $statuses, $counts, $search, $filters, $notice, $page) {
            ?>
            <header class="page-head">
                <div>
                    <h1 class="page-title" tabindex="-1"><?php esc_html_e('Terminanfragen', 'madex-chatbot'); ?></h1>
                    <p class="page-sub"><?php esc_html_e('Alle Anfragen sind Wunschtermine und werden persönlich bestätigt.', 'madex-chatbot'); ?></p>
                </div>
                <a class="btn btn--secondary" href="<?php echo esc_url(Madex_Portal_Auth::url('export.csv', array_filter(array('status' => $status)))); ?>"><?php echo $this->icon('download'); ?><?php esc_html_e('CSV exportieren', 'madex-chatbot'); ?></a>
            </header>
            <?php if ($notice === 'saved') : ?>
                <div class="notice notice--success" role="status" data-autodismiss><?php echo $this->icon('check'); ?><div><b><?php esc_html_e('Gespeichert.', 'madex-chatbot'); ?></b><span><?php esc_html_e('Die Anfrage wurde aktualisiert.', 'madex-chatbot'); ?></span></div></div>
            <?php elseif ($notice === 'resent') : ?>
                <div class="notice notice--success" role="status" data-autodismiss><?php echo $this->icon('check'); ?><div><b><?php esc_html_e('E-Mail gesendet.', 'madex-chatbot'); ?></b><span><?php esc_html_e('Die Benachrichtigung wurde erneut zugestellt.', 'madex-chatbot'); ?></span></div></div>
            <?php elseif ($notice === 'error') : ?>
                <div class="notice notice--error" role="alert"><?php echo $this->icon('x'); ?><div><b><?php esc_html_e('Aktion fehlgeschlagen.', 'madex-chatbot'); ?></b><span><?php esc_html_e('Bitte versuchen Sie es erneut. Bleibt der Fehler bestehen, informieren Sie die Administration.', 'madex-chatbot'); ?></span></div></div>
            <?php endif; ?>
            <div class="split<?php echo $detail ? ' has-detail' : ''; ?>">
                <section class="card card--flush split__list" aria-label="<?php esc_attr_e('Anfragenliste', 'madex-chatbot'); ?>">
                    <div class="list-toolbar">
                        <nav class="pills" aria-label="<?php esc_attr_e('Status filtern', 'madex-chatbot'); ?>">
                            <?php $this->pill(Madex_Portal_Auth::url('appointments', array_filter(array('q' => $search))), __('Alle', 'madex-chatbot'), $status === ''); ?>
                            <?php foreach ($statuses as $key => $label) : ?>
                                <?php $this->pill(Madex_Portal_Auth::url('appointments', array_filter(array('status' => $key, 'q' => $search))), $label . ($counts[$key] ? ' · ' . $counts[$key] : ''), $status === $key); ?>
                            <?php endforeach; ?>
                        </nav>
                        <?php $this->search_form('appointments', $search, __('Suchen nach Name, Firma, Referenz …', 'madex-chatbot'), array('status' => $status)); ?>
                    </div>
                    <?php if (empty($list['items'])) : ?>
                        <div class="empty"><?php echo $this->icon('calendar'); ?><b><?php esc_html_e('Keine Terminanfragen', 'madex-chatbot'); ?></b><p><?php esc_html_e('Neue Anfragen aus dem Chat erscheinen hier sofort.', 'madex-chatbot'); ?></p></div>
                    <?php else : ?>
                        <ul class="row-list">
                            <?php foreach ($list['items'] as $item) : $active = $detail && $detail['reference'] === $item['reference']; ?>
                                <li>
                                    <a class="row-link<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo esc_url(Madex_Portal_Auth::url('appointments', array_filter(array_merge($filters, array('ref' => $item['reference'], 'p' => $page > 1 ? $page : ''))))); ?>" <?php echo $active ? 'aria-current="true"' : ''; ?>>
                                        <span class="row-link__top">
                                            <b><?php echo esc_html($item['customer_name']); ?></b>
                                            <?php $this->status_tag($item['status']); ?>
                                            <time datetime="<?php echo esc_attr($this->iso($item['created_at'])); ?>"><?php echo esc_html($this->relative($item['created_at'])); ?></time>
                                        </span>
                                        <span class="row-link__meta"><?php echo esc_html(implode(' · ', array_filter(array($item['company'], Madex_Business_Service::service_label($item['service']), $this->preferred($item))))); ?><?php if ($item['email_status'] === 'failed') : ?> · <span class="text-error"><?php esc_html_e('E-Mail fehlgeschlagen', 'madex-chatbot'); ?></span><?php endif; ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php $this->pagination('appointments', $filters, $list); ?>
                    <?php endif; ?>
                </section>
                <section class="card split__detail" aria-label="<?php esc_attr_e('Anfragedetail', 'madex-chatbot'); ?>">
                    <?php if (!$detail) : ?>
                        <div class="empty"><?php echo $this->icon('arrow-left'); ?><b><?php esc_html_e('Anfrage auswählen', 'madex-chatbot'); ?></b><p><?php esc_html_e('Wählen Sie links eine Anfrage, um Kontaktdaten und Verlauf zu sehen.', 'madex-chatbot'); ?></p></div>
                    <?php else : $this->appointment_detail($detail, $statuses, $filters); endif; ?>
                </section>
            </div>
            <?php
        });
    }

    private function appointment_detail($detail, $statuses, $filters) {
        $next = array('new' => 'contacted', 'contacted' => 'confirmed', 'confirmed' => 'completed');
        $next_labels = array(
            'contacted' => __('Als kontaktiert markieren', 'madex-chatbot'),
            'confirmed' => __('Als bestätigt markieren', 'madex-chatbot'),
            'completed' => __('Als erledigt markieren', 'madex-chatbot'),
        );
        $ref = $detail['reference'];
        $token = Madex_Portal_Auth::form_token();
        ?>
        <a class="back-link" href="<?php echo esc_url(Madex_Portal_Auth::url('appointments', array_filter($filters))); ?>"><?php echo $this->icon('arrow-left'); ?><?php esc_html_e('Zurück zur Liste', 'madex-chatbot'); ?></a>
        <div class="detail-head">
            <div>
                <span class="mono-label"><?php echo esc_html($ref); ?></span>
                <h2 class="detail-title"><?php echo esc_html($detail['customer_name']); ?></h2>
                <p class="detail-sub"><?php echo esc_html(implode(' · ', array_filter(array($detail['company'], $detail['existing_client'] === 'yes' ? __('Bestehender Kunde', 'madex-chatbot') : __('Interessent', 'madex-chatbot'))))); ?></p>
            </div>
            <?php $this->status_tag($detail['status']); ?>
        </div>

        <?php if ($detail['email_status'] === 'failed') : ?>
            <div class="notice notice--error notice--action" role="alert">
                <?php echo $this->icon('x'); ?>
                <div><b><?php esc_html_e('Benachrichtigung nicht zugestellt.', 'madex-chatbot'); ?></b><span><?php esc_html_e('Die Anfrage ist gespeichert. Sie können die E-Mail erneut senden.', 'madex-chatbot'); ?></span></div>
                <form method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('appointments/resend')); ?>">
                    <input type="hidden" name="_token" value="<?php echo esc_attr($token); ?>">
                    <input type="hidden" name="ref" value="<?php echo esc_attr($ref); ?>">
                    <button type="submit" class="btn btn--danger-ghost btn--sm" data-submit-label="<?php esc_attr_e('Wird gesendet …', 'madex-chatbot'); ?>"><?php esc_html_e('Erneut senden', 'madex-chatbot'); ?></button>
                </form>
            </div>
        <?php endif; ?>

        <dl class="facts facts--grid">
            <div><dt><?php esc_html_e('E-Mail', 'madex-chatbot'); ?></dt><dd><a href="mailto:<?php echo esc_attr($detail['email']); ?>"><?php echo esc_html($detail['email']); ?></a></dd></div>
            <div><dt><?php esc_html_e('Telefon', 'madex-chatbot'); ?></dt><dd><?php if ($detail['phone'] !== '') : ?><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $detail['phone'])); ?>"><?php echo esc_html($detail['phone']); ?></a><?php else : ?>–<?php endif; ?></dd></div>
            <div><dt><?php esc_html_e('Interesse', 'madex-chatbot'); ?></dt><dd><?php echo esc_html(implode(' · ', array_filter(array(Madex_Business_Service::service_label($detail['service']), $detail['package_interest'])))); ?></dd></div>
            <div><dt><?php esc_html_e('Wunschtermin', 'madex-chatbot'); ?></dt><dd><?php echo esc_html($this->preferred($detail)); ?></dd></div>
            <div><dt><?php esc_html_e('Eingegangen', 'madex-chatbot'); ?></dt><dd><?php echo esc_html($this->datetime($detail['created_at'])); ?></dd></div>
            <div><dt><?php esc_html_e('E-Mail-Status', 'madex-chatbot'); ?></dt><dd><?php $this->email_tag($detail['email_status']); ?></dd></div>
        </dl>

        <?php if ($detail['message'] !== '') : ?><blockquote class="quote">„<?php echo nl2br(esc_html($detail['message'])); ?>“</blockquote><?php endif; ?>

        <form method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('appointments/update')); ?>" class="stack" data-dirty-form>
            <input type="hidden" name="_token" value="<?php echo esc_attr($token); ?>">
            <input type="hidden" name="ref" value="<?php echo esc_attr($ref); ?>">
            <label class="field">
                <span class="field__label"><?php esc_html_e('Interne Notiz', 'madex-chatbot'); ?> <small><?php esc_html_e('· nur im Team sichtbar', 'madex-chatbot'); ?></small></span>
                <textarea class="input textarea" name="internal_notes" rows="3" maxlength="5000"><?php echo esc_textarea($detail['internal_notes']); ?></textarea>
            </label>
            <div class="btn-row btn-row--sticky">
                <?php if (isset($next[$detail['status']])) : ?>
                    <button type="submit" name="status" value="<?php echo esc_attr($next[$detail['status']]); ?>" class="btn btn--primary btn--grow"><?php echo esc_html($next_labels[$next[$detail['status']]]); ?></button>
                <?php endif; ?>
                <label class="select-wrap">
                    <span class="visually-hidden"><?php esc_html_e('Status ändern', 'madex-chatbot'); ?></span>
                    <select class="input select" name="status_select" data-status-select>
                        <?php foreach ($statuses as $key => $label) : ?>
                            <option value="<?php echo esc_attr($key); ?>" <?php selected($detail['status'], $key); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="submit" name="status" value="__select" class="btn btn--secondary"><?php esc_html_e('Speichern', 'madex-chatbot'); ?></button>
            </div>
        </form>

        <div class="timeline">
            <h3 class="timeline__title"><?php esc_html_e('Verlauf', 'madex-chatbot'); ?></h3>
            <ol>
                <?php foreach (array_reverse($detail['events']) as $event) : ?>
                    <li><time datetime="<?php echo esc_attr($this->iso($event['created_at'])); ?>"><?php echo esc_html($this->datetime($event['created_at'], 'd.m. H:i')); ?></time><span><?php echo esc_html($this->event_label($event, $statuses)); ?></span></li>
                <?php endforeach; ?>
            </ol>
        </div>
        <?php
    }

    private function page_reports() {
        $range = $this->range_param(array(7, 30, 90, 365), 30);
        $report = Madex_Business_Service::get_report_series($range);
        $stats = Madex_Business_Service::get_dashboard_stats($range);
        $total_chats = array_sum(wp_list_pluck($report['series'], 'conversations'));
        $total_appts = array_sum(wp_list_pluck($report['series'], 'appointments'));
        $rate = $total_chats > 0 ? round(($total_appts / $total_chats) * 100, 1) : 0;

        $this->render_app_page('reports', __('Berichte', 'madex-chatbot'), function () use ($range, $report, $stats, $total_chats, $total_appts, $rate) {
            $statuses = Madex_Business_Service::status_options();
            $status_rows = array();
            foreach ($report['appointment_statuses'] as $row) {
                $status_rows[] = array('label' => isset($statuses[$row['label']]) ? $statuses[$row['label']] : $row['label'], 'total' => (int) $row['total']);
            }
            $package_rows = array();
            foreach ($report['packages'] as $row) {
                $package_rows[] = array('label' => $row['label'], 'total' => (int) $row['total']);
            }
            $clients = 0;
            $prospects = 0;
            foreach ($report['session_types'] as $row) {
                if ($row['label'] === 'client') {
                    $clients = (int) $row['total'];
                } elseif ($row['label'] === 'prospect') {
                    $prospects = (int) $row['total'];
                }
            }
            ?>
            <header class="page-head">
                <div>
                    <h1 class="page-title" tabindex="-1"><?php esc_html_e('Berichte', 'madex-chatbot'); ?></h1>
                    <p class="page-sub"><?php echo esc_html(sprintf(__('Zeitraum: letzte %d Tage', 'madex-chatbot'), $range)); ?></p>
                </div>
                <div class="page-head__actions">
                    <?php $this->segmented('reports', 'range', array(7 => __('7 Tage', 'madex-chatbot'), 30 => __('30 Tage', 'madex-chatbot'), 90 => __('90 Tage', 'madex-chatbot'), 365 => __('12 Monate', 'madex-chatbot')), $range); ?>
                    <a class="btn btn--secondary" href="<?php echo esc_url(Madex_Portal_Auth::url('export.csv', array('range' => $range))); ?>"><?php echo $this->icon('download'); ?><?php esc_html_e('CSV', 'madex-chatbot'); ?></a>
                    <button type="button" class="btn btn--secondary" data-print><?php echo $this->icon('print'); ?><?php esc_html_e('PDF / Drucken', 'madex-chatbot'); ?></button>
                </div>
            </header>
            <section class="kpi-grid kpi-grid--four">
                <?php
                $this->kpi(__('Gespräche', 'madex-chatbot'), $total_chats, sprintf(__('letzte %d Tage', 'madex-chatbot'), $range));
                $this->kpi(__('Terminanfragen', 'madex-chatbot'), $total_appts, sprintf(__('letzte %d Tage', 'madex-chatbot'), $range));
                $this->kpi(__('Anfragequote', 'madex-chatbot'), number_format_i18n($rate, 1) . ' %', __('Anfragen pro Gespräch', 'madex-chatbot'));
                $this->kpi(__('Ohne bestätigte Info', 'madex-chatbot'), $stats['unresolved'], __('Gespräche mit Weiterleitung', 'madex-chatbot'));
                ?>
            </section>
            <section class="card">
                <div class="card__head"><h2 class="card__title"><?php esc_html_e('Chat- und Anfragetrend', 'madex-chatbot'); ?></h2><?php $this->chart_legend(); ?></div>
                <?php $this->line_chart($report['series']); ?>
            </section>
            <div class="grid grid--two">
                <section class="card"><h2 class="card__title"><?php esc_html_e('Häufige Kundeninteressen', 'madex-chatbot'); ?></h2><?php $this->bar_list($this->topic_rows($report), __('Keine Daten im Zeitraum.', 'madex-chatbot')); ?></section>
                <section class="card"><h2 class="card__title"><?php esc_html_e('Paketinteresse', 'madex-chatbot'); ?></h2><?php $this->bar_list($package_rows, __('Noch keine Paketanfragen im Zeitraum.', 'madex-chatbot')); ?></section>
                <section class="card"><h2 class="card__title"><?php esc_html_e('Status der Terminanfragen', 'madex-chatbot'); ?></h2><?php $this->bar_list($status_rows, __('Keine Anfragen im Zeitraum.', 'madex-chatbot')); ?></section>
                <section class="card"><h2 class="card__title"><?php esc_html_e('Kunden vs. Interessenten', 'madex-chatbot'); ?></h2><?php $this->donut($clients, $prospects); ?></section>
            </div>
            <?php
        });
    }

    private function page_live() {
        $live = Madex_Business_Service::get_live_activity();
        $this->render_app_page('live', __('Live-Aktivität', 'madex-chatbot'), function () use ($live) {
            ?>
            <header class="page-head">
                <div>
                    <h1 class="page-title" tabindex="-1"><?php esc_html_e('Live-Aktivität', 'madex-chatbot'); ?></h1>
                    <p class="page-sub"><span class="pulse-label"><span class="pulse" aria-hidden="true"></span><?php esc_html_e('Aktualisiert automatisch alle 15 Sekunden', 'madex-chatbot'); ?></span> · <span data-live-stamp><?php esc_html_e('gerade aktualisiert', 'madex-chatbot'); ?></span></p>
                </div>
            </header>
            <div class="grid grid--live">
                <section class="card card--live card--tall" aria-live="polite">
                    <canvas class="globe" data-globe aria-hidden="true"></canvas>
                    <h2 class="card__title"><?php esc_html_e('Aktive Gespräche', 'madex-chatbot'); ?></h2>
                    <p class="live-count live-count--xl"><b data-live-count><?php echo esc_html($live['active_count']); ?></b><span><?php esc_html_e('gerade jetzt', 'madex-chatbot'); ?></span></p>
                    <ul class="live-chips live-chips--stack" data-live-list>
                        <?php foreach ($live['active'] as $item) : ?>
                            <li><a href="<?php echo esc_url(Madex_Portal_Auth::url('chats', array('id' => $item['public_id']))); ?>"><span class="dot" aria-hidden="true"></span><?php echo esc_html($this->live_chip_text($item)); ?></a></li>
                        <?php endforeach; ?>
                        <?php if (empty($live['active'])) : ?><li class="live-chips__empty"><?php esc_html_e('Gerade keine aktiven Gespräche.', 'madex-chatbot'); ?></li><?php endif; ?>
                    </ul>
                    <p class="privacy-note"><?php echo $this->icon('shield'); ?><?php esc_html_e('Besucher werden nur als Nummer angezeigt – ohne IP-Adresse oder Standort.', 'madex-chatbot'); ?></p>
                </section>
                <section class="card">
                    <h2 class="card__title"><?php esc_html_e('Neueste Terminanfragen', 'madex-chatbot'); ?></h2>
                    <ul class="event-list" data-live-events>
                        <?php foreach ($live['events'] as $event) : ?>
                            <li><a href="<?php echo esc_url(Madex_Portal_Auth::url('appointments', array('ref' => $event['reference']))); ?>"><span class="event-list__icon"><?php echo $this->icon('calendar'); ?></span><span><b><?php echo esc_html($event['label']); ?></b><small><?php echo esc_html($event['detail'] . ' · ' . $this->relative($event['created_at'])); ?></small></span></a></li>
                        <?php endforeach; ?>
                        <?php if (empty($live['events'])) : ?><li class="live-chips__empty"><?php esc_html_e('Noch keine Terminanfragen.', 'madex-chatbot'); ?></li><?php endif; ?>
                    </ul>
                </section>
            </div>
            <?php
        });
    }

    /* ==================================================================
     * Actions, API and export
     * ================================================================== */

    private function handle_appointment_update() {
        $ref = isset($_POST['ref']) ? sanitize_text_field(wp_unslash($_POST['ref'])) : '';
        $appointment = Madex_Business_Service::get_appointment($ref);
        if (is_wp_error($appointment)) {
            $this->redirect('appointments', array('notice' => 'error'));
        }

        $status = isset($_POST['status']) ? sanitize_key(wp_unslash($_POST['status'])) : '';
        if ($status === '__select' || $status === '') {
            $status = isset($_POST['status_select']) ? sanitize_key(wp_unslash($_POST['status_select'])) : $appointment['status'];
        }
        $changes = array(
            // The business service unslashes and sanitises the raw value.
            'internal_notes' => isset($_POST['internal_notes']) ? $_POST['internal_notes'] : $appointment['internal_notes'],
        );
        if (array_key_exists($status, Madex_Business_Service::status_options())) {
            $changes['status'] = $status;
        }

        $result = Madex_Business_Service::update_appointment((int) $appointment['id'], $changes, (int) $this->session['user_id']);
        $this->redirect('appointments', array('ref' => $appointment['reference'], 'notice' => is_wp_error($result) ? 'error' : 'saved'));
    }

    private function handle_appointment_resend() {
        $ref = isset($_POST['ref']) ? sanitize_text_field(wp_unslash($_POST['ref'])) : '';
        $appointment = Madex_Business_Service::get_appointment($ref);
        if (is_wp_error($appointment)) {
            $this->redirect('appointments', array('notice' => 'error'));
        }
        $result = Madex_Business_Service::retry_appointment_email((int) $appointment['id'], (int) $this->session['user_id']);
        $this->redirect('appointments', array('ref' => $appointment['reference'], 'notice' => is_wp_error($result) ? 'error' : 'resent'));
    }

    private function api_live() {
        $live = Madex_Business_Service::get_live_activity();
        $stats = Madex_Business_Service::get_dashboard_stats(1);
        $active = array();
        foreach ($live['active'] as $item) {
            $active[] = array(
                'text' => $this->live_chip_text($item),
                'url' => Madex_Portal_Auth::url('chats', array('id' => $item['public_id'])),
            );
        }
        $events = array();
        foreach ($live['events'] as $event) {
            $events[] = array(
                'title' => $event['label'],
                'text' => $event['detail'] . ' · ' . $this->relative($event['created_at']),
                'url' => Madex_Portal_Auth::url('appointments', array('ref' => $event['reference'])),
            );
        }
        $this->json(array(
            'active_count' => $live['active_count'],
            'active' => $active,
            'events' => $events,
            'new_appointments' => $stats['new_appointments'],
            'stamp' => wp_date('H:i:s'),
        ));
    }

    private function export_csv() {
        $range = isset($_GET['range']) ? absint($_GET['range']) : 0;
        $status = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : '';
        $args = array();
        if ($range > 0) {
            $args['date_from'] = gmdate('Y-m-d', current_time('timestamp') - (min(366, $range) - 1) * DAY_IN_SECONDS);
        }
        if (array_key_exists($status, Madex_Business_Service::status_options())) {
            $args['status'] = $status;
        }
        $rows = Madex_Business_Service::export_appointments_csv_rows($args);
        $rows[0] = array('Referenz', 'Status', 'Eingegangen', 'Name', 'Unternehmen', 'E-Mail', 'Telefon', 'Kundenstatus', 'Leistung', 'Paket', 'Wunschdatum', 'Zeitfenster', 'E-Mail-Status', 'Anliegen');

        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="madex-terminanfragen-' . wp_date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        foreach ($rows as $row) {
            fputcsv($out, $row, ';');
        }
        fclose($out);
        exit;
    }

    private function serve_asset($name) {
        if (!isset(self::$assets[$name])) {
            status_header(404);
            exit;
        }
        $file = MADEX_CHATBOT_PLUGIN_DIR . self::$assets[$name][0];
        if (!is_readable($file)) {
            status_header(404);
            exit;
        }
        header_remove('X-Powered-By');
        header('Content-Type: ' . self::$assets[$name][1]);
        header('Content-Length: ' . filesize($file));
        header('Cache-Control: public, max-age=86400');
        header('X-Content-Type-Options: nosniff');
        header('Cross-Origin-Resource-Policy: same-origin');
        readfile($file);
        exit;
    }

    /* ==================================================================
     * Layout
     * ================================================================== */

    /**
     * Link the plugin's real static files. Many hosts (nginx, LiteSpeed,
     * caching/CDN layers) answer *.css/*.js/*.png requests themselves and
     * never pass a virtual path like /chatadm/assets/portal.css to
     * WordPress, which left the portal unstyled. A root-relative URL keeps
     * the files same-origin for the Content-Security-Policy.
     */
    private function asset_url($name) {
        $relative = self::$assets[$name][0];
        $file = MADEX_CHATBOT_PLUGIN_DIR . $relative;
        $version = file_exists($file) ? substr(md5((string) filemtime($file) . MADEX_CHATBOT_VERSION), 0, 8) : MADEX_CHATBOT_VERSION;
        return add_query_arg('v', $version, wp_make_link_relative(MADEX_CHATBOT_PLUGIN_URL . $relative));
    }

    private function document_head($title) {
        ?><!doctype html>
<html lang="de-CH">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="same-origin">
<meta name="color-scheme" content="light">
<meta name="theme-color" content="#FCFCFC">
<title><?php echo esc_html($title . ' · Madex Management'); ?></title>
<link rel="icon" type="image/png" href="<?php echo esc_url($this->asset_url('favicon.png')); ?>">
<link rel="stylesheet" href="<?php echo esc_url($this->asset_url('portal.css')); ?>">
<?php if ($this->needs_qr) : ?><script src="<?php echo esc_url($this->asset_url('qrcode.js')); ?>" defer></script><?php endif; ?>
<script src="<?php echo esc_url($this->asset_url('portal.js')); ?>" defer></script>
</head>
<?php
    }

    private function render_auth_page($title, $content) {
        $this->document_head($title);
        ?>
<body class="mdx mdx--auth">
<main class="auth">
    <aside class="auth__visual" aria-hidden="true">
        <canvas class="crystal" data-crystal></canvas>
        <img class="auth__logo" src="<?php echo esc_url($this->asset_url('logo.png')); ?>" alt="" width="176" height="38">
        <div class="auth__claim">
            <b><?php esc_html_e('Madex Management', 'madex-chatbot'); ?></b>
            <span><?php esc_html_e('Gespräche und Terminanfragen auf einen Blick.', 'madex-chatbot'); ?></span>
        </div>
    </aside>
    <section class="auth__panel">
        <img class="auth__logo auth__logo--mobile" src="<?php echo esc_url($this->asset_url('logo.png')); ?>" alt="Madex IT Solutions" width="150" height="32">
        <?php call_user_func($content); ?>
        <p class="auth__foot"><?php esc_html_e('Geschützter Bereich · Zugriffe werden protokolliert.', 'madex-chatbot'); ?></p>
    </section>
</main>
</body>
</html>
        <?php
    }

    private function render_app_page($active, $title, $content) {
        $new_count = Madex_Business_Service::list_appointments(array('status' => 'new', 'per_page' => 1))['total'];
        $live_count = Madex_Business_Service::list_conversations(array('state' => 'live', 'per_page' => 1))['total'];
        $name = $this->user ? $this->user->display_name : '';
        $initials = $this->initials($name);
        $token = Madex_Portal_Auth::form_token();
        $nav = array(
            'overview' => array(__('Übersicht', 'madex-chatbot'), 'grid', 0),
            'chats' => array(__('Chats', 'madex-chatbot'), 'chat', $live_count),
            'appointments' => array(__('Terminanfragen', 'madex-chatbot'), 'calendar', $new_count),
            'reports' => array(__('Berichte', 'madex-chatbot'), 'bars', 0),
            'live' => array(__('Live-Aktivität', 'madex-chatbot'), 'radar', 0),
        );

        $this->document_head($title);
        ?>
<body class="mdx mdx--app">
<a class="skip-link" href="#main"><?php esc_html_e('Zum Inhalt springen', 'madex-chatbot'); ?></a>
<div class="app" data-app data-idle="<?php echo esc_attr(Madex_Portal_Auth::idle_ttl()); ?>" data-expired-url="<?php echo esc_url(Madex_Portal_Auth::url('login', array('state' => 'expired'))); ?>" data-live-url="<?php echo esc_url(Madex_Portal_Auth::url('api/live')); ?>" data-page="<?php echo esc_attr($active); ?>">
    <aside class="sidebar" aria-label="<?php esc_attr_e('Hauptnavigation', 'madex-chatbot'); ?>">
        <a class="sidebar__brand" href="<?php echo esc_url(Madex_Portal_Auth::url('overview')); ?>"><img src="<?php echo esc_url($this->asset_url('logo.png')); ?>" alt="Madex IT Solutions" width="150" height="32"></a>
        <nav class="nav">
            <?php foreach ($nav as $key => $item) : ?>
                <a class="nav__item<?php echo $key === $active ? ' is-active' : ''; ?>" href="<?php echo esc_url(Madex_Portal_Auth::url($key)); ?>" <?php echo $key === $active ? 'aria-current="page"' : ''; ?>>
                    <?php echo $this->icon($item[1]); ?><span class="nav__label"><?php echo esc_html($item[0]); ?></span>
                    <?php if ($item[2] > 0) : ?><span class="nav__badge<?php echo $key === 'chats' ? ' nav__badge--live' : ''; ?>" <?php echo $key === 'appointments' ? 'data-nav-new' : ''; ?>><?php echo esc_html($item[2]); ?></span><?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="user-card">
            <span class="avatar" aria-hidden="true"><?php echo esc_html($initials); ?></span>
            <span class="user-card__text"><b><?php echo esc_html($name); ?></b>
                <form method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('logout')); ?>">
                    <input type="hidden" name="_token" value="<?php echo esc_attr($token); ?>">
                    <button type="submit" class="user-card__logout"><?php esc_html_e('Abmelden', 'madex-chatbot'); ?></button>
                </form>
            </span>
        </div>
    </aside>

    <header class="topbar">
        <a href="<?php echo esc_url(Madex_Portal_Auth::url('overview')); ?>"><img src="<?php echo esc_url($this->asset_url('logo.png')); ?>" alt="Madex IT Solutions" width="122" height="26"></a>
        <span class="avatar avatar--sm" aria-hidden="true"><?php echo esc_html($initials); ?></span>
    </header>

    <main id="main" class="main" tabindex="-1">
        <?php call_user_func($content); ?>
    </main>

    <nav class="bottom-nav" aria-label="<?php esc_attr_e('Navigation', 'madex-chatbot'); ?>">
        <?php foreach (array('overview' => array(__('Übersicht', 'madex-chatbot'), 'grid'), 'chats' => array(__('Chats', 'madex-chatbot'), 'chat'), 'appointments' => array(__('Termine', 'madex-chatbot'), 'calendar')) as $key => $item) : ?>
            <a class="bottom-nav__item<?php echo $key === $active ? ' is-active' : ''; ?>" href="<?php echo esc_url(Madex_Portal_Auth::url($key)); ?>" <?php echo $key === $active ? 'aria-current="page"' : ''; ?>><?php echo $this->icon($item[1]); ?><span><?php echo esc_html($item[0]); ?></span><?php if ($key === 'appointments' && $new_count > 0) : ?><i class="bottom-nav__dot" aria-hidden="true"></i><span class="visually-hidden"><?php echo esc_html(sprintf(__('%d neu', 'madex-chatbot'), $new_count)); ?></span><?php endif; ?></a>
        <?php endforeach; ?>
        <button type="button" class="bottom-nav__item<?php echo in_array($active, array('reports', 'live'), true) ? ' is-active' : ''; ?>" data-more-toggle aria-expanded="false" aria-controls="more-sheet"><?php echo $this->icon('menu'); ?><span><?php esc_html_e('Mehr', 'madex-chatbot'); ?></span></button>
    </nav>
    <div class="sheet" id="more-sheet" hidden data-more-sheet>
        <div class="sheet__panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Weitere Bereiche', 'madex-chatbot'); ?>">
            <a class="sheet__item" href="<?php echo esc_url(Madex_Portal_Auth::url('reports')); ?>"><?php echo $this->icon('bars'); ?><?php esc_html_e('Berichte', 'madex-chatbot'); ?></a>
            <a class="sheet__item" href="<?php echo esc_url(Madex_Portal_Auth::url('live')); ?>"><?php echo $this->icon('radar'); ?><?php esc_html_e('Live-Aktivität', 'madex-chatbot'); ?></a>
            <form method="post" action="<?php echo esc_url(Madex_Portal_Auth::url('logout')); ?>">
                <input type="hidden" name="_token" value="<?php echo esc_attr($token); ?>">
                <button type="submit" class="sheet__item sheet__item--danger"><?php echo $this->icon('logout'); ?><?php esc_html_e('Abmelden', 'madex-chatbot'); ?></button>
            </form>
            <button type="button" class="btn btn--secondary btn--block" data-more-close><?php esc_html_e('Schliessen', 'madex-chatbot'); ?></button>
        </div>
    </div>

    <div class="session-dialog" hidden data-session-dialog role="alertdialog" aria-modal="true" aria-labelledby="session-dialog-title">
        <div class="session-dialog__panel">
            <span class="state-card__icon state-card__icon--neutral"><?php echo $this->icon('clock'); ?></span>
            <h2 id="session-dialog-title"><?php esc_html_e('Sitzung läuft bald ab', 'madex-chatbot'); ?></h2>
            <p><?php esc_html_e('Aus Sicherheitsgründen werden Sie bei Inaktivität automatisch abgemeldet.', 'madex-chatbot'); ?> <span data-session-countdown></span></p>
            <button type="button" class="btn btn--primary btn--block" data-session-extend><?php esc_html_e('Angemeldet bleiben', 'madex-chatbot'); ?></button>
        </div>
    </div>
</div>
</body>
</html>
        <?php
    }

    private function render_error_page($status, $title, $body) {
        status_header($status);
        $this->render_auth_page($title, function () use ($title, $body) {
            $this->state_card('x', 'error', $title, $body, '', __('Zum Portal', 'madex-chatbot'), Madex_Portal_Auth::url(''));
        });
        exit;
    }

    /* ==================================================================
     * Components
     * ================================================================== */

    private function kpi($label, $value, $hint, $tone = '') {
        ?>
        <article class="kpi<?php echo $tone !== '' ? ' kpi--' . esc_attr($tone) : ''; ?>">
            <span class="kpi__label"><?php echo esc_html($label); ?></span>
            <span class="kpi__value" <?php echo $tone === 'live' ? 'data-live-count' : ''; ?>><?php echo esc_html(is_numeric($value) ? number_format_i18n((float) $value) : $value); ?></span>
            <span class="kpi__hint"><?php echo esc_html($hint); ?></span>
        </article>
        <?php
    }

    private function segmented($route, $param, $options, $current) {
        ?>
        <nav class="segmented" aria-label="<?php esc_attr_e('Zeitraum', 'madex-chatbot'); ?>">
            <?php foreach ($options as $value => $label) : ?>
                <a class="segmented__item<?php echo (int) $value === (int) $current ? ' is-active' : ''; ?>" href="<?php echo esc_url(Madex_Portal_Auth::url($route, array($param => $value))); ?>" <?php echo (int) $value === (int) $current ? 'aria-current="true"' : ''; ?>><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>
        <?php
    }

    private function pill($url, $label, $active) {
        printf(
            '<a class="pill%1$s" href="%2$s"%3$s>%4$s</a>',
            $active ? ' is-active' : '',
            esc_url($url),
            $active ? ' aria-current="true"' : '',
            esc_html($label)
        );
    }

    private function search_form($route, $value, $placeholder, $hidden) {
        ?>
        <form class="search" method="get" action="<?php echo esc_url(Madex_Portal_Auth::url($route)); ?>" role="search">
            <?php foreach (array_filter($hidden) as $key => $val) : ?><input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($val); ?>"><?php endforeach; ?>
            <label class="visually-hidden" for="search-<?php echo esc_attr($route); ?>"><?php esc_html_e('Suchen', 'madex-chatbot'); ?></label>
            <?php echo $this->icon('search'); ?>
            <input class="input search__input" id="search-<?php echo esc_attr($route); ?>" type="search" name="q" value="<?php echo esc_attr($value); ?>" placeholder="<?php echo esc_attr($placeholder); ?>" maxlength="100">
        </form>
        <?php
    }

    private function pagination($route, $filters, $result) {
        $pages = (int) ceil($result['total'] / max(1, $result['per_page']));
        if ($pages <= 1) {
            return;
        }
        $page = (int) $result['page'];
        ?>
        <nav class="pager" aria-label="<?php esc_attr_e('Seiten', 'madex-chatbot'); ?>">
            <?php if ($page > 1) : ?><a class="btn btn--ghost btn--sm" href="<?php echo esc_url(Madex_Portal_Auth::url($route, array_filter(array_merge($filters, array('p' => $page - 1))))); ?>">← <?php esc_html_e('Zurück', 'madex-chatbot'); ?></a><?php endif; ?>
            <span><?php echo esc_html(sprintf(__('Seite %1$d von %2$d', 'madex-chatbot'), $page, $pages)); ?></span>
            <?php if ($page < $pages) : ?><a class="btn btn--ghost btn--sm" href="<?php echo esc_url(Madex_Portal_Auth::url($route, array_filter(array_merge($filters, array('p' => $page + 1))))); ?>"><?php esc_html_e('Weiter', 'madex-chatbot'); ?> →</a><?php endif; ?>
        </nav>
        <?php
    }

    private function status_tag($status) {
        $map = array(
            'new' => array('new', '●'),
            'contacted' => array('warning', '◷'),
            'confirmed' => array('success', '✓'),
            'completed' => array('success', '✓'),
            'cancelled' => array('muted', '—'),
        );
        $labels = Madex_Business_Service::status_options();
        $tone = isset($map[$status]) ? $map[$status] : array('muted', '•');
        printf('<span class="tag tag--%1$s"><span aria-hidden="true">%2$s</span> %3$s</span>', esc_attr($tone[0]), esc_html($tone[1]), esc_html(isset($labels[$status]) ? $labels[$status] : $status));
    }

    private function email_tag($status) {
        $map = array(
            'sent' => array('success', '✓', __('Zugestellt', 'madex-chatbot')),
            'failed' => array('error', '✕', __('Fehlgeschlagen', 'madex-chatbot')),
            'pending' => array('muted', '◌', __('Ausstehend', 'madex-chatbot')),
        );
        $tone = isset($map[$status]) ? $map[$status] : $map['pending'];
        printf('<span class="tag tag--%1$s"><span aria-hidden="true">%2$s</span> %3$s</span>', esc_attr($tone[0]), esc_html($tone[1]), esc_html($tone[2]));
    }

    private function appointment_table($items) {
        if (empty($items)) {
            echo '<div class="empty">' . $this->icon('calendar') . '<b>' . esc_html__('Noch keine Terminanfragen', 'madex-chatbot') . '</b><p>' . esc_html__('Neue Anfragen aus dem Chat erscheinen hier sofort.', 'madex-chatbot') . '</p></div>';
            return;
        }
        ?>
        <div class="table" role="table" aria-label="<?php esc_attr_e('Neueste Terminanfragen', 'madex-chatbot'); ?>">
            <div class="table__row table__row--head" role="row">
                <span role="columnheader"><?php esc_html_e('Kunde', 'madex-chatbot'); ?></span>
                <span role="columnheader"><?php esc_html_e('Typ', 'madex-chatbot'); ?></span>
                <span role="columnheader"><?php esc_html_e('Interesse', 'madex-chatbot'); ?></span>
                <span role="columnheader"><?php esc_html_e('Wunschtermin', 'madex-chatbot'); ?></span>
                <span role="columnheader"><?php esc_html_e('E-Mail', 'madex-chatbot'); ?></span>
                <span role="columnheader"><?php esc_html_e('Status', 'madex-chatbot'); ?></span>
            </div>
            <?php foreach ($items as $item) : ?>
                <a class="table__row" role="row" href="<?php echo esc_url(Madex_Portal_Auth::url('appointments', array('ref' => $item['reference']))); ?>">
                    <span role="cell" class="table__primary"><b><?php echo esc_html($item['customer_name']); ?></b><small><?php echo esc_html($item['company'] ?: $item['reference']); ?></small></span>
                    <span role="cell" data-label="<?php esc_attr_e('Typ', 'madex-chatbot'); ?>"><?php echo esc_html($item['existing_client'] === 'yes' ? __('Kunde', 'madex-chatbot') : __('Interessent', 'madex-chatbot')); ?></span>
                    <span role="cell" data-label="<?php esc_attr_e('Interesse', 'madex-chatbot'); ?>"><?php echo esc_html(Madex_Business_Service::service_label($item['service'])); ?></span>
                    <span role="cell" data-label="<?php esc_attr_e('Wunschtermin', 'madex-chatbot'); ?>"><?php echo esc_html($this->preferred($item, true)); ?></span>
                    <span role="cell" data-label="<?php esc_attr_e('E-Mail', 'madex-chatbot'); ?>"><?php $this->email_tag($item['email_status']); ?></span>
                    <span role="cell" class="table__status"><?php $this->status_tag($item['status']); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
        <?php
    }

    private function chart_legend() {
        ?>
        <ul class="legend" aria-hidden="true">
            <li><i class="legend__swatch legend__swatch--chats"></i><?php esc_html_e('Gespräche', 'madex-chatbot'); ?></li>
            <li><i class="legend__swatch legend__swatch--appts"></i><?php esc_html_e('Anfragen', 'madex-chatbot'); ?></li>
        </ul>
        <?php
    }

    private function line_chart($series) {
        $w = 640;
        $h = 200;
        $top = 12;
        $bottom = 176;
        $count = count($series);
        $max = 1;
        foreach ($series as $point) {
            $max = max($max, (int) $point['conversations'], (int) $point['appointments']);
        }
        $max = (int) (ceil($max / 4) * 4);
        $x = function ($i) use ($count, $w) {
            return $count > 1 ? round($i / ($count - 1) * $w, 1) : $w / 2;
        };
        $y = function ($v) use ($max, $top, $bottom) {
            return round($bottom - ($v / $max) * ($bottom - $top), 1);
        };
        $conv = array();
        $appt = array();
        foreach (array_values($series) as $i => $point) {
            $conv[] = $x($i) . ',' . $y((int) $point['conversations']);
            $appt[] = $x($i) . ',' . $y((int) $point['appointments']);
        }
        $area = 'M0,' . $bottom . ' L' . implode(' L', $conv) . ' L' . $w . ',' . $bottom . ' Z';
        $total_c = array_sum(wp_list_pluck($series, 'conversations'));
        $total_a = array_sum(wp_list_pluck($series, 'appointments'));
        $ticks = $count > 1 ? array_unique(array(0, (int) floor(($count - 1) / 3), (int) floor(2 * ($count - 1) / 3), $count - 1)) : array(0);
        ?>
        <figure class="chart">
            <svg viewBox="0 0 <?php echo (int) $w; ?> <?php echo (int) $h; ?>" preserveAspectRatio="none" role="img" aria-label="<?php echo esc_attr(sprintf(__('%1$d Gespräche und %2$d Terminanfragen in %3$d Tagen', 'madex-chatbot'), $total_c, $total_a, $count)); ?>">
                <?php foreach (array(0.25, 0.5, 0.75, 1) as $f) : $gy = round($bottom - $f * ($bottom - $top), 1); ?>
                    <line class="chart__grid" x1="0" x2="<?php echo (int) $w; ?>" y1="<?php echo esc_attr($gy); ?>" y2="<?php echo esc_attr($gy); ?>"></line>
                <?php endforeach; ?>
                <line class="chart__axis" x1="0" x2="<?php echo (int) $w; ?>" y1="<?php echo (int) $bottom; ?>" y2="<?php echo (int) $bottom; ?>"></line>
                <path class="chart__area" d="<?php echo esc_attr($area); ?>"></path>
                <polyline class="chart__line chart__line--chats" points="<?php echo esc_attr(implode(' ', $conv)); ?>" vector-effect="non-scaling-stroke"></polyline>
                <polyline class="chart__line chart__line--appts" points="<?php echo esc_attr(implode(' ', $appt)); ?>" vector-effect="non-scaling-stroke"></polyline>
            </svg>
            <div class="chart__y" aria-hidden="true"><span><?php echo esc_html($max); ?></span><span><?php echo esc_html($max / 2); ?></span><span>0</span></div>
            <figcaption class="chart__x" aria-hidden="true">
                <?php foreach ($ticks as $i) : ?><span><?php echo esc_html(gmdate('d.m.', $this->ts($series[$i]['date'] . ' 12:00:00'))); ?></span><?php endforeach; ?>
            </figcaption>
            <?php // Tables ignore overflow clipping, so the screen-reader copy is wrapped in a clipped block; otherwise its rows extend the page height. ?>
            <div class="visually-hidden"><table>
                <caption><?php esc_html_e('Gespräche und Terminanfragen pro Tag', 'madex-chatbot'); ?></caption>
                <thead><tr><th scope="col"><?php esc_html_e('Datum', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Gespräche', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Anfragen', 'madex-chatbot'); ?></th></tr></thead>
                <tbody><?php foreach ($series as $point) : ?><tr><td><?php echo esc_html($point['date']); ?></td><td><?php echo (int) $point['conversations']; ?></td><td><?php echo (int) $point['appointments']; ?></td></tr><?php endforeach; ?></tbody>
            </table></div>
        </figure>
        <?php
    }

    private function bar_list($rows, $empty_text) {
        $rows = array_values(array_filter($rows, function ($row) { return (int) $row['total'] > 0; }));
        if (empty($rows)) {
            echo '<p class="empty empty--inline">' . esc_html($empty_text) . '</p>';
            return;
        }
        $max = max(array_map(function ($row) { return (int) $row['total']; }, $rows));
        echo '<ul class="bars">';
        foreach (array_slice($rows, 0, 6) as $row) {
            $pct = $max > 0 ? round(((int) $row['total'] / $max) * 100, 1) : 0;
            printf(
                '<li><span class="bars__label"><span>%1$s</span><b>%2$s</b></span><svg class="bars__track" viewBox="0 0 100 6" preserveAspectRatio="none" aria-hidden="true"><rect class="bars__bg" width="100" height="6" rx="1"></rect><rect class="bars__fill" width="%3$s" height="6" rx="1"></rect></svg></li>',
                esc_html($row['label']),
                esc_html(number_format_i18n((int) $row['total'])),
                esc_attr(max(2, $pct))
            );
        }
        echo '</ul>';
    }

    private function donut($clients, $prospects) {
        $total = (int) $clients + (int) $prospects;
        if ($total === 0) {
            echo '<p class="empty empty--inline">' . esc_html__('Noch keine Angaben im Zeitraum.', 'madex-chatbot') . '</p>';
            return;
        }
        $pct = round(($clients / $total) * 100);
        ?>
        <div class="donut">
            <svg viewBox="0 0 42 42" role="img" aria-label="<?php echo esc_attr(sprintf(__('%1$d %% bestehende Kunden, %2$d %% Interessenten', 'madex-chatbot'), $pct, 100 - $pct)); ?>">
                <circle class="donut__prospects" cx="21" cy="21" r="15.915" fill="none" stroke-width="3.5"></circle>
                <circle class="donut__clients" cx="21" cy="21" r="15.915" fill="none" stroke-width="3.5" stroke-dasharray="<?php echo esc_attr($pct . ' ' . (100 - $pct)); ?>" stroke-dashoffset="25"></circle>
                <text x="21" y="21" class="donut__total"><?php echo esc_html(number_format_i18n($total)); ?></text>
                <text x="21" y="27" class="donut__caption"><?php esc_html_e('gesamt', 'madex-chatbot'); ?></text>
            </svg>
            <ul class="donut__legend">
                <li><i class="legend__swatch legend__swatch--clients"></i><span><?php esc_html_e('Bestehende Kunden', 'madex-chatbot'); ?><b><?php echo esc_html($pct . ' % · ' . number_format_i18n($clients)); ?></b></span></li>
                <li><i class="legend__swatch legend__swatch--prospects"></i><span><?php esc_html_e('Interessenten', 'madex-chatbot'); ?><b><?php echo esc_html((100 - $pct) . ' % · ' . number_format_i18n($prospects)); ?></b></span></li>
            </ul>
        </div>
        <?php
    }

    private function topic_rows($report) {
        // Session topics already include chats that led to an appointment;
        // appointment services are only used when no topics exist yet.
        $source = !empty($report['topics']) ? $report['topics'] : $report['services'];
        $merged = array();
        foreach ($source as $row) {
            $label = Madex_Business_Service::service_label($row['label']);
            $merged[$label] = (isset($merged[$label]) ? $merged[$label] : 0) + (int) $row['total'];
        }
        arsort($merged);
        $rows = array();
        foreach ($merged as $label => $total) {
            $rows[] = array('label' => $label, 'total' => $total);
        }
        return $rows;
    }

    /**
     * Minimal stroke icon set (decorative; labels always accompany them).
     */
    private function icon($name) {
        $paths = array(
            'grid' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
            'chat' => '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v7a2.5 2.5 0 0 1-2.5 2.5H10l-5 4v-4.5A2.5 2.5 0 0 1 4 12.5z"/>',
            'calendar' => '<path d="M7 3v3m10-3v3M4 9h16M5 5h14a1 1 0 0 1 1 1v14H4V6a1 1 0 0 1 1-1Z"/>',
            'bars' => '<path d="M5 20V10m7 10V4m7 16v-7"/>',
            'radar' => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 12 18 6"/>',
            'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
            'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
            'arrow-left' => '<path d="M19 12H5m6-6-6 6 6 6"/>',
            'check' => '<path d="m5 12 4 4L19 6"/>',
            'x' => '<path d="M6 6l12 12M18 6 6 18"/>',
            'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
            'alert' => '<path d="M12 4 2.5 20h19z"/><path d="M12 10v4m0 3v.5"/>',
            'hourglass' => '<path d="M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9m8-18c0 5-8 5-8 9"/>',
            'ban' => '<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>',
            'lock' => '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
            'shield' => '<path d="M12 3 5 6v6c0 4 3 7 7 9 4-2 7-5 7-9V6z"/>',
            'help' => '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17v.5"/>',
            'key' => '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9m-3 3 3 3"/>',
            'download' => '<path d="M12 4v11m-5-5 5 5 5-5M5 20h14"/>',
            'copy' => '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
            'print' => '<path d="M7 9V3h10v6M7 17H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><rect x="7" y="14" width="10" height="7"/>',
            'logout' => '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 8l-4 4 4 4M6 12h10"/>',
        );
        $path = isset($paths[$name]) ? $paths[$name] : $paths['help'];
        return '<svg class="icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $path . '</svg>';
    }

    /* ==================================================================
     * Formatting helpers
     * ================================================================== */

    private function range_param($allowed, $default) {
        $range = isset($_GET['range']) ? absint($_GET['range']) : $default;
        return in_array($range, $allowed, true) ? $range : $default;
    }

    private function greeting() {
        $hour = (int) wp_date('G');
        if ($hour < 11) {
            return __('Guten Morgen', 'madex-chatbot');
        }
        if ($hour < 18) {
            return __('Guten Tag', 'madex-chatbot');
        }
        return __('Guten Abend', 'madex-chatbot');
    }

    private function weekday($timestamp, $short = true) {
        $long = array(__('Sonntag', 'madex-chatbot'), __('Montag', 'madex-chatbot'), __('Dienstag', 'madex-chatbot'), __('Mittwoch', 'madex-chatbot'), __('Donnerstag', 'madex-chatbot'), __('Freitag', 'madex-chatbot'), __('Samstag', 'madex-chatbot'));
        $abbr = array('So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa');
        $index = (int) gmdate('w', $timestamp);
        return $short ? $abbr[$index] : $long[$index];
    }

    private function long_date() {
        $months = array(1 => 'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember');
        $now = current_time('timestamp');
        return $this->weekday($now, false) . ', ' . gmdate('j', $now) . '. ' . $months[(int) gmdate('n', $now)] . ' ' . gmdate('Y', $now);
    }

    /** Local MySQL datetime → "local" pseudo-timestamp (matches current_time('timestamp')). */
    private function ts($mysql) {
        $ts = strtotime((string) $mysql . ' UTC');
        return $ts ? $ts : 0;
    }

    private function iso($mysql) {
        $ts = $this->ts($mysql);
        return $ts ? gmdate('Y-m-d\TH:i', $ts) : '';
    }

    private function datetime($mysql, $format = 'd.m.Y, H:i') {
        $ts = $this->ts($mysql);
        return $ts ? gmdate($format, $ts) : '–';
    }

    private function time_only($mysql) {
        return $this->datetime($mysql, 'H:i');
    }

    private function relative($mysql) {
        $ts = $this->ts($mysql);
        if (!$ts) {
            return '–';
        }
        $diff = current_time('timestamp') - $ts;
        if ($diff < 60) {
            return __('gerade eben', 'madex-chatbot');
        }
        if ($diff < HOUR_IN_SECONDS) {
            return sprintf(__('vor %d Min.', 'madex-chatbot'), floor($diff / 60));
        }
        if ($diff < DAY_IN_SECONDS && gmdate('Y-m-d', $ts) === gmdate('Y-m-d', current_time('timestamp'))) {
            return sprintf(__('vor %d Std.', 'madex-chatbot'), floor($diff / HOUR_IN_SECONDS));
        }
        if (gmdate('Y-m-d', $ts) === gmdate('Y-m-d', current_time('timestamp') - DAY_IN_SECONDS)) {
            return __('gestern', 'madex-chatbot');
        }
        if ($diff < 6 * DAY_IN_SECONDS) {
            return $this->weekday($ts);
        }
        return gmdate('d.m.', $ts);
    }

    private function preferred($item, $short = false) {
        if (empty($item['preferred_date'])) {
            return '';
        }
        $ts = $this->ts($item['preferred_date'] . ' 12:00:00');
        $time = Madex_Business_Service::time_label($item['preferred_time']);
        if ($short) {
            $abbr = array('morning' => 'VM', 'midday' => 'MI', 'afternoon' => 'NM', 'flexible' => 'flex.');
            $time = isset($abbr[$item['preferred_time']]) ? $abbr[$item['preferred_time']] : $time;
        }
        return $this->weekday($ts) . ', ' . gmdate('d.m.', $ts) . ($time !== '' ? ' · ' . $time : '');
    }

    private function customer_type_label($type) {
        if ($type === 'client') {
            return __('Bestehender Kunde', 'madex-chatbot');
        }
        if ($type === 'prospect') {
            return __('Interessent', 'madex-chatbot');
        }
        return __('Unbekannt', 'madex-chatbot');
    }

    private function live_chip_text($item) {
        $minutes = max(1, (int) floor((current_time('timestamp') - $this->ts($item['created_at'])) / 60));
        return implode(' · ', array_filter(array(
            sprintf(__('Besucher %s', 'madex-chatbot'), $item['visitor']),
            $item['topic_label'],
            $minutes >= 60 ? sprintf(__('%d Std.', 'madex-chatbot'), floor($minutes / 60)) : sprintf(__('%d Min.', 'madex-chatbot'), $minutes),
        )));
    }

    private function event_label($event, $statuses) {
        $actor = '';
        if (!empty($event['actor_user_id'])) {
            $user = get_userdata((int) $event['actor_user_id']);
            $actor = $user ? ' · ' . $user->display_name : '';
        }
        switch ($event['event_type']) {
            case 'created':
                return __('Anfrage eingegangen', 'madex-chatbot');
            case 'email_sent':
                return __('Benachrichtigung zugestellt', 'madex-chatbot');
            case 'email_failed':
                return __('E-Mail-Benachrichtigung fehlgeschlagen', 'madex-chatbot');
            case 'email_retry_requested':
                return __('E-Mail erneut angefordert', 'madex-chatbot') . $actor;
            case 'status_changed':
                $label = isset($statuses[$event['new_status']]) ? $statuses[$event['new_status']] : $event['new_status'];
                return sprintf(__('Status: %s', 'madex-chatbot'), $label) . $actor;
            case 'updated':
                return __('Notiz aktualisiert', 'madex-chatbot') . $actor;
        }
        return $event['event_type'] . $actor;
    }

    private function initials($name) {
        $parts = preg_split('/\s+/', trim((string) $name));
        $initials = '';
        foreach (array_slice(array_filter($parts), 0, 2) as $part) {
            $initials .= function_exists('mb_substr') ? mb_strtoupper(mb_substr($part, 0, 1)) : strtoupper(substr($part, 0, 1));
        }
        return $initials !== '' ? $initials : 'M';
    }

    /* ==================================================================
     * HTTP helpers
     * ================================================================== */

    private function same_origin() {
        $home = wp_parse_url(home_url('/'));
        $expected = strtolower($home['scheme'] . '://' . $home['host'] . (isset($home['port']) ? ':' . $home['port'] : ''));
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? strtolower(trim((string) $_SERVER['HTTP_ORIGIN'])) : '';
        if ($origin !== '' && $origin !== 'null') {
            return hash_equals($expected, $origin);
        }
        $referer = isset($_SERVER['HTTP_REFERER']) ? (string) $_SERVER['HTTP_REFERER'] : '';
        if ($referer !== '') {
            $parts = wp_parse_url($referer);
            $ref_origin = strtolower(($parts['scheme'] ?? '') . '://' . ($parts['host'] ?? '') . (isset($parts['port']) ? ':' . $parts['port'] : ''));
            return hash_equals($expected, $ref_origin);
        }
        // No Origin/Referer (privacy tools, no-referrer policy): rely on the
        // SameSite=Strict session cookie and per-session form token.
        return true;
    }

    private function redirect($route, $args = array()) {
        wp_safe_redirect(Madex_Portal_Auth::url($route, $args), 303);
        exit;
    }

    private function json($data, $status = 200) {
        status_header($status);
        header('Content-Type: application/json; charset=UTF-8');
        echo wp_json_encode($data);
        exit;
    }
}
