<?php
/**
 * Authenticated encryption for plugin secrets.
 *
 * New values use libsodium secretbox when available and AES-256-GCM as a
 * fallback. Legacy AES-CBC values remain readable so they can be re-encrypted
 * after an upgrade, but encryption never falls back to plaintext.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Encryption {

    const SODIUM_PREFIX = 'mxs1:';
    const GCM_PREFIX = 'mxg1:';
    const LEGACY_PREFIX = 'enc:';
    const GCM_METHOD = 'aes-256-gcm';
    const LEGACY_METHOD = 'aes-256-cbc';

    /**
     * Derive a site-specific binary key from WordPress salts.
     *
     * @return string|false
     */
    private static function get_encryption_key() {
        $parts = array();

        foreach (array('AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY') as $constant) {
            if (defined($constant) && constant($constant) !== 'put your unique phrase here') {
                $parts[] = (string) constant($constant);
            }
        }

        if (function_exists('wp_salt')) {
            $parts[] = wp_salt('auth');
            $parts[] = wp_salt('secure_auth');
        }

        $material = implode('|', array_filter($parts));
        if ($material === '') {
            return false;
        }

        return hash_hmac('sha256', 'madex-chatbot-secrets-v2', $material, true);
    }

    /**
     * Encrypt a secret with authentication.
     *
     * @param string $plaintext Secret value.
     * @return string|false
     */
    public static function encrypt($plaintext) {
        if ($plaintext === '') {
            return '';
        }

        $key = self::get_encryption_key();
        if ($key === false) {
            return false;
        }

        try {
            if (function_exists('sodium_crypto_secretbox')) {
                $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
                $ciphertext = sodium_crypto_secretbox((string) $plaintext, $nonce, $key);
                return self::SODIUM_PREFIX . base64_encode($nonce . $ciphertext);
            }

            if (function_exists('openssl_encrypt') && in_array(self::GCM_METHOD, openssl_get_cipher_methods(), true)) {
                $iv = random_bytes(openssl_cipher_iv_length(self::GCM_METHOD));
                $tag = '';
                $ciphertext = openssl_encrypt(
                    (string) $plaintext,
                    self::GCM_METHOD,
                    $key,
                    OPENSSL_RAW_DATA,
                    $iv,
                    $tag,
                    'madex-chatbot',
                    16
                );

                if ($ciphertext === false || strlen($tag) !== 16) {
                    return false;
                }

                return self::GCM_PREFIX . base64_encode($iv . $tag . $ciphertext);
            }
        } catch (Exception $exception) {
            return false;
        }

        return false;
    }

    /**
     * Decrypt a secret.
     *
     * Plaintext is returned only for backwards compatibility with existing
     * stored API keys; callers should immediately persist it using encrypt().
     *
     * @param string $value Stored value.
     * @return string|false
     */
    public static function decrypt($value) {
        if ($value === '') {
            return '';
        }

        $key = self::get_encryption_key();
        if ($key === false) {
            return false;
        }

        if (strpos($value, self::SODIUM_PREFIX) === 0) {
            if (!function_exists('sodium_crypto_secretbox_open')) {
                return false;
            }

            $decoded = base64_decode(substr($value, strlen(self::SODIUM_PREFIX)), true);
            if ($decoded === false || strlen($decoded) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
                return false;
            }

            $nonce = substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $ciphertext = substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            return sodium_crypto_secretbox_open($ciphertext, $nonce, $key);
        }

        if (strpos($value, self::GCM_PREFIX) === 0) {
            if (!function_exists('openssl_decrypt') || !in_array(self::GCM_METHOD, openssl_get_cipher_methods(), true)) {
                return false;
            }

            $decoded = base64_decode(substr($value, strlen(self::GCM_PREFIX)), true);
            $iv_length = openssl_cipher_iv_length(self::GCM_METHOD);
            if ($decoded === false || strlen($decoded) <= ($iv_length + 16)) {
                return false;
            }

            $iv = substr($decoded, 0, $iv_length);
            $tag = substr($decoded, $iv_length, 16);
            $ciphertext = substr($decoded, $iv_length + 16);

            return openssl_decrypt(
                $ciphertext,
                self::GCM_METHOD,
                $key,
                OPENSSL_RAW_DATA,
                $iv,
                $tag,
                'madex-chatbot'
            );
        }

        if (strpos($value, self::LEGACY_PREFIX) === 0) {
            return self::decrypt_legacy($value);
        }

        // Existing releases stored API keys in plaintext. Returning the value
        // permits a one-time migration; new writes never use plaintext.
        return (string) $value;
    }

    /**
     * Read legacy AES-CBC values created before v2.
     *
     * @param string $value Legacy encrypted value.
     * @return string|false
     */
    private static function decrypt_legacy($value) {
        if (!function_exists('openssl_decrypt')) {
            return false;
        }

        $key_base = '';
        if (defined('AUTH_KEY') && AUTH_KEY !== 'put your unique phrase here') {
            $key_base .= AUTH_KEY;
        }
        if (defined('SECURE_AUTH_KEY') && SECURE_AUTH_KEY !== 'put your unique phrase here') {
            $key_base .= SECURE_AUTH_KEY;
        }
        if ($key_base === '') {
            $key_base = ABSPATH . get_site_url() . 'madex-chatbot-fallback';
        }

        $legacy_key = hash('sha256', $key_base, true);
        $decoded = base64_decode(substr($value, strlen(self::LEGACY_PREFIX)), true);
        $iv_length = openssl_cipher_iv_length(self::LEGACY_METHOD);

        if ($decoded === false || strlen($decoded) <= $iv_length) {
            return false;
        }

        return openssl_decrypt(
            substr($decoded, $iv_length),
            self::LEGACY_METHOD,
            $legacy_key,
            OPENSSL_RAW_DATA,
            substr($decoded, 0, $iv_length)
        );
    }

    /**
     * @param string $value Value to inspect.
     * @return bool
     */
    public static function is_encrypted($value) {
        return strpos($value, self::SODIUM_PREFIX) === 0
            || strpos($value, self::GCM_PREFIX) === 0
            || strpos($value, self::LEGACY_PREFIX) === 0;
    }

    /**
     * Mask an API key without exposing it to the browser.
     *
     * @param string $stored_value Stored key.
     * @return string
     */
    public static function mask_api_key($stored_value) {
        $api_key = self::decrypt($stored_value);
        if (!is_string($api_key) || $api_key === '') {
            return '';
        }

        $length = strlen($api_key);
        if ($length <= 12) {
            return str_repeat('*', $length);
        }

        return substr($api_key, 0, 4) . str_repeat('*', $length - 8) . substr($api_key, -4);
    }

    /**
     * @return bool
     */
    public static function is_available() {
        return function_exists('sodium_crypto_secretbox')
            || (function_exists('openssl_encrypt') && in_array(self::GCM_METHOD, openssl_get_cipher_methods(), true));
    }

    /**
     * Kept for callers from earlier releases.
     *
     * @return bool
     */
    public static function is_openssl_available() {
        return function_exists('openssl_encrypt')
            && function_exists('openssl_decrypt')
            && in_array(self::GCM_METHOD, openssl_get_cipher_methods(), true);
    }
}
