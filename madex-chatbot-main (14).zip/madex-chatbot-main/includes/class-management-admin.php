<?php
/**
 * Madex control panel inside WordPress Admin: packages, appointment requests,
 * portal access/2FA, reports, audit log and system status.
 *
 * Full configuration lives here. The boss portal (/chatadm) only ever reads
 * operational data and never exposes these settings.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Management_Admin {

    const APPOINTMENT_SETTINGS = 'madex_chatbot_appointment_settings';
    const PORTAL_SETTINGS = 'madex_portal_settings';

    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'register_pages'), 20);
        add_action('admin_post_madex_save_package', array($this, 'save_package'));
        add_action('admin_post_madex_delete_package', array($this, 'delete_package'));
        add_action('admin_post_madex_update_appointment', array($this, 'update_appointment'));
        add_action('admin_post_madex_retry_appointment_email', array($this, 'retry_appointment_email'));
        add_action('admin_post_madex_save_portal_settings', array($this, 'save_portal_settings'));
        add_action('admin_post_madex_set_portal_access', array($this, 'set_portal_access'));
        add_action('admin_post_madex_reset_portal_2fa', array($this, 'reset_portal_2fa'));
        add_action('admin_post_madex_revoke_portal_sessions', array($this, 'revoke_portal_sessions'));
        add_action('admin_post_madex_export_appointments', array($this, 'export_appointments'));
    }

    public function register_pages() {
        $parent = 'madex-chatbot';
        $pages = array(
            array('madex-chatbot-overview', __('Übersicht', 'madex-chatbot'), 'render_overview'),
            array('madex-chatbot-packages', __('Pakete & Regeln', 'madex-chatbot'), 'render_packages'),
            array('madex-chatbot-appointments', __('Terminanfragen', 'madex-chatbot'), 'render_appointments'),
            array('madex-chatbot-portal', __('Portal & 2FA', 'madex-chatbot'), 'render_portal'),
            array('madex-chatbot-reports', __('Berichte', 'madex-chatbot'), 'render_reports'),
            array('madex-chatbot-audit', __('Audit-Log', 'madex-chatbot'), 'render_audit'),
            array('madex-chatbot-system', __('Systemstatus', 'madex-chatbot'), 'render_system'),
        );
        foreach ($pages as $page) {
            add_submenu_page($parent, $page[1], $page[1], 'manage_options', $page[0], array($this, $page[2]));
        }

        // Operational pages first, configuration after.
        global $submenu;
        if (!empty($submenu[$parent])) {
            $order = array(
                'madex-chatbot-overview', 'madex-chatbot-appointments', 'madex-chatbot-packages', 'madex-chatbot-portal',
                'madex-chatbot-reports', 'madex-chatbot', 'madex-chatbot-knowledge', 'madex-chatbot-sessions',
                'madex-chatbot-audit', 'madex-chatbot-system',
            );
            usort($submenu[$parent], function ($a, $b) use ($order) {
                $ia = array_search($a[2], $order, true);
                $ib = array_search($b[2], $order, true);
                return ($ia === false ? 99 : $ia) - ($ib === false ? 99 : $ib);
            });
        }
    }

    /* ==================================================================
     * Shared chrome
     * ================================================================== */

    private function require_admin() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sie dürfen den Madex Chatbot nicht verwalten.', 'madex-chatbot'), 403);
        }
    }

    private function header($title, $description = '', $actions = '') {
        ?>
        <div class="wrap madex-control">
            <header class="mc-header">
                <img class="mc-header__logo" src="<?php echo esc_url(MADEX_CHATBOT_PLUGIN_URL . 'assets/images/logo-madex.png'); ?>" alt="Madex IT Solutions" width="132" height="28">
                <div class="mc-header__text">
                    <h1><?php echo esc_html($title); ?></h1>
                    <?php if ($description !== '') : ?><p><?php echo esc_html($description); ?></p><?php endif; ?>
                </div>
                <span class="mc-dirty" data-mc-dirty-indicator hidden>● <?php esc_html_e('Ungespeicherte Änderungen', 'madex-chatbot'); ?></span>
                <?php if ($actions !== '') : ?><div class="mc-header__actions"><?php echo $actions; // Built from escaped parts by callers. ?></div><?php endif; ?>
            </header>
            <hr class="wp-header-end">
            <?php $this->notice(); ?>
        <?php
    }

    private function footer() {
        echo '</div>';
    }

    private function notice() {
        $notice = isset($_GET['madex_notice']) ? sanitize_key(wp_unslash($_GET['madex_notice'])) : '';
        $messages = array(
            'saved' => array('success', __('Änderungen gespeichert.', 'madex-chatbot')),
            'deleted' => array('success', __('Eintrag gelöscht.', 'madex-chatbot')),
            'updated' => array('success', __('Terminanfrage aktualisiert.', 'madex-chatbot')),
            'resent' => array('success', __('Benachrichtigung erneut gesendet.', 'madex-chatbot')),
            'resend_failed' => array('error', __('Die E-Mail konnte erneut nicht zugestellt werden. Prüfen Sie die E-Mail-Konfiguration (z. B. SMTP-Plugin).', 'madex-chatbot')),
            'reset' => array('success', __('2FA wurde zurückgesetzt und alle Portal-Sitzungen beendet. Beim nächsten Login wird die Einrichtung erneut angezeigt.', 'madex-chatbot')),
            'revoked' => array('success', __('Alle Portal-Sitzungen dieses Benutzers wurden beendet.', 'madex-chatbot')),
            'access_on' => array('success', __('Portal-Zugang freigegeben.', 'madex-chatbot')),
            'access_off' => array('success', __('Portal-Zugang entzogen und Sitzungen beendet.', 'madex-chatbot')),
            'error' => array('error', __('Die Aktion konnte nicht ausgeführt werden. Bitte prüfen Sie die Eingaben.', 'madex-chatbot')),
        );
        if (!isset($messages[$notice])) {
            return;
        }
        $detail = isset($_GET['madex_detail']) ? sanitize_text_field(wp_unslash($_GET['madex_detail'])) : '';
        printf(
            '<div class="notice notice-%1$s is-dismissible"><p>%2$s%3$s</p></div>',
            esc_attr($messages[$notice][0]),
            esc_html($messages[$notice][1]),
            $detail !== '' ? ' ' . esc_html($detail) : ''
        );
    }

    private function redirect($page, $notice, $args = array()) {
        $args = array_merge(array('page' => $page, 'madex_notice' => $notice), $args);
        wp_safe_redirect(add_query_arg(array_map('rawurlencode', $args), admin_url('admin.php')));
        exit;
    }

    private function status_badge($status) {
        $labels = Madex_Business_Service::status_options();
        $tones = array('new' => 'new', 'contacted' => 'warning', 'confirmed' => 'success', 'completed' => 'success', 'cancelled' => 'muted');
        $icons = array('new' => '●', 'contacted' => '◷', 'confirmed' => '✓', 'completed' => '✓', 'cancelled' => '—');
        printf(
            '<span class="mc-badge mc-badge--%1$s"><span aria-hidden="true">%2$s</span> %3$s</span>',
            esc_attr(isset($tones[$status]) ? $tones[$status] : 'muted'),
            esc_html(isset($icons[$status]) ? $icons[$status] : '•'),
            esc_html(isset($labels[$status]) ? $labels[$status] : $status)
        );
    }

    private function email_badge($status) {
        $map = array(
            'sent' => array('success', '✓', __('Zugestellt', 'madex-chatbot')),
            'failed' => array('error', '✕', __('Fehlgeschlagen', 'madex-chatbot')),
            'pending' => array('muted', '◌', __('Ausstehend', 'madex-chatbot')),
        );
        $item = isset($map[$status]) ? $map[$status] : $map['pending'];
        printf('<span class="mc-badge mc-badge--%1$s"><span aria-hidden="true">%2$s</span> %3$s</span>', esc_attr($item[0]), esc_html($item[1]), esc_html($item[2]));
    }

    private function kpi($label, $value, $hint, $accent = false) {
        printf(
            '<article class="mc-kpi%4$s"><span class="mc-kpi__label">%1$s</span><strong class="mc-kpi__value">%2$s</strong><span class="mc-kpi__hint">%3$s</span></article>',
            esc_html($label),
            esc_html(number_format_i18n((float) $value)),
            esc_html($hint),
            $accent ? ' mc-kpi--accent' : ''
        );
    }

    private function format_datetime($mysql, $format = 'd.m.Y, H:i') {
        $ts = strtotime((string) $mysql . ' UTC');
        return $ts ? gmdate($format, $ts) : '–';
    }

    private function preferred_label($item) {
        if (empty($item['preferred_date'])) {
            return '–';
        }
        $ts = strtotime($item['preferred_date'] . ' 12:00:00 UTC');
        $days = array('So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa');
        return $days[(int) gmdate('w', $ts)] . ', ' . gmdate('d.m.Y', $ts) . ' · ' . Madex_Business_Service::time_label($item['preferred_time']);
    }

    /* ==================================================================
     * Overview
     * ================================================================== */

    public function render_overview() {
        $this->require_admin();
        $stats = Madex_Business_Service::get_dashboard_stats(7);
        $recent = Madex_Business_Service::list_appointments(array('per_page' => 6));
        $checks = $this->system_checks();
        $failing = array_filter($checks, function ($check) { return !$check['ok'] && $check['required']; });
        $portal_url = Madex_Portal_Auth::url('');

        $actions = '<a class="button" href="' . esc_url($portal_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Management-Portal öffnen', 'madex-chatbot') . ' ↗</a>';
        $this->header(__('Übersicht', 'madex-chatbot'), __('Gespräche, Terminanfragen und Systemzustand auf einen Blick.', 'madex-chatbot'), $actions);
        ?>
        <?php if (!empty($failing)) : ?>
            <div class="mc-alert mc-alert--warning">
                <span class="dashicons dashicons-warning" aria-hidden="true"></span>
                <div><b><?php echo esc_html(sprintf(_n('%d Punkt benötigt Ihre Aufmerksamkeit', '%d Punkte benötigen Ihre Aufmerksamkeit', count($failing), 'madex-chatbot'), count($failing))); ?></b>
                    <p><?php echo esc_html(implode(' · ', wp_list_pluck($failing, 'label'))); ?></p></div>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=madex-chatbot-system')); ?>"><?php esc_html_e('Systemstatus', 'madex-chatbot'); ?></a>
            </div>
        <?php endif; ?>

        <section class="mc-kpis">
            <?php
            $this->kpi(__('Gespräche', 'madex-chatbot'), $stats['conversations_range'], __('letzte 7 Tage', 'madex-chatbot'));
            $this->kpi(__('Gespräche heute', 'madex-chatbot'), $stats['conversations_today'], __('seit 00:00', 'madex-chatbot'));
            $this->kpi(__('Aktive Chats', 'madex-chatbot'), $stats['active_chats'], __('letzte 5 Minuten', 'madex-chatbot'));
            $this->kpi(__('Neue Terminanfragen', 'madex-chatbot'), $stats['new_appointments'], __('nicht bearbeitet', 'madex-chatbot'), $stats['new_appointments'] > 0);
            $this->kpi(__('Bestätigte Termine', 'madex-chatbot'), $stats['confirmed_upcoming'], __('ab heute', 'madex-chatbot'));
            $this->kpi(__('Ohne bestätigte Info', 'madex-chatbot'), $stats['unresolved'], __('Gespräche, letzte 7 Tage', 'madex-chatbot'));
            $this->kpi(__('E-Mail fehlgeschlagen', 'madex-chatbot'), $stats['email_failures'], __('erneut senden möglich', 'madex-chatbot'), $stats['email_failures'] > 0);
            $this->kpi(__('Interessenten / Kunden', 'madex-chatbot'), $stats['prospects'] + $stats['existing_clients'], sprintf(__('%1$d neu · %2$d Kunden', 'madex-chatbot'), $stats['prospects'], $stats['existing_clients']));
            ?>
        </section>

        <div class="mc-grid mc-grid--two">
            <section class="mc-card">
                <div class="mc-card__head"><h2><?php esc_html_e('Schnellzugriff', 'madex-chatbot'); ?></h2></div>
                <div class="mc-quick">
                    <?php
                    $quick = array(
                        array('madex-chatbot-packages', 'screenoptions', __('Pakete verwalten', 'madex-chatbot'), __('Leistungen und Anzeigeregeln', 'madex-chatbot')),
                        array('madex-chatbot-appointments', 'calendar-alt', __('Terminanfragen', 'madex-chatbot'), __('Kontaktieren, bestätigen, erledigen', 'madex-chatbot')),
                        array('madex-chatbot-portal', 'shield', __('Portal & 2FA', 'madex-chatbot'), __('Benutzer, Pfad und Sicherheit', 'madex-chatbot')),
                        array('madex-chatbot-knowledge', 'book', __('Wissensbasis', 'madex-chatbot'), __('Geprüfte Inhalte für die KI', 'madex-chatbot')),
                        array('madex-chatbot&tab=ai', 'admin-generic', __('KI-Verhalten', 'madex-chatbot'), __('Modell und Anweisungen', 'madex-chatbot')),
                        array('madex-chatbot&tab=branding', 'art', __('Branding', 'madex-chatbot'), __('Texte, Farbe, Kontakt', 'madex-chatbot')),
                    );
                    foreach ($quick as $item) :
                        ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=' . $item[0])); ?>"><span class="dashicons dashicons-<?php echo esc_attr($item[1]); ?>" aria-hidden="true"></span><b><?php echo esc_html($item[2]); ?></b><small><?php echo esc_html($item[3]); ?></small></a>
                    <?php endforeach; ?>
                </div>
            </section>
            <section class="mc-card mc-card--flush">
                <div class="mc-card__head mc-card__head--pad"><h2><?php esc_html_e('Neueste Terminanfragen', 'madex-chatbot'); ?></h2><a href="<?php echo esc_url(admin_url('admin.php?page=madex-chatbot-appointments')); ?>"><?php esc_html_e('Alle anzeigen →', 'madex-chatbot'); ?></a></div>
                <?php $this->appointment_list($recent['items'], ''); ?>
            </section>
        </div>
        <?php
        $this->footer();
    }

    /* ==================================================================
     * Packages
     * ================================================================== */

    public function render_packages() {
        $this->require_admin();
        $edit_id = isset($_GET['package_id']) ? absint($_GET['package_id']) : 0;
        $creating = isset($_GET['new']);
        $package = $edit_id ? Madex_Business_Service::get_package($edit_id) : array();
        if (is_wp_error($package)) {
            $package = array();
            $edit_id = 0;
        }
        $packages = Madex_Business_Service::list_packages(array('per_page' => 100))['items'];
        if (!$edit_id && !$creating && !empty($packages)) {
            $edit_id = (int) $packages[0]['id'];
            $package = Madex_Business_Service::get_package($edit_id);
        }

        $defaults = array(
            'name' => '', 'short_description' => '', 'features' => array(), 'audience' => '', 'icon' => '',
            'cta_label' => __('Beratung anfragen', 'madex-chatbot'), 'display_order' => count($packages) * 10,
            'is_active' => true, 'internal_notes' => '', 'conditions' => array(),
        );
        $package = wp_parse_args(is_array($package) ? $package : array(), $defaults);
        $conditions = $this->normalize_conditions($package['conditions']);

        $title = $edit_id ? sprintf(__('Pakete · %s', 'madex-chatbot'), $package['name']) : __('Pakete · Neues Paket', 'madex-chatbot');
        $actions = '<a class="button" href="' . esc_url(admin_url('admin.php?page=madex-chatbot-packages&new=1')) . '">' . esc_html__('+ Neues Paket', 'madex-chatbot') . '</a>'
            . '<button type="submit" form="mc-package-form" class="button button-primary">' . esc_html__('Speichern', 'madex-chatbot') . '</button>';
        $this->header($title, __('Pakete werden ohne Preise präsentiert. Regeln und interne Notizen werden nie an Besucher oder die KI ausgeliefert.', 'madex-chatbot'), $actions);
        ?>
        <div class="mc-packages">
            <aside class="mc-card mc-card--flush mc-package-list" aria-label="<?php esc_attr_e('Pakete', 'madex-chatbot'); ?>">
                <div class="mc-card__head mc-card__head--pad"><h2><?php esc_html_e('Alle Pakete', 'madex-chatbot'); ?></h2><span class="mc-muted"><?php echo esc_html(count($packages)); ?></span></div>
                <?php if (empty($packages)) : ?>
                    <div class="mc-empty"><span class="dashicons dashicons-screenoptions" aria-hidden="true"></span><b><?php esc_html_e('Noch keine Pakete', 'madex-chatbot'); ?></b><p><?php esc_html_e('Legen Sie rechts Ihr erstes Leistungspaket an.', 'madex-chatbot'); ?></p></div>
                <?php else : ?>
                    <ul>
                        <?php foreach ($packages as $item) : ?>
                            <li><a class="<?php echo (int) $item['id'] === $edit_id ? 'is-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=madex-chatbot-packages&package_id=' . (int) $item['id'])); ?>">
                                <span><b><?php echo esc_html($item['name']); ?></b><small><?php echo esc_html(wp_trim_words($item['short_description'], 8)); ?></small></span>
                                <?php if ($item['is_active']) : ?><span class="mc-badge mc-badge--success"><?php esc_html_e('Aktiv', 'madex-chatbot'); ?></span><?php else : ?><span class="mc-badge mc-badge--muted"><?php esc_html_e('Ausgeblendet', 'madex-chatbot'); ?></span><?php endif; ?>
                            </a></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </aside>

            <form id="mc-package-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mc-package-editor" data-mc-dirty data-mc-package-form>
                <input type="hidden" name="action" value="madex_save_package">
                <input type="hidden" name="package_id" value="<?php echo esc_attr($edit_id); ?>">
                <?php wp_nonce_field('madex_save_package'); ?>

                <section class="mc-card">
                    <div class="mc-card__head"><h2><?php esc_html_e('Details', 'madex-chatbot'); ?></h2></div>
                    <div class="mc-fields">
                        <label class="mc-field mc-field--wide"><span><?php esc_html_e('Paketname', 'madex-chatbot'); ?> *</span><input type="text" name="name" required maxlength="190" value="<?php echo esc_attr($package['name']); ?>" data-preview="name"></label>
                        <label class="mc-field mc-field--wide"><span><?php esc_html_e('Kurzbeschreibung', 'madex-chatbot'); ?></span><textarea name="short_description" rows="2" maxlength="500" data-preview="description"><?php echo esc_textarea($package['short_description']); ?></textarea></label>
                        <label class="mc-field mc-field--wide"><span><?php esc_html_e('Enthaltene Leistungen', 'madex-chatbot'); ?> <small><?php esc_html_e('eine pro Zeile', 'madex-chatbot'); ?></small></span><textarea name="features" rows="5" data-preview="features"><?php echo esc_textarea(implode("\n", (array) $package['features'])); ?></textarea></label>
                        <label class="mc-field"><span><?php esc_html_e('Ideal für', 'madex-chatbot'); ?></span><input type="text" name="audience" maxlength="255" value="<?php echo esc_attr($package['audience']); ?>" placeholder="<?php esc_attr_e('z. B. KMU bis 50 Mitarbeitende', 'madex-chatbot'); ?>"></label>
                        <label class="mc-field"><span><?php esc_html_e('Call-to-Action', 'madex-chatbot'); ?></span><input type="text" name="cta_label" maxlength="80" value="<?php echo esc_attr($package['cta_label']); ?>" data-preview="cta"></label>
                        <div class="mc-field mc-field--wide"><span><?php esc_html_e('Symbol oder Bild (optional)', 'madex-chatbot'); ?></span>
                            <div class="mc-media"><input type="url" name="icon" value="<?php echo esc_attr($package['icon']); ?>" placeholder="https://" data-mc-media-input><button type="button" class="button" data-mc-media><?php esc_html_e('Mediathek', 'madex-chatbot'); ?></button></div>
                        </div>
                        <label class="mc-field"><span><?php esc_html_e('Reihenfolge', 'madex-chatbot'); ?></span><input type="number" name="display_order" min="0" max="9999" value="<?php echo esc_attr((int) $package['display_order']); ?>"><small><?php esc_html_e('Kleinere Zahl = weiter vorne. Das erste passende Paket wird als „Passt am besten“ markiert.', 'madex-chatbot'); ?></small></label>
                        <div class="mc-field"><span><?php esc_html_e('Status', 'madex-chatbot'); ?></span>
                            <label class="mc-switch"><input type="checkbox" name="is_active" value="1" <?php checked((bool) $package['is_active']); ?>><span class="mc-switch__track" aria-hidden="true"></span><span><?php esc_html_e('Aktiv und für Empfehlungen verfügbar', 'madex-chatbot'); ?></span></label>
                        </div>
                        <label class="mc-field mc-field--wide mc-field--internal"><span><?php esc_html_e('Interne Notiz', 'madex-chatbot'); ?> <small><?php esc_html_e('· nie öffentlich sichtbar, nie an die KI', 'madex-chatbot'); ?></small></span><textarea name="internal_notes" rows="2"><?php echo esc_textarea($package['internal_notes']); ?></textarea></label>
                    </div>
                </section>

                <section class="mc-card mc-rules" data-mc-rules>
                    <div class="mc-card__head"><h2><?php esc_html_e('Anzeigeregeln', 'madex-chatbot'); ?></h2><span class="mc-muted"><?php esc_html_e('Werden Kunden nie angezeigt', 'madex-chatbot'); ?></span></div>
                    <p class="mc-help"><?php esc_html_e('Ohne Regeln wird das Paket allen Besuchern empfohlen. Die Regeln werden serverseitig mit den Angaben aus dem Chat geprüft.', 'madex-chatbot'); ?></p>
                    <label class="mc-inline"><span><?php esc_html_e('Paket anzeigen, wenn', 'madex-chatbot'); ?></span>
                        <select name="relation">
                            <option value="and" <?php selected($conditions['relation'], 'and'); ?>><?php esc_html_e('alle Bedingungen zutreffen (UND)', 'madex-chatbot'); ?></option>
                            <option value="or" <?php selected($conditions['relation'], 'or'); ?>><?php esc_html_e('mindestens eine zutrifft (ODER)', 'madex-chatbot'); ?></option>
                        </select>
                    </label>
                    <div class="mc-rule-list" data-mc-rule-list>
                        <?php foreach ($conditions['rules'] as $index => $rule) { $this->rule_row($index, $rule, $conditions['relation']); } ?>
                    </div>
                    <p class="mc-rule-empty" data-mc-rule-empty <?php echo empty($conditions['rules']) ? '' : 'hidden'; ?>><?php esc_html_e('Keine Bedingungen – wird allen Besuchern angezeigt.', 'madex-chatbot'); ?></p>
                    <button type="button" class="mc-add-rule" data-mc-add-rule>+ <?php esc_html_e('Bedingung hinzufügen', 'madex-chatbot'); ?></button>
                    <div class="mc-rule-then"><span class="mc-rule-op"><?php esc_html_e('DANN', 'madex-chatbot'); ?></span><span class="mc-chip mc-chip--solid"><?php esc_html_e('Paket anzeigen', 'madex-chatbot'); ?></span></div>
                    <template data-mc-rule-template><?php $this->rule_row('__INDEX__', array('field' => 'customer_status', 'operator' => 'equals', 'value' => 'prospect'), $conditions['relation']); ?></template>
                </section>

                <section class="mc-card mc-preview" aria-label="<?php esc_attr_e('Vorschau im Chatbot', 'madex-chatbot'); ?>">
                    <div class="mc-card__head"><h2><?php esc_html_e('Vorschau im Chatbot', 'madex-chatbot'); ?></h2><span class="mc-muted"><?php esc_html_e('ohne Preise', 'madex-chatbot'); ?></span></div>
                    <article class="mc-preview-card">
                        <span class="mc-preview-card__badge"><?php esc_html_e('Passt am besten', 'madex-chatbot'); ?></span>
                        <b data-preview-target="name"><?php echo esc_html($package['name'] !== '' ? $package['name'] : __('Paketname', 'madex-chatbot')); ?></b>
                        <p data-preview-target="description"><?php echo esc_html($package['short_description']); ?></p>
                        <ul data-preview-target="features"><?php foreach ((array) $package['features'] as $feature) : ?><li><?php echo esc_html($feature); ?></li><?php endforeach; ?></ul>
                        <span class="mc-preview-card__cta" data-preview-target="cta"><?php echo esc_html($package['cta_label']); ?></span>
                    </article>
                </section>
            </form>

            <?php if ($edit_id) : ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mc-danger" data-mc-confirm="<?php esc_attr_e('Dieses Paket endgültig löschen?', 'madex-chatbot'); ?>">
                    <input type="hidden" name="action" value="madex_delete_package">
                    <input type="hidden" name="package_id" value="<?php echo esc_attr($edit_id); ?>">
                    <?php wp_nonce_field('madex_delete_package_' . $edit_id); ?>
                    <button type="submit" class="button-link button-link-delete"><?php esc_html_e('Paket löschen', 'madex-chatbot'); ?></button>
                </form>
            <?php endif; ?>
        </div>
        <?php
        $this->footer();
    }

    private function normalize_conditions($conditions) {
        if (isset($conditions['rules'])) {
            return array('relation' => $conditions['relation'] === 'or' ? 'or' : 'and', 'rules' => array_values((array) $conditions['rules']));
        }
        if (isset($conditions['field'])) {
            return array('relation' => 'and', 'rules' => array($conditions));
        }
        return array('relation' => 'and', 'rules' => array_values(array_filter((array) $conditions, function ($rule) { return isset($rule['field']); })));
    }

    private function rule_row($index, $rule, $relation) {
        $field = isset($rule['field']) ? $rule['field'] : 'customer_status';
        $operator = isset($rule['operator']) ? $rule['operator'] : 'equals';
        $value = isset($rule['value']) ? $rule['value'] : '';
        $name = 'rules[' . $index . ']';
        $op_label = $index === 0 || $index === '0' ? __('WENN', 'madex-chatbot') : ($relation === 'or' ? __('ODER', 'madex-chatbot') : __('UND', 'madex-chatbot'));
        ?>
        <div class="mc-rule" data-mc-rule>
            <span class="mc-rule-op" data-mc-rule-op><?php echo esc_html($op_label); ?></span>
            <select name="<?php echo esc_attr($name); ?>[field]" aria-label="<?php esc_attr_e('Merkmal', 'madex-chatbot'); ?>" data-mc-rule-field>
                <option value="customer_status" <?php selected($field, 'customer_status'); ?>><?php esc_html_e('Kundenstatus', 'madex-chatbot'); ?></option>
                <option value="service" <?php selected($field, 'service'); ?>><?php esc_html_e('Interesse', 'madex-chatbot'); ?></option>
                <option value="company_size" <?php selected($field, 'company_size'); ?>><?php esc_html_e('Mitarbeitende', 'madex-chatbot'); ?></option>
            </select>
            <select name="<?php echo esc_attr($name); ?>[operator]" aria-label="<?php esc_attr_e('Vergleich', 'madex-chatbot'); ?>" data-mc-rule-operator>
                <option value="equals" <?php selected($operator, 'equals'); ?> data-for="customer_status service company_size"><?php esc_html_e('ist', 'madex-chatbot'); ?></option>
                <option value="not_equals" <?php selected($operator, 'not_equals'); ?> data-for="customer_status service company_size"><?php esc_html_e('ist nicht', 'madex-chatbot'); ?></option>
                <option value="lte" <?php selected($operator, 'lte'); ?> data-for="company_size"><?php esc_html_e('ist höchstens', 'madex-chatbot'); ?></option>
                <option value="gte" <?php selected($operator, 'gte'); ?> data-for="company_size"><?php esc_html_e('ist mindestens', 'madex-chatbot'); ?></option>
            </select>
            <span class="mc-rule-value" data-mc-rule-value>
                <select name="<?php echo esc_attr($name); ?>[value_customer_status]" data-for="customer_status" aria-label="<?php esc_attr_e('Wert', 'madex-chatbot'); ?>" <?php echo $field !== 'customer_status' ? 'hidden disabled' : ''; ?>>
                    <option value="prospect" <?php selected($value, 'prospect'); ?>><?php esc_html_e('Neuer Kunde (Interessent)', 'madex-chatbot'); ?></option>
                    <option value="client" <?php selected($value, 'client'); ?>><?php esc_html_e('Bestehender Kunde', 'madex-chatbot'); ?></option>
                </select>
                <select name="<?php echo esc_attr($name); ?>[value_service]" data-for="service" aria-label="<?php esc_attr_e('Wert', 'madex-chatbot'); ?>" <?php echo $field !== 'service' ? 'hidden disabled' : ''; ?>>
                    <?php foreach (Madex_Business_Service::service_options() as $key => $label) : ?>
                        <option value="<?php echo esc_attr($key); ?>" <?php selected($value, $key); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="number" min="0" max="100000" name="<?php echo esc_attr($name); ?>[value_company_size]" data-for="company_size" aria-label="<?php esc_attr_e('Mitarbeitende', 'madex-chatbot'); ?>" value="<?php echo esc_attr($field === 'company_size' ? (int) $value : 50); ?>" <?php echo $field !== 'company_size' ? 'hidden disabled' : ''; ?>>
            </span>
            <button type="button" class="mc-icon-btn" data-mc-remove-rule aria-label="<?php esc_attr_e('Bedingung entfernen', 'madex-chatbot'); ?>">×</button>
        </div>
        <?php
    }

    public function save_package() {
        $this->require_admin();
        check_admin_referer('madex_save_package');
        $id = isset($_POST['package_id']) ? absint($_POST['package_id']) : 0;

        $rules = array();
        $service_keys = array_keys(Madex_Business_Service::service_options());
        foreach ((array) ($_POST['rules'] ?? array()) as $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $field = sanitize_key($rule['field'] ?? '');
            $operator = sanitize_key($rule['operator'] ?? 'equals');
            if ($field === 'customer_status') {
                $value = sanitize_key($rule['value_customer_status'] ?? '');
                $value = in_array($value, array('client', 'prospect'), true) ? $value : 'prospect';
                $operator = in_array($operator, array('equals', 'not_equals'), true) ? $operator : 'equals';
            } elseif ($field === 'service') {
                $value = sanitize_key($rule['value_service'] ?? '');
                if (!in_array($value, $service_keys, true)) {
                    continue;
                }
                $operator = in_array($operator, array('equals', 'not_equals'), true) ? $operator : 'equals';
            } elseif ($field === 'company_size') {
                $value = absint($rule['value_company_size'] ?? 0);
                $operator = in_array($operator, array('equals', 'not_equals', 'lte', 'gte'), true) ? $operator : 'lte';
            } else {
                continue;
            }
            $rules[] = array('field' => $field, 'operator' => $operator, 'value' => $value);
        }
        $relation = isset($_POST['relation']) && sanitize_key(wp_unslash($_POST['relation'])) === 'or' ? 'or' : 'and';

        // The business service sanitises and unslashes every field itself.
        $data = array(
            'name' => $_POST['name'] ?? '',
            'short_description' => $_POST['short_description'] ?? '',
            'features' => preg_split('/\r\n|\r|\n/', (string) wp_unslash($_POST['features'] ?? '')),
            'audience' => $_POST['audience'] ?? '',
            'icon' => $_POST['icon'] ?? '',
            'cta_label' => $_POST['cta_label'] ?? '',
            'display_order' => absint($_POST['display_order'] ?? 0),
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
            'internal_notes' => $_POST['internal_notes'] ?? '',
            'conditions' => empty($rules) ? array() : array('relation' => $relation, 'rules' => $rules),
        );
        $result = Madex_Business_Service::save_package($data, $id);
        if (is_wp_error($result)) {
            $this->redirect('madex-chatbot-packages', 'error', array('madex_detail' => $result->get_error_message()) + ($id ? array('package_id' => $id) : array('new' => 1)));
        }
        $this->redirect('madex-chatbot-packages', 'saved', array('package_id' => (int) $result['id']));
    }

    public function delete_package() {
        $this->require_admin();
        $id = absint($_POST['package_id'] ?? 0);
        check_admin_referer('madex_delete_package_' . $id);
        $result = Madex_Business_Service::delete_package($id);
        $this->redirect('madex-chatbot-packages', is_wp_error($result) || !$result ? 'error' : 'deleted');
    }

    /* ==================================================================
     * Appointments
     * ================================================================== */

    public function render_appointments() {
        $this->require_admin();
        $ref = isset($_GET['ref']) ? sanitize_text_field(wp_unslash($_GET['ref'])) : '';
        $status = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : '';
        $statuses = Madex_Business_Service::status_options();
        $status = array_key_exists($status, $statuses) ? $status : '';
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;

        $list = Madex_Business_Service::list_appointments(array('status' => $status, 'search' => $search, 'page' => $paged, 'per_page' => 25));
        $detail = $ref !== '' ? Madex_Business_Service::get_appointment($ref) : null;
        if (is_wp_error($detail)) {
            $detail = null;
        }

        $export = wp_nonce_url(admin_url('admin-post.php?action=madex_export_appointments' . ($status ? '&status=' . $status : '')), 'madex_export_appointments');
        $this->header(__('Terminanfragen', 'madex-chatbot'), __('Anfragen werden vor dem E-Mail-Versand gespeichert und bleiben sichtbar, auch wenn eine Benachrichtigung fehlschlägt.', 'madex-chatbot'), '<a class="button" href="' . esc_url($export) . '">' . esc_html__('CSV exportieren', 'madex-chatbot') . '</a>');
        ?>
        <div class="mc-toolbar">
            <nav class="mc-pills" aria-label="<?php esc_attr_e('Status filtern', 'madex-chatbot'); ?>">
                <a class="<?php echo $status === '' ? 'is-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=madex-chatbot-appointments')); ?>"><?php esc_html_e('Alle', 'madex-chatbot'); ?></a>
                <?php foreach ($statuses as $key => $label) : $count = Madex_Business_Service::list_appointments(array('status' => $key, 'per_page' => 1))['total']; ?>
                    <a class="<?php echo $status === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=madex-chatbot-appointments&status=' . $key)); ?>"><?php echo esc_html($label . ($count ? ' · ' . $count : '')); ?></a>
                <?php endforeach; ?>
            </nav>
            <form method="get" class="mc-search" role="search">
                <input type="hidden" name="page" value="madex-chatbot-appointments">
                <?php if ($status) : ?><input type="hidden" name="status" value="<?php echo esc_attr($status); ?>"><?php endif; ?>
                <label class="screen-reader-text" for="mc-appointment-search"><?php esc_html_e('Suchen', 'madex-chatbot'); ?></label>
                <input id="mc-appointment-search" type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Name, Firma, E-Mail oder Referenz …', 'madex-chatbot'); ?>">
                <button class="button"><?php esc_html_e('Suchen', 'madex-chatbot'); ?></button>
            </form>
        </div>
        <div class="mc-split">
            <section class="mc-card mc-card--flush">
                <?php $this->appointment_list($list['items'], $ref, array('status' => $status, 's' => $search)); ?>
                <?php
                $pages = (int) ceil($list['total'] / $list['per_page']);
                if ($pages > 1) {
                    echo '<div class="mc-pager">' . paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'current' => $paged,
                        'total' => $pages,
                    )) . '</div>';
                }
                ?>
            </section>
            <section class="mc-card"><?php $this->appointment_detail($detail, $statuses); ?></section>
        </div>
        <?php
        $this->footer();
    }

    private function appointment_list($items, $selected, $filters = array()) {
        if (empty($items)) {
            echo '<div class="mc-empty"><span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span><b>' . esc_html__('Keine Terminanfragen', 'madex-chatbot') . '</b><p>' . esc_html__('Neue Anfragen aus dem Chat erscheinen hier sofort.', 'madex-chatbot') . '</p></div>';
            return;
        }
        echo '<ul class="mc-rows">';
        foreach ($items as $item) {
            $url = add_query_arg(array_filter(array_merge($filters, array('page' => 'madex-chatbot-appointments', 'ref' => $item['reference']))), admin_url('admin.php'));
            echo '<li><a class="' . ($selected === $item['reference'] ? 'is-active' : '') . '" href="' . esc_url($url) . '">';
            echo '<span class="mc-rows__main"><b>' . esc_html($item['customer_name']) . '</b><small>' . esc_html(implode(' · ', array_filter(array($item['company'], Madex_Business_Service::service_label($item['service']), $this->preferred_label($item))))) . '</small></span>';
            echo '<span class="mc-rows__side">';
            $this->status_badge($item['status']);
            if ($item['email_status'] === 'failed') {
                echo ' ';
                $this->email_badge('failed');
            }
            echo '<small class="mc-mono">' . esc_html($item['reference']) . '</small></span></a></li>';
        }
        echo '</ul>';
    }

    private function appointment_detail($detail, $statuses) {
        if (!$detail) {
            echo '<div class="mc-empty"><span class="dashicons dashicons-arrow-left-alt" aria-hidden="true"></span><b>' . esc_html__('Anfrage auswählen', 'madex-chatbot') . '</b><p>' . esc_html__('Wählen Sie eine Anfrage, um Kontaktdaten und Verlauf zu sehen.', 'madex-chatbot') . '</p></div>';
            return;
        }
        $id = (int) $detail['id'];
        ?>
        <div class="mc-detail-head">
            <div><span class="mc-mono"><?php echo esc_html($detail['reference']); ?></span><h2><?php echo esc_html($detail['customer_name']); ?></h2><p><?php echo esc_html(implode(' · ', array_filter(array($detail['company'], $detail['existing_client'] === 'yes' ? __('Bestehender Kunde', 'madex-chatbot') : __('Interessent', 'madex-chatbot'))))); ?></p></div>
            <?php $this->status_badge($detail['status']); ?>
        </div>
        <?php if ($detail['email_status'] === 'failed') : ?>
            <div class="mc-alert mc-alert--error">
                <span class="dashicons dashicons-warning" aria-hidden="true"></span>
                <div><b><?php esc_html_e('Benachrichtigung nicht zugestellt', 'madex-chatbot'); ?></b><p><?php echo esc_html($detail['email_error'] ?: __('Die Anfrage ist gespeichert.', 'madex-chatbot')); ?></p></div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="madex_retry_appointment_email"><input type="hidden" name="appointment_id" value="<?php echo esc_attr($id); ?>"><?php wp_nonce_field('madex_retry_appointment_email_' . $id); ?><button class="button"><?php esc_html_e('Erneut senden', 'madex-chatbot'); ?></button></form>
            </div>
        <?php endif; ?>
        <dl class="mc-facts">
            <div><dt><?php esc_html_e('E-Mail', 'madex-chatbot'); ?></dt><dd><a href="mailto:<?php echo esc_attr($detail['email']); ?>"><?php echo esc_html($detail['email']); ?></a></dd></div>
            <div><dt><?php esc_html_e('Telefon', 'madex-chatbot'); ?></dt><dd><?php echo esc_html($detail['phone'] ?: '–'); ?></dd></div>
            <div><dt><?php esc_html_e('Interesse', 'madex-chatbot'); ?></dt><dd><?php echo esc_html(implode(' · ', array_filter(array(Madex_Business_Service::service_label($detail['service']), $detail['package_interest'])))); ?></dd></div>
            <div><dt><?php esc_html_e('Wunschtermin', 'madex-chatbot'); ?></dt><dd><?php echo esc_html($this->preferred_label($detail)); ?></dd></div>
            <div><dt><?php esc_html_e('Eingegangen', 'madex-chatbot'); ?></dt><dd><?php echo esc_html($this->format_datetime($detail['created_at'])); ?></dd></div>
            <div><dt><?php esc_html_e('E-Mail-Status', 'madex-chatbot'); ?></dt><dd><?php $this->email_badge($detail['email_status']); ?></dd></div>
            <div><dt><?php esc_html_e('Einwilligung', 'madex-chatbot'); ?></dt><dd><?php echo esc_html($detail['privacy_consent'] ? sprintf(__('erteilt am %s', 'madex-chatbot'), $this->format_datetime($detail['consent_at'])) : '–'); ?></dd></div>
        </dl>
        <?php if ($detail['message'] !== '') : ?><blockquote class="mc-quote"><?php echo nl2br(esc_html($detail['message'])); ?></blockquote><?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mc-stack" data-mc-dirty>
            <input type="hidden" name="action" value="madex_update_appointment"><input type="hidden" name="appointment_id" value="<?php echo esc_attr($id); ?>"><?php wp_nonce_field('madex_update_appointment_' . $id); ?>
            <label class="mc-field"><span><?php esc_html_e('Interne Notiz', 'madex-chatbot'); ?></span><textarea name="internal_notes" rows="3"><?php echo esc_textarea($detail['internal_notes']); ?></textarea></label>
            <div class="mc-inline">
                <label><span class="screen-reader-text"><?php esc_html_e('Status', 'madex-chatbot'); ?></span><select name="status"><?php foreach ($statuses as $key => $label) : ?><option value="<?php echo esc_attr($key); ?>" <?php selected($detail['status'], $key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
                <button class="button button-primary"><?php esc_html_e('Speichern', 'madex-chatbot'); ?></button>
            </div>
        </form>
        <div class="mc-timeline"><h3><?php esc_html_e('Verlauf', 'madex-chatbot'); ?></h3><ol>
            <?php foreach (array_reverse($detail['events']) as $event) : ?>
                <li><time><?php echo esc_html($this->format_datetime($event['created_at'], 'd.m. H:i')); ?></time><span><?php echo esc_html($this->event_label($event, $statuses)); ?></span></li>
            <?php endforeach; ?>
        </ol></div>
        <?php
    }

    private function event_label($event, $statuses) {
        $actor = '';
        if (!empty($event['actor_user_id'])) {
            $user = get_userdata((int) $event['actor_user_id']);
            $actor = $user ? ' · ' . $user->display_name : '';
        }
        $labels = array(
            'created' => __('Anfrage eingegangen', 'madex-chatbot'),
            'email_sent' => __('Benachrichtigung zugestellt', 'madex-chatbot'),
            'email_failed' => __('E-Mail-Benachrichtigung fehlgeschlagen', 'madex-chatbot'),
            'email_retry_requested' => __('E-Mail erneut angefordert', 'madex-chatbot'),
            'updated' => __('Notiz aktualisiert', 'madex-chatbot'),
        );
        if ($event['event_type'] === 'status_changed') {
            return sprintf(__('Status: %s', 'madex-chatbot'), isset($statuses[$event['new_status']]) ? $statuses[$event['new_status']] : $event['new_status']) . $actor;
        }
        return (isset($labels[$event['event_type']]) ? $labels[$event['event_type']] : $event['event_type']) . $actor;
    }

    public function update_appointment() {
        $this->require_admin();
        $id = absint($_POST['appointment_id'] ?? 0);
        check_admin_referer('madex_update_appointment_' . $id);
        $status = sanitize_key(wp_unslash($_POST['status'] ?? ''));
        $changes = array('internal_notes' => $_POST['internal_notes'] ?? '');
        if (array_key_exists($status, Madex_Business_Service::status_options())) {
            $changes['status'] = $status;
        }
        $result = Madex_Business_Service::update_appointment($id, $changes, get_current_user_id());
        $this->redirect('madex-chatbot-appointments', is_wp_error($result) ? 'error' : 'updated', is_wp_error($result) ? array() : array('ref' => $result['reference']));
    }

    public function retry_appointment_email() {
        $this->require_admin();
        $id = absint($_POST['appointment_id'] ?? 0);
        check_admin_referer('madex_retry_appointment_email_' . $id);
        $result = Madex_Business_Service::retry_appointment_email($id, get_current_user_id());
        $appointment = Madex_Business_Service::get_appointment($id);
        $args = is_wp_error($appointment) ? array() : array('ref' => $appointment['reference']);
        $this->redirect('madex-chatbot-appointments', is_wp_error($result) ? 'resend_failed' : 'resent', $args);
    }

    public function export_appointments() {
        $this->require_admin();
        check_admin_referer('madex_export_appointments');
        $status = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : '';
        $args = array_key_exists($status, Madex_Business_Service::status_options()) ? array('status' => $status) : array();
        $rows = Madex_Business_Service::export_appointments_csv_rows($args);
        $rows[0] = array('Referenz', 'Status', 'Eingegangen', 'Name', 'Unternehmen', 'E-Mail', 'Telefon', 'Kundenstatus', 'Leistung', 'Paket', 'Wunschdatum', 'Zeitfenster', 'E-Mail-Status', 'Anliegen');
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="madex-terminanfragen-' . wp_date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        foreach ($rows as $row) {
            fputcsv($out, $row, ';');
        }
        fclose($out);
        exit;
    }

    /* ==================================================================
     * Portal & 2FA
     * ================================================================== */

    public function render_portal() {
        $this->require_admin();
        $settings = wp_parse_args(get_option(self::PORTAL_SETTINGS, array()), array('idle_timeout' => 1800, 'retention_days' => 90));
        $appointment_settings = get_option(self::APPOINTMENT_SETTINGS, array());
        $recipients = isset($appointment_settings['notification_recipients']) ? (array) $appointment_settings['notification_recipients'] : array(get_option('admin_email'));
        $allowed = Madex_Portal_Auth::get_allowed_user_ids();
        $search = isset($_GET['user_search']) ? sanitize_text_field(wp_unslash($_GET['user_search'])) : '';
        $user_args = array('orderby' => 'display_name', 'order' => 'ASC', 'number' => 100);
        if ($search !== '') {
            $user_args['search'] = '*' . $search . '*';
            $user_args['search_columns'] = array('user_login', 'user_email', 'display_name');
        }
        $users = get_users($user_args);
        // Always show approved users even when they are outside the search.
        $listed = wp_list_pluck($users, 'ID');
        foreach ($allowed as $user_id) {
            if (!in_array($user_id, $listed, true) && ($user = get_userdata($user_id))) {
                array_unshift($users, $user);
            }
        }
        $portal_url = Madex_Portal_Auth::url('');

        $actions = '<a class="button button-primary" target="_blank" rel="noopener noreferrer" href="' . esc_url($portal_url) . '">' . esc_html__('Portal öffnen', 'madex-chatbot') . ' ↗</a>';
        $this->header(__('Portal & Zwei-Faktor-Authentifizierung', 'madex-chatbot'), __('Das Management-Portal ist vom WordPress-Admin getrennt. Nur hier freigegebene Benutzer können sich – immer mit 2FA – anmelden.', 'madex-chatbot'), $actions);
        ?>
        <?php if (!is_ssl() && wp_parse_url(home_url('/'), PHP_URL_SCHEME) !== 'https') : ?>
            <div class="mc-alert mc-alert--error"><span class="dashicons dashicons-lock" aria-hidden="true"></span><div><b><?php esc_html_e('HTTPS erforderlich', 'madex-chatbot'); ?></b><p><?php esc_html_e('Das Portal setzt ausschliesslich sichere Cookies und funktioniert nur über HTTPS. Bitte aktivieren Sie ein SSL-Zertifikat für die Website.', 'madex-chatbot'); ?></p></div></div>
        <?php endif; ?>

        <div class="mc-grid mc-grid--portal">
            <section class="mc-card">
                <div class="mc-card__head"><h2><?php esc_html_e('Portal-Einstellungen', 'madex-chatbot'); ?></h2></div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mc-stack" data-mc-dirty>
                    <input type="hidden" name="action" value="madex_save_portal_settings"><?php wp_nonce_field('madex_save_portal_settings'); ?>
                    <label class="mc-field"><span><?php esc_html_e('Dashboard-Pfad', 'madex-chatbot'); ?></span>
                        <span class="mc-prefix"><span><?php echo esc_html(untrailingslashit(home_url('/')) . '/'); ?></span><input type="text" name="slug" required pattern="[a-z0-9-]+" maxlength="60" value="<?php echo esc_attr(Madex_Portal_Auth::get_slug()); ?>"></span>
                        <small><?php esc_html_e('Nur Kleinbuchstaben, Zahlen und Bindestriche. Der Pfad ist kein Schutz – jeder Aufruf wird serverseitig geprüft.', 'madex-chatbot'); ?></small>
                    </label>
                    <div class="mc-fields">
                        <label class="mc-field"><span><?php esc_html_e('Automatische Abmeldung bei Inaktivität', 'madex-chatbot'); ?></span>
                            <select name="idle_timeout">
                                <?php foreach (array(900 => '15 Minuten', 1800 => '30 Minuten', 3600 => '60 Minuten') as $value => $label) : ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected((int) $settings['idle_timeout'], $value); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small><?php esc_html_e('Spätestens nach 8 Stunden ist immer eine neue Anmeldung nötig.', 'madex-chatbot'); ?></small>
                        </label>
                        <label class="mc-field"><span><?php esc_html_e('Chatverläufe aufbewahren', 'madex-chatbot'); ?></span>
                            <span class="mc-suffix"><input type="number" name="retention_days" min="1" max="3650" value="<?php echo esc_attr((int) $settings['retention_days']); ?>"><span><?php esc_html_e('Tage', 'madex-chatbot'); ?></span></span>
                            <small><?php esc_html_e('Terminanfragen bleiben erhalten.', 'madex-chatbot'); ?></small>
                        </label>
                    </div>
                    <label class="mc-field"><span><?php esc_html_e('E-Mail-Empfänger für Terminanfragen', 'madex-chatbot'); ?></span>
                        <textarea name="notification_recipients" rows="3" placeholder="info@madex-it.ch"><?php echo esc_textarea(implode("\n", $recipients)); ?></textarea>
                        <small><?php esc_html_e('Eine Adresse pro Zeile. Für zuverlässige Zustellung empfehlen wir ein SMTP-Plugin.', 'madex-chatbot'); ?></small>
                    </label>
                    <div><button class="button button-primary"><?php esc_html_e('Einstellungen speichern', 'madex-chatbot'); ?></button></div>
                </form>
            </section>

            <section class="mc-card mc-policy">
                <div class="mc-card__head"><h2><?php esc_html_e('Sicherheitsrichtlinie', 'madex-chatbot'); ?></h2></div>
                <ul>
                    <li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('2FA (TOTP, Google Authenticator-kompatibel) ist für alle Portal-Benutzer Pflicht.', 'madex-chatbot'); ?></li>
                    <li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Einmalige Wiederherstellungscodes (8 Stück), nur gehasht gespeichert.', 'madex-chatbot'); ?></li>
                    <li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Progressive Sperre: 5 Fehlversuche → 1 Min., 10 → 15 Min., 20 → 60 Min. (pro Konto und Netzwerk).', 'madex-chatbot'); ?></li>
                    <li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Generische Fehlermeldungen – es wird nie verraten, ob ein Benutzer existiert.', 'madex-chatbot'); ?></li>
                    <li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Eigene Sitzungen (HttpOnly, Secure, SameSite=Strict), kein WordPress-Login-Cookie, keine Admin-Leiste.', 'madex-chatbot'); ?></li>
                    <li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('noindex, strikte Content-Security-Policy, keine Versions- oder WordPress-Pfade im Portal.', 'madex-chatbot'); ?></li>
                </ul>
                <p class="mc-help"><?php esc_html_e('Tipp: Entfernen Sie zusätzlich den „Server“-Header in der Webserver-Konfiguration (z. B. ServerTokens Prod / server_tokens off).', 'madex-chatbot'); ?></p>
            </section>
        </div>

        <section class="mc-card mc-card--flush">
            <div class="mc-card__head mc-card__head--pad">
                <div><h2><?php esc_html_e('Benutzer & Rechte', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Freigegebene Benutzer melden sich mit ihrem WordPress-Benutzernamen und Passwort an. Beim ersten Login wird die 2FA eingerichtet.', 'madex-chatbot'); ?></p></div>
                <div class="mc-inline">
                    <form method="get" class="mc-search"><input type="hidden" name="page" value="madex-chatbot-portal"><label class="screen-reader-text" for="mc-user-search"><?php esc_html_e('Benutzer suchen', 'madex-chatbot'); ?></label><input id="mc-user-search" type="search" name="user_search" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Benutzer suchen …', 'madex-chatbot'); ?>"></form>
                    <a class="button" href="<?php echo esc_url(admin_url('user-new.php?role=' . Madex_Portal_Auth::VIEWER_ROLE)); ?>"><?php esc_html_e('Dashboard-Benutzer anlegen', 'madex-chatbot'); ?></a>
                </div>
            </div>
            <table class="mc-table">
                <thead><tr><th scope="col"><?php esc_html_e('Benutzer', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Rolle', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Portal-Zugang', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('2FA', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Aktionen', 'madex-chatbot'); ?></th></tr></thead>
                <tbody>
                    <?php foreach ($users as $user) :
                        $is_allowed = Madex_Portal_Auth::is_user_allowed($user->ID);
                        $twofa = Madex_Portal_Auth::get_2fa_status($user->ID);
                        $sessions = $is_allowed ? Madex_Portal_Auth::count_active_sessions($user->ID) : 0;
                        $role_names = array_map(function ($role) { $obj = get_role($role); return $obj ? translate_user_role(wp_roles()->role_names[$role] ?? $role) : $role; }, (array) $user->roles);
                        ?>
                        <tr class="<?php echo $is_allowed ? 'is-allowed' : ''; ?>">
                            <td><span class="mc-user"><span class="mc-avatar" aria-hidden="true"><?php echo esc_html(strtoupper(mb_substr($user->display_name, 0, 1))); ?></span><span><b><?php echo esc_html($user->display_name); ?></b><small><?php echo esc_html($user->user_login . ' · ' . $user->user_email); ?></small></span></span></td>
                            <td><?php echo esc_html(implode(', ', $role_names)); ?></td>
                            <td>
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" <?php echo $is_allowed ? 'data-mc-confirm="' . esc_attr__('Portal-Zugang entziehen und alle Sitzungen beenden?', 'madex-chatbot') . '"' : ''; ?>>
                                    <input type="hidden" name="action" value="madex_set_portal_access"><input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>"><input type="hidden" name="allowed" value="<?php echo $is_allowed ? '0' : '1'; ?>"><?php wp_nonce_field('madex_set_portal_access_' . $user->ID); ?>
                                    <button type="submit" class="mc-toggle<?php echo $is_allowed ? ' is-on' : ''; ?>" aria-pressed="<?php echo $is_allowed ? 'true' : 'false'; ?>"><span class="mc-toggle__track" aria-hidden="true"></span><span><?php echo $is_allowed ? esc_html__('Freigegeben', 'madex-chatbot') : esc_html__('Kein Zugang', 'madex-chatbot'); ?></span></button>
                                </form>
                            </td>
                            <td>
                                <?php if (!$is_allowed) : ?>
                                    <span class="mc-muted">–</span>
                                <?php elseif ($twofa['enrolled'] && !$twofa['force_reenroll']) : ?>
                                    <span class="mc-badge mc-badge--success">✓ <?php esc_html_e('Aktiv', 'madex-chatbot'); ?></span>
                                    <small class="mc-muted"><?php echo esc_html(sprintf(__('%d Codes übrig', 'madex-chatbot'), $twofa['recovery_codes_remaining'])); ?><?php echo $sessions ? esc_html(' · ' . sprintf(_n('%d Sitzung', '%d Sitzungen', $sessions, 'madex-chatbot'), $sessions)) : ''; ?></small>
                                <?php else : ?>
                                    <span class="mc-badge mc-badge--warning">◷ <?php esc_html_e('Einrichtung beim nächsten Login', 'madex-chatbot'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="mc-actions"><div class="mc-actions__inner">
                                <?php if ($is_allowed && $twofa['enrolled']) : ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-mc-confirm="<?php esc_attr_e('2FA zurücksetzen? Der Benutzer muss beim nächsten Login einen neuen QR-Code scannen.', 'madex-chatbot'); ?>"><input type="hidden" name="action" value="madex_reset_portal_2fa"><input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>"><?php wp_nonce_field('madex_reset_portal_2fa_' . $user->ID); ?><button class="button-link"><?php esc_html_e('2FA zurücksetzen', 'madex-chatbot'); ?></button></form>
                                <?php endif; ?>
                                <?php if ($sessions > 0) : ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="madex_revoke_portal_sessions"><input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>"><?php wp_nonce_field('madex_revoke_portal_sessions_' . $user->ID); ?><button class="button-link button-link-delete"><?php esc_html_e('Abmelden erzwingen', 'madex-chatbot'); ?></button></form>
                                <?php endif; ?>
                            </div></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
        <?php
        $this->footer();
    }

    public function save_portal_settings() {
        $this->require_admin();
        check_admin_referer('madex_save_portal_settings');

        Madex_Portal_Auth::set_slug(wp_unslash($_POST['slug'] ?? 'chatadm'));

        $idle = absint($_POST['idle_timeout'] ?? 1800);
        $settings = get_option(self::PORTAL_SETTINGS, array());
        $settings['idle_timeout'] = in_array($idle, array(900, 1800, 3600), true) ? $idle : 1800;
        $settings['retention_days'] = max(1, min(3650, absint($_POST['retention_days'] ?? 90)));
        update_option(self::PORTAL_SETTINGS, $settings, false);

        $emails = array();
        foreach (preg_split('/[\r\n,;]+/', (string) wp_unslash($_POST['notification_recipients'] ?? '')) as $email) {
            $email = sanitize_email(trim($email));
            if ($email && is_email($email)) {
                $emails[] = $email;
            }
        }
        $appointment = get_option(self::APPOINTMENT_SETTINGS, array());
        $appointment['notification_recipients'] = array_values(array_unique($emails));
        update_option(self::APPOINTMENT_SETTINGS, $appointment, false);

        $this->redirect('madex-chatbot-portal', 'saved');
    }

    public function set_portal_access() {
        $this->require_admin();
        $user_id = absint($_POST['user_id'] ?? 0);
        check_admin_referer('madex_set_portal_access_' . $user_id);
        $allowed = !empty($_POST['allowed']);
        $result = Madex_Portal_Auth::set_user_access($user_id, $allowed);
        $this->redirect('madex-chatbot-portal', is_wp_error($result) ? 'error' : ($allowed ? 'access_on' : 'access_off'));
    }

    public function reset_portal_2fa() {
        $this->require_admin();
        $user_id = absint($_POST['user_id'] ?? 0);
        check_admin_referer('madex_reset_portal_2fa_' . $user_id);
        $result = Madex_Portal_Auth::reset_user_2fa($user_id);
        $this->redirect('madex-chatbot-portal', is_wp_error($result) ? 'error' : 'reset');
    }

    public function revoke_portal_sessions() {
        $this->require_admin();
        $user_id = absint($_POST['user_id'] ?? 0);
        check_admin_referer('madex_revoke_portal_sessions_' . $user_id);
        $result = Madex_Portal_Auth::revoke_user_sessions($user_id, 'admin_revoked');
        $this->redirect('madex-chatbot-portal', $result === false ? 'error' : 'revoked');
    }

    /* ==================================================================
     * Reports
     * ================================================================== */

    public function render_reports() {
        $this->require_admin();
        $days = isset($_GET['days']) ? absint($_GET['days']) : 30;
        $days = in_array($days, array(7, 30, 90, 365), true) ? $days : 30;
        $report = Madex_Business_Service::get_report_series($days);
        $total_chats = array_sum(wp_list_pluck($report['series'], 'conversations'));
        $total_appts = array_sum(wp_list_pluck($report['series'], 'appointments'));
        $max = max(1, max(array_merge(wp_list_pluck($report['series'], 'conversations'), array(1))));
        $statuses = Madex_Business_Service::status_options();

        $export = wp_nonce_url(admin_url('admin-post.php?action=madex_export_appointments'), 'madex_export_appointments');
        $this->header(__('Berichte', 'madex-chatbot'), __('Operative Trends ohne API-, Modell-, Token- oder Kosteninformationen.', 'madex-chatbot'), '<a class="button" href="' . esc_url($export) . '">' . esc_html__('CSV exportieren', 'madex-chatbot') . '</a>');
        ?>
        <nav class="mc-pills mc-pills--spaced" aria-label="<?php esc_attr_e('Zeitraum', 'madex-chatbot'); ?>">
            <?php foreach (array(7 => '7 Tage', 30 => '30 Tage', 90 => '90 Tage', 365 => '12 Monate') as $value => $label) : ?>
                <a class="<?php echo $days === $value ? 'is-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=madex-chatbot-reports&days=' . $value)); ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>
        <section class="mc-kpis mc-kpis--three">
            <?php
            $this->kpi(__('Gespräche', 'madex-chatbot'), $total_chats, sprintf(__('letzte %d Tage', 'madex-chatbot'), $days));
            $this->kpi(__('Terminanfragen', 'madex-chatbot'), $total_appts, sprintf(__('letzte %d Tage', 'madex-chatbot'), $days));
            $this->kpi(__('Anfragequote (%)', 'madex-chatbot'), $total_chats ? round($total_appts / $total_chats * 100, 1) : 0, __('Anfragen pro Gespräch', 'madex-chatbot'));
            ?>
        </section>
        <section class="mc-card">
            <div class="mc-card__head"><h2><?php esc_html_e('Gespräche und Anfragen pro Tag', 'madex-chatbot'); ?></h2><span class="mc-legend"><i class="is-chat"></i><?php esc_html_e('Gespräche', 'madex-chatbot'); ?> <i class="is-appt"></i><?php esc_html_e('Anfragen', 'madex-chatbot'); ?></span></div>
            <div class="mc-bars" role="img" aria-label="<?php echo esc_attr(sprintf(__('%1$d Gespräche und %2$d Anfragen', 'madex-chatbot'), $total_chats, $total_appts)); ?>">
                <?php foreach ($report['series'] as $point) : ?>
                    <span class="mc-bars__day" title="<?php echo esc_attr(gmdate('d.m.Y', strtotime($point['date'] . ' UTC')) . ': ' . $point['conversations'] . ' / ' . $point['appointments']); ?>">
                        <span class="mc-bars__chat" style="height: <?php echo esc_attr(round($point['conversations'] / $max * 100, 1)); ?>%"></span>
                        <span class="mc-bars__appt" style="height: <?php echo esc_attr(round($point['appointments'] / $max * 100, 1)); ?>%"></span>
                    </span>
                <?php endforeach; ?>
            </div>
        </section>
        <div class="mc-grid mc-grid--three">
            <?php
            $blocks = array(
                __('Häufige Anliegen', 'madex-chatbot') => array_map(function ($row) { return array(Madex_Business_Service::service_label($row['label']), $row['total']); }, $report['topics'] ?: $report['services']),
                __('Paketinteresse', 'madex-chatbot') => array_map(function ($row) { return array($row['label'], $row['total']); }, $report['packages']),
                __('Status der Anfragen', 'madex-chatbot') => array_map(function ($row) use ($statuses) { return array(isset($statuses[$row['label']]) ? $statuses[$row['label']] : $row['label'], $row['total']); }, $report['appointment_statuses']),
            );
            foreach ($blocks as $title => $rows) :
                ?>
                <section class="mc-card"><h2><?php echo esc_html($title); ?></h2>
                    <?php if (empty($rows)) : ?><p class="mc-muted"><?php esc_html_e('Keine Daten im Zeitraum.', 'madex-chatbot'); ?></p><?php else : ?>
                        <table class="mc-table mc-table--compact"><tbody><?php foreach ($rows as $row) : ?><tr><td><?php echo esc_html($row[0]); ?></td><td class="mc-num"><?php echo esc_html(number_format_i18n((int) $row[1])); ?></td></tr><?php endforeach; ?></tbody></table>
                    <?php endif; ?>
                </section>
            <?php endforeach; ?>
        </div>
        <?php
        $this->footer();
    }

    /* ==================================================================
     * Audit log
     * ================================================================== */

    public function render_audit() {
        $this->require_admin();
        $events = Madex_Portal_Auth::get_recent_audit(150);
        $labels = array(
            'password_login' => __('Passwort-Anmeldung', 'madex-chatbot'),
            'password_rate_limited' => __('Anmeldung gedrosselt', 'madex-chatbot'),
            'portal_access' => __('Portal-Zugriff', 'madex-chatbot'),
            'totp_enrollment' => __('2FA-Einrichtung', 'madex-chatbot'),
            'totp_login' => __('2FA-Bestätigung', 'madex-chatbot'),
            'recovery_login' => __('Anmeldung mit Wiederherstellungscode', 'madex-chatbot'),
            'portal_logout' => __('Abmeldung', 'madex-chatbot'),
            'portal_session' => __('Sitzung', 'madex-chatbot'),
            'portal_sessions_revoked' => __('Sitzungen beendet', 'madex-chatbot'),
            'portal_access_changed' => __('Zugang geändert', 'madex-chatbot'),
            'two_factor_reset' => __('2FA zurückgesetzt', 'madex-chatbot'),
        );
        $bad = array('failed', 'blocked', 'denied', 'revoked');

        $this->header(__('Audit-Log', 'madex-chatbot'), __('Sicherheitsereignisse des Management-Portals. IP-Adressen und Browser werden nur als nicht umkehrbare Hashes gespeichert.', 'madex-chatbot'));
        ?>
        <section class="mc-card mc-card--flush">
            <?php if (empty($events)) : ?>
                <div class="mc-empty"><span class="dashicons dashicons-shield" aria-hidden="true"></span><b><?php esc_html_e('Noch keine Ereignisse', 'madex-chatbot'); ?></b></div>
            <?php else : ?>
                <table class="mc-table">
                    <thead><tr><th scope="col"><?php esc_html_e('Zeit', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Ereignis', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Ergebnis', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Benutzer', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Details', 'madex-chatbot'); ?></th></tr></thead>
                    <tbody>
                        <?php foreach ($events as $event) :
                            $user = $event['user_id'] ? get_userdata((int) $event['user_id']) : null;
                            $data = $event['data'] ? json_decode($event['data'], true) : array();
                            ?>
                            <tr>
                                <td class="mc-mono"><?php echo esc_html(wp_date('d.m.Y H:i:s', (int) $event['created_at'])); ?></td>
                                <td><?php echo esc_html(isset($labels[$event['event_type']]) ? $labels[$event['event_type']] : $event['event_type']); ?></td>
                                <td><span class="mc-badge mc-badge--<?php echo in_array($event['result'], $bad, true) ? 'error' : 'success'; ?>"><?php echo esc_html($event['result']); ?></span></td>
                                <td><?php echo $user ? esc_html($user->display_name) : '<span class="mc-muted">' . esc_html__('unbekannt', 'madex-chatbot') . '</span>'; ?></td>
                                <td class="mc-muted"><?php echo esc_html(is_array($data) ? implode(', ', array_map(function ($k, $v) { return $k . ': ' . $v; }, array_keys($data), $data)) : ''); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
        <?php
        $this->footer();
    }

    /* ==================================================================
     * System status
     * ================================================================== */

    private function system_checks() {
        global $wpdb;
        $settings = get_option('madex_chatbot_settings', array());
        $appointment = get_option(self::APPOINTMENT_SETTINGS, array());
        $openai = new Madex_OpenAI_Service();
        $tables = array('madex_chat_sessions', 'madex_chat_messages', 'madex_packages', 'madex_appointments', 'madex_appointment_events', 'madex_portal_security', 'madex_portal_sessions', 'madex_portal_auth_limits', 'madex_portal_audit');
        $missing = array();
        foreach ($tables as $table) {
            $name = $wpdb->prefix . $table;
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $name)) !== $name) {
                $missing[] = $table;
            }
        }
        $has_packages = Madex_Business_Service::list_packages(array('active' => 1, 'per_page' => 1))['total'] > 0;

        return array(
            array('label' => __('HTTPS', 'madex-chatbot'), 'ok' => is_ssl() || wp_parse_url(home_url('/'), PHP_URL_SCHEME) === 'https', 'detail' => __('Pflicht für sichere Portal-Cookies.', 'madex-chatbot'), 'required' => true),
            array('label' => __('Authentifizierte Verschlüsselung', 'madex-chatbot'), 'ok' => Madex_Encryption::is_available(), 'detail' => __('Sodium oder AES-256-GCM für API-Schlüssel und 2FA-Geheimnisse.', 'madex-chatbot'), 'required' => true),
            array('label' => __('Datenbanktabellen', 'madex-chatbot'), 'ok' => empty($missing), 'detail' => empty($missing) ? __('Alle Tabellen vorhanden.', 'madex-chatbot') : sprintf(__('Fehlend: %s – Plugin einmal deaktivieren und wieder aktivieren.', 'madex-chatbot'), implode(', ', $missing)), 'required' => true),
            array('label' => __('Chatbot aktiviert', 'madex-chatbot'), 'ok' => !empty($settings['enabled']), 'detail' => __('Einstellungen → Allgemein.', 'madex-chatbot'), 'required' => false),
            array('label' => __('KI-Verbindung konfiguriert', 'madex-chatbot'), 'ok' => $openai->is_configured(), 'detail' => __('Ohne Schlüssel leitet der Chat alle Fragen an das Team weiter.', 'madex-chatbot'), 'required' => true),
            array('label' => __('E-Mail-Empfänger', 'madex-chatbot'), 'ok' => !empty($appointment['notification_recipients']), 'detail' => __('Sonst wird die Admin-E-Mail der Website verwendet.', 'madex-chatbot'), 'required' => false),
            array('label' => __('Portal-Benutzer freigegeben', 'madex-chatbot'), 'ok' => count(Madex_Portal_Auth::get_allowed_user_ids()) > 0, 'detail' => __('Portal & 2FA → Benutzer & Rechte.', 'madex-chatbot'), 'required' => false),
            array('label' => __('Aktive Pakete', 'madex-chatbot'), 'ok' => $has_packages, 'detail' => __('Ohne Pakete bietet der Chat direkt eine Beratung an.', 'madex-chatbot'), 'required' => false),
            array('label' => __('Wartungsaufgabe (Cron)', 'madex-chatbot'), 'ok' => (bool) wp_next_scheduled('madex_chatbot_cleanup_guest_sessions'), 'detail' => __('Löscht abgelaufene Sitzungen und alte Chats stündlich.', 'madex-chatbot'), 'required' => false),
            array('label' => __('Fehleranzeige deaktiviert', 'madex-chatbot'), 'ok' => !(defined('WP_DEBUG') && WP_DEBUG && (!defined('WP_DEBUG_DISPLAY') || WP_DEBUG_DISPLAY)), 'detail' => __('WP_DEBUG_DISPLAY sollte auf Live-Systemen aus sein, damit keine technischen Details sichtbar werden.', 'madex-chatbot'), 'required' => true),
        );
    }

    public function render_system() {
        $this->require_admin();
        $checks = $this->system_checks();
        $this->header(__('Systemstatus', 'madex-chatbot'), __('Bereitschaftsprüfung ohne Anzeige von Geheimnissen oder Serverversionen.', 'madex-chatbot'));
        ?>
        <section class="mc-card mc-card--flush">
            <ul class="mc-checks">
                <?php foreach ($checks as $check) : ?>
                    <li class="<?php echo $check['ok'] ? 'is-ok' : ($check['required'] ? 'is-error' : 'is-warning'); ?>">
                        <span class="mc-checks__icon" aria-hidden="true"><?php echo $check['ok'] ? '✓' : '!'; ?></span>
                        <span class="mc-checks__text"><b><?php echo esc_html($check['label']); ?></b><small><?php echo esc_html($check['detail']); ?></small></span>
                        <strong><?php echo $check['ok'] ? esc_html__('Bereit', 'madex-chatbot') : ($check['required'] ? esc_html__('Handlung nötig', 'madex-chatbot') : esc_html__('Empfohlen', 'madex-chatbot')); ?></strong>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
        <?php
        $this->footer();
    }
}
