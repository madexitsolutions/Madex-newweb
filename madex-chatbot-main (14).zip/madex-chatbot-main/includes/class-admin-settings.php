<?php
/**
 * Settings, knowledge base and chat history screens in WordPress Admin.
 *
 * Every form posts to admin-post.php and redirects back (post/redirect/get),
 * so a reload never re-submits and errors are shown instead of a false
 * "saved" message. Options are written directly with update_option(); no
 * register_setting() sanitizer runs a second time over already-encrypted
 * values.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Admin_Settings {

    const PAGE = 'madex-chatbot';

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_post_madex_save_settings', array($this, 'handle_save'));
        add_action('admin_post_madex_knowledge', array($this, 'handle_knowledge'));
    }

    /**
     * Defaults for the look-and-greeting option.
     *
     * @return array
     */
    public static function branding_defaults() {
        return array(
            'chat_title' => 'Orion',
            'welcome_message' => 'Hallo, ich bin Orion, der KI-Assistent von Madex IT Solutions. Wie kann ich Ihnen helfen?',
            'contact_phone' => "052 589 67 59\n076 507 33 32",
            'contact_email' => 'info@madex-it.ch',
            'mail_from_name' => 'Madex IT Solutions',
            'mail_from_email' => 'info@madex-it.ch',
            'teaser_enabled' => true,
            'teaser_message' => 'Hallo, ich bin Orion, der KI-Assistent von Madex IT Solutions 👋 Haben Sie Fragen? Ich berate Sie gerne.',
            'teaser_delay' => 6,
            'teaser_mobile' => false,
        );
    }

    /**
     * Website areas the assistant can link to as buttons ([[seite:key]]).
     * "heading" lets the widget scroll to the area when it is on the page.
     *
     * @return array[]
     */
    public static function page_sections() {
        $home = home_url('/');
        $sections = array(
            array('key' => 'pakete', 'label' => 'Pakete ansehen', 'url' => $home, 'heading' => 'Unsere meistgebuchten Marketing-Pakete'),
            array('key' => 'analyse', 'label' => 'Kostenlose Analyse', 'url' => home_url('/kostenlose-prufung/'), 'heading' => ''),
            array('key' => 'kontakt', 'label' => 'Kontaktseite', 'url' => home_url('/kontakt/'), 'heading' => ''),
            array('key' => 'portfolio', 'label' => 'Referenzen ansehen', 'url' => home_url('/portfolio/'), 'heading' => ''),
            array('key' => 'webdesign', 'label' => 'Webdesign', 'url' => home_url('/marketing-solutions/website-development/'), 'heading' => ''),
            array('key' => 'seo', 'label' => 'SEO-Optimierung', 'url' => home_url('/marketing-solutions/seo-optimierung/'), 'heading' => ''),
            array('key' => 'google-ads', 'label' => 'Google Marketing', 'url' => home_url('/marketing-solutions/google-marketing/'), 'heading' => ''),
            array('key' => 'social-media', 'label' => 'Social Media Marketing', 'url' => home_url('/marketing-solutions/social-media-marketing/'), 'heading' => ''),
        );
        return apply_filters('madex_chatbot_page_sections', $sections);
    }

    /**
     * @return array
     */
    public static function security_defaults() {
        return array(
            'rate_limit_per_minute' => 10,
            'guest_messages_per_day' => 100,
            'message_cooldown' => 1,
            'min_message_length' => 1,
            'max_message_length' => 1000,
            'block_spam' => true,
            'log_security_events' => true,
        );
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Madex Chatbot', 'madex-chatbot'),
            __('Madex Chatbot', 'madex-chatbot'),
            'manage_options',
            self::PAGE,
            array($this, 'render_main_page'),
            'dashicons-format-chat',
            30
        );

        add_submenu_page(self::PAGE, __('Einstellungen', 'madex-chatbot'), __('Einstellungen', 'madex-chatbot'), 'manage_options', self::PAGE, array($this, 'render_main_page'));
        add_submenu_page(self::PAGE, __('Wissensdatenbank', 'madex-chatbot'), __('Wissensdatenbank', 'madex-chatbot'), 'manage_options', 'madex-chatbot-knowledge', array($this, 'render_knowledge_page'));
        add_submenu_page(self::PAGE, __('Chatverläufe', 'madex-chatbot'), __('Chatverläufe', 'madex-chatbot'), 'manage_options', 'madex-chatbot-sessions', array($this, 'render_sessions_page'));
    }

    /* ==================================================================
     * Shared chrome
     * ================================================================== */

    private function header($title, $description = '') {
        ?>
        <div class="wrap madex-control">
            <header class="mc-header">
                <img class="mc-header__logo" src="<?php echo esc_url(MADEX_CHATBOT_PLUGIN_URL . 'assets/images/logo-madex.png'); ?>" alt="Madex IT Solutions" width="132" height="28">
                <div class="mc-header__text">
                    <h1><?php echo esc_html($title); ?></h1>
                    <?php if ($description !== '') : ?><p><?php echo esc_html($description); ?></p><?php endif; ?>
                </div>
                <span class="mc-dirty" data-mc-dirty-indicator hidden>● <?php esc_html_e('Ungespeicherte Änderungen', 'madex-chatbot'); ?></span>
            </header>
            <hr class="wp-header-end">
            <?php $this->notice(); ?>
        <?php
    }

    private function notice() {
        $notice = isset($_GET['madex_notice']) ? sanitize_key(wp_unslash($_GET['madex_notice'])) : '';
        $messages = array(
            'saved' => array('success', __('Änderungen gespeichert.', 'madex-chatbot')),
            'key_saved' => array('success', __('API-Schlüssel gespeichert. Mit «Verbindung testen» prüfen Sie, ob er funktioniert.', 'madex-chatbot')),
            'key_removed' => array('success', __('API-Schlüssel entfernt. Der Chat leitet Fragen nun direkt an das Team weiter.', 'madex-chatbot')),
            'key_format' => array('error', __('Der API-Schlüssel wurde nicht gespeichert: OpenAI-Schlüssel beginnen mit «sk-». Bitte kopieren Sie ihn vollständig aus Ihrem OpenAI-Konto.', 'madex-chatbot')),
            'key_encrypt' => array('error', __('Der API-Schlüssel konnte nicht verschlüsselt werden und wurde nicht gespeichert. Prüfen Sie unter Systemstatus die Verschlüsselung.', 'madex-chatbot')),
            'kb_added' => array('success', __('Eintrag hinzugefügt. Der Assistent verwendet ihn ab sofort.', 'madex-chatbot')),
            'kb_updated' => array('success', __('Eintrag aktualisiert.', 'madex-chatbot')),
            'kb_deleted' => array('success', __('Eintrag gelöscht.', 'madex-chatbot')),
            'error' => array('error', __('Die Aktion konnte nicht ausgeführt werden. Bitte prüfen Sie die Eingaben.', 'madex-chatbot')),
        );
        if (!isset($messages[$notice])) {
            return;
        }
        printf(
            '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
            esc_attr($messages[$notice][0]),
            esc_html($messages[$notice][1])
        );
    }

    private function redirect($page, $args = array()) {
        wp_safe_redirect(add_query_arg(array_merge(array('page' => $page), $args), admin_url('admin.php')));
        exit;
    }

    private function require_admin() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sie dürfen den Madex Chatbot nicht verwalten.', 'madex-chatbot'), 403);
        }
    }

    private function tabs() {
        return array(
            'general' => __('Allgemein', 'madex-chatbot'),
            'ai' => __('KI & Wissen', 'madex-chatbot'),
            'greeting' => __('Begrüssung', 'madex-chatbot'),
            'datasources' => __('Datenquellen', 'madex-chatbot'),
            'security' => __('Sicherheit', 'madex-chatbot'),
        );
    }

    /**
     * Decrypted key state for display; the key itself never reaches the page.
     *
     * @return array{stored: bool, valid: bool, masked: string}
     */
    private function api_key_state() {
        $settings = get_option('madex_chatbot_settings', array());
        $stored = !empty($settings['api_key']);
        $plain = $stored ? Madex_Encryption::decrypt($settings['api_key']) : '';
        $valid = is_string($plain) && strpos($plain, 'sk-') === 0;
        return array(
            'stored' => $stored,
            'valid' => $valid,
            'masked' => $valid ? Madex_Encryption::mask_api_key($settings['api_key']) : '',
        );
    }

    /* ==================================================================
     * Settings page
     * ================================================================== */

    public function render_main_page() {
        $this->require_admin();
        $tabs = $this->tabs();
        $active = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'general';
        if (!isset($tabs[$active])) {
            $active = 'general';
        }

        $this->header(__('Einstellungen', 'madex-chatbot'), __('Wie sich der Assistent auf Ihrer Website verhält, was er über Madex weiss und wie er Besucher begrüsst.', 'madex-chatbot'));
        ?>
        <nav class="mc-tabs" aria-label="<?php esc_attr_e('Einstellungsbereiche', 'madex-chatbot'); ?>">
            <?php foreach ($tabs as $key => $label) : ?>
                <a href="<?php echo esc_url(add_query_arg(array('page' => self::PAGE, 'tab' => $key), admin_url('admin.php'))); ?>" class="<?php echo $key === $active ? 'is-active' : ''; ?>" <?php echo $key === $active ? 'aria-current="page"' : ''; ?>><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mc-settings" data-mc-dirty autocomplete="off">
            <input type="hidden" name="action" value="madex_save_settings">
            <input type="hidden" name="tab" value="<?php echo esc_attr($active); ?>">
            <?php wp_nonce_field('madex_save_settings'); ?>
            <?php
            switch ($active) {
                case 'ai':
                    $this->render_ai_tab();
                    break;
                case 'greeting':
                    $this->render_greeting_tab();
                    break;
                case 'datasources':
                    $this->render_datasources_tab();
                    break;
                case 'security':
                    $this->render_security_tab();
                    break;
                default:
                    $this->render_general_tab();
            }
            ?>
            <div class="mc-savebar">
                <button type="submit" class="button button-primary"><?php esc_html_e('Änderungen speichern', 'madex-chatbot'); ?></button>
            </div>
        </form>
        </div>
        <?php
    }

    private function render_general_tab() {
        $settings = get_option('madex_chatbot_settings', array());
        $branding = wp_parse_args(get_option('madex_chatbot_branding', array()), self::branding_defaults());
        $key = $this->api_key_state();
        $packages = Madex_Business_Service::list_packages(array('active' => 1, 'per_page' => 1));
        global $wpdb;
        $kb_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}madex_knowledge_base");
        $steps = array(
            array(!empty($settings['enabled']), __('Chatbot ist auf der Website sichtbar', 'madex-chatbot'), __('Schalter oben einschalten.', 'madex-chatbot'), ''),
            array($key['valid'], __('KI-Verbindung eingerichtet', 'madex-chatbot'), __('OpenAI-API-Schlüssel unter «KI & Wissen» hinterlegen.', 'madex-chatbot'), 'ai'),
            array(true, __('Unternehmenswissen vorhanden', 'madex-chatbot'), Madex_Company_Knowledge::is_customised() ? __('Eigene Fassung aktiv.', 'madex-chatbot') : __('Standardprofil von madex-it.ch aktiv.', 'madex-chatbot'), 'ai'),
            array($packages['total'] > 0, sprintf(_n('%d aktives Paket für Empfehlungen', '%d aktive Pakete für Empfehlungen', $packages['total'], 'madex-chatbot'), $packages['total']), __('Unter «Pakete & Regeln» anlegen.', 'madex-chatbot'), 'packages'),
            array(true, sprintf(_n('%d zusätzlicher Wissenseintrag', '%d zusätzliche Wissenseinträge', $kb_count, 'madex-chatbot'), $kb_count), __('Optional: FAQ, Angebote, Referenzen in der Wissensdatenbank.', 'madex-chatbot'), 'knowledge'),
        );
        $links = array(
            'ai' => add_query_arg(array('page' => self::PAGE, 'tab' => 'ai'), admin_url('admin.php')),
            'packages' => admin_url('admin.php?page=madex-chatbot-packages'),
            'knowledge' => admin_url('admin.php?page=madex-chatbot-knowledge'),
        );
        ?>
        <div class="mc-grid mc-grid--two">
            <section class="mc-card">
                <div class="mc-card__head"><h2><?php esc_html_e('Chatbot', 'madex-chatbot'); ?></h2></div>
                <div class="mc-stack">
                    <input type="hidden" name="settings[enabled]" value="0">
                    <label class="mc-switch"><input type="checkbox" name="settings[enabled]" value="1" <?php checked(!empty($settings['enabled'])); ?>><span class="mc-switch__track" aria-hidden="true"></span><span><?php esc_html_e('Chat-Widget auf der Website anzeigen', 'madex-chatbot'); ?></span></label>
                    <p class="mc-help"><?php esc_html_e('Ausgeschaltet bleibt das Widget für alle Besucher unsichtbar. Einstellungen und Daten bleiben erhalten.', 'madex-chatbot'); ?></p>
                </div>
            </section>

            <section class="mc-card">
                <div class="mc-card__head"><h2><?php esc_html_e('Direkter Kontakt', 'madex-chatbot'); ?></h2></div>
                <div class="mc-stack">
                    <div class="mc-fields">
                        <label class="mc-field"><span><?php esc_html_e('Telefonnummern', 'madex-chatbot'); ?></span>
                            <textarea name="branding[contact_phone]" rows="2"><?php echo esc_textarea($branding['contact_phone']); ?></textarea>
                            <small><?php esc_html_e('Eine Nummer pro Zeile.', 'madex-chatbot'); ?></small>
                        </label>
                        <label class="mc-field"><span><?php esc_html_e('E-Mail', 'madex-chatbot'); ?></span>
                            <input type="email" name="branding[contact_email]" value="<?php echo esc_attr($branding['contact_email']); ?>">
                            <small><?php esc_html_e('Wird angezeigt, wenn der Assistent an das Team übergibt.', 'madex-chatbot'); ?></small>
                        </label>
                        <label class="mc-field"><span><?php esc_html_e('Absender-Name für E-Mails', 'madex-chatbot'); ?></span>
                            <input type="text" name="branding[mail_from_name]" maxlength="80" value="<?php echo esc_attr($branding['mail_from_name']); ?>">
                        </label>
                        <label class="mc-field"><span><?php esc_html_e('Absender-E-Mail', 'madex-chatbot'); ?></span>
                            <input type="email" name="branding[mail_from_email]" value="<?php echo esc_attr($branding['mail_from_email']); ?>">
                            <small><?php esc_html_e('Absender der Chatbot-E-Mails. Die Adresse sollte zur Domain der Website gehören.', 'madex-chatbot'); ?></small>
                        </label>
                    </div>
                </div>
            </section>
        </div>

        <section class="mc-card mc-card--flush">
            <div class="mc-card__head mc-card__head--pad"><h2><?php esc_html_e('Einrichtung', 'madex-chatbot'); ?></h2></div>
            <ul class="mc-checks">
                <?php foreach ($steps as $step) : ?>
                    <li class="<?php echo $step[0] ? 'is-ok' : 'is-warning'; ?>">
                        <span class="mc-checks__icon" aria-hidden="true"><?php echo $step[0] ? '✓' : '!'; ?></span>
                        <span class="mc-checks__text"><b><?php echo esc_html($step[1]); ?></b><small><?php echo esc_html($step[2]); ?></small></span>
                        <?php if ($step[3] !== '') : ?><a href="<?php echo esc_url($links[$step[3]]); ?>"><?php esc_html_e('Öffnen', 'madex-chatbot'); ?></a><?php else : ?><span></span><?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
        <?php
    }

    private function render_ai_tab() {
        $settings = get_option('madex_chatbot_settings', array());
        $directive = get_option('madex_chatbot_directive', array());
        $key = $this->api_key_state();
        $model = $settings['model'] ?? 'gpt-4o-mini';
        $models = array(
            'gpt-4o-mini' => __('GPT-4o mini – schnell und günstig (empfohlen)', 'madex-chatbot'),
            'gpt-4.1-mini' => __('GPT-4.1 mini – präziser, weiterhin günstig', 'madex-chatbot'),
            'gpt-4o' => __('GPT-4o – höchste Qualität', 'madex-chatbot'),
            'gpt-4.1' => __('GPT-4.1 – höchste Qualität, längere Antworten', 'madex-chatbot'),
        );
        if (!isset($models[$model])) {
            $models = array($model => $model) + $models;
        }
        ?>
        <section class="mc-card">
            <div class="mc-card__head">
                <div><h2><?php esc_html_e('OpenAI-Verbindung', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Der Schlüssel wird verschlüsselt gespeichert und nie wieder vollständig angezeigt.', 'madex-chatbot'); ?></p></div>
                <?php if ($key['valid']) : ?>
                    <span class="mc-badge mc-badge--success">✓ <?php esc_html_e('Schlüssel hinterlegt', 'madex-chatbot'); ?></span>
                <?php elseif ($key['stored']) : ?>
                    <span class="mc-badge mc-badge--error">! <?php esc_html_e('Schlüssel unlesbar – bitte neu eingeben', 'madex-chatbot'); ?></span>
                <?php else : ?>
                    <span class="mc-badge mc-badge--warning">! <?php esc_html_e('Kein Schlüssel', 'madex-chatbot'); ?></span>
                <?php endif; ?>
            </div>
            <div class="mc-stack">
                <div class="mc-fields">
                    <label class="mc-field"><span><?php echo $key['valid'] ? esc_html__('Neuer API-Schlüssel', 'madex-chatbot') : esc_html__('API-Schlüssel', 'madex-chatbot'); ?></span>
                        <span class="mc-secret">
                            <input type="password" id="madex-api-key" name="settings[api_key]" value="" spellcheck="false" autocomplete="new-password" placeholder="<?php echo esc_attr($key['valid'] ? $key['masked'] : 'sk-…'); ?>">
                            <button type="button" class="button" data-mc-reveal="madex-api-key" aria-pressed="false"><?php esc_html_e('Anzeigen', 'madex-chatbot'); ?></button>
                        </span>
                        <small><?php echo $key['valid'] ? esc_html__('Leer lassen, um den gespeicherten Schlüssel zu behalten.', 'madex-chatbot') : wp_kses(__('Erstellen Sie einen Schlüssel unter <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer">platform.openai.com/api-keys</a> und fügen Sie ihn hier ein.', 'madex-chatbot'), array('a' => array('href' => true, 'target' => true, 'rel' => true))); ?></small>
                    </label>
                    <label class="mc-field"><span><?php esc_html_e('Modell', 'madex-chatbot'); ?></span>
                        <select name="settings[model]">
                            <?php foreach ($models as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($model, $value); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small><?php esc_html_e('Für Kundenberatung reicht GPT-4o mini in den meisten Fällen.', 'madex-chatbot'); ?></small>
                    </label>
                </div>
                <div class="mc-inline">
                    <button type="button" class="button" id="madex-test-connection" <?php disabled(!$key['valid']); ?>><?php esc_html_e('Verbindung testen', 'madex-chatbot'); ?></button>
                    <span id="madex-test-result" class="mc-test-result" role="status" aria-live="polite"></span>
                    <?php if ($key['stored']) : ?>
                        <label class="mc-check-inline"><input type="checkbox" name="remove_api_key" value="1"> <?php esc_html_e('Gespeicherten Schlüssel entfernen', 'madex-chatbot'); ?></label>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <section class="mc-card">
            <div class="mc-card__head">
                <div><h2><?php esc_html_e('Unternehmenswissen', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Was der Assistent über Madex weiss: Leistungen, Pakete, Konditionen, Team und Kontakt. Vorausgefüllt mit den Angaben von madex-it.ch.', 'madex-chatbot'); ?></p></div>
                <span class="mc-badge <?php echo Madex_Company_Knowledge::is_customised() ? 'mc-badge--new' : 'mc-badge--muted'; ?>"><?php echo Madex_Company_Knowledge::is_customised() ? esc_html__('Eigene Fassung', 'madex-chatbot') : esc_html__('Standard', 'madex-chatbot'); ?></span>
            </div>
            <div class="mc-stack">
                <label class="mc-field"><span class="screen-reader-text"><?php esc_html_e('Unternehmenswissen', 'madex-chatbot'); ?></span>
                    <textarea name="company_knowledge" rows="20" class="mc-code"><?php echo esc_textarea(Madex_Company_Knowledge::get()); ?></textarea>
                    <small><?php esc_html_e('Schreiben Sie in kurzen, sachlichen Sätzen. Nur was hier, in der Wissensdatenbank oder in den Paketen steht, gibt der Assistent als Fakt weiter. Preise nennt er nur, wenn sie hier stehen.', 'madex-chatbot'); ?></small>
                </label>
                <?php if (Madex_Company_Knowledge::is_customised()) : ?>
                    <label class="mc-check-inline"><input type="checkbox" name="reset_knowledge" value="1"> <?php esc_html_e('Beim Speichern auf das Standardprofil von madex-it.ch zurücksetzen', 'madex-chatbot'); ?></label>
                <?php endif; ?>
            </div>
        </section>

        <section class="mc-card">
            <div class="mc-card__head"><div><h2><?php esc_html_e('Zusätzliche Anweisungen', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Optional. Ton, Aktionen oder Regeln, die zusätzlich gelten sollen. Grundverhalten, Sprache und Sicherheitsregeln sind bereits eingebaut.', 'madex-chatbot'); ?></p></div></div>
            <label class="mc-field"><span class="screen-reader-text"><?php esc_html_e('Zusätzliche Anweisungen', 'madex-chatbot'); ?></span>
                <textarea name="directive[system_prompt]" rows="5" placeholder="<?php esc_attr_e('z. B. «Weise im Oktober auf unsere Herbstaktion hin: 10 % auf das Basic-Paket bei Abschluss bis 31.10.»', 'madex-chatbot'); ?>"><?php echo esc_textarea($directive['system_prompt'] ?? ''); ?></textarea>
            </label>
        </section>
        <?php
    }

    private function render_greeting_tab() {
        $branding = wp_parse_args(get_option('madex_chatbot_branding', array()), self::branding_defaults());
        ?>
        <div class="mc-grid mc-grid--two">
            <section class="mc-card">
                <div class="mc-card__head"><div><h2><?php esc_html_e('Proaktive Begrüssung', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Eine kurze Nachricht erscheint neben dem Chat-Symbol, damit Besucher wissen, dass sie fragen können. Einmal pro Besuch; nach dem Schliessen nicht erneut.', 'madex-chatbot'); ?></p></div></div>
                <div class="mc-stack">
                    <input type="hidden" name="branding[teaser_enabled]" value="0">
                    <label class="mc-switch"><input type="checkbox" name="branding[teaser_enabled]" value="1" <?php checked(!empty($branding['teaser_enabled'])); ?>><span class="mc-switch__track" aria-hidden="true"></span><span><?php esc_html_e('Begrüssung automatisch anzeigen', 'madex-chatbot'); ?></span></label>
                    <label class="mc-field"><span><?php esc_html_e('Nachricht', 'madex-chatbot'); ?></span>
                        <textarea name="branding[teaser_message]" rows="3" maxlength="180" data-mc-teaser-input><?php echo esc_textarea($branding['teaser_message']); ?></textarea>
                        <small><?php esc_html_e('Höchstens 180 Zeichen. Eine Frage lädt am stärksten zum Antworten ein.', 'madex-chatbot'); ?></small>
                    </label>
                    <div class="mc-fields">
                        <label class="mc-field"><span><?php esc_html_e('Erscheint nach', 'madex-chatbot'); ?></span>
                            <span class="mc-suffix"><input type="number" name="branding[teaser_delay]" min="0" max="120" value="<?php echo esc_attr((int) $branding['teaser_delay']); ?>"><span><?php esc_html_e('Sekunden', 'madex-chatbot'); ?></span></span>
                        </label>
                        <div class="mc-field"><span><?php esc_html_e('Auf dem Handy', 'madex-chatbot'); ?></span>
                            <input type="hidden" name="branding[teaser_mobile]" value="0">
                            <label class="mc-switch"><input type="checkbox" name="branding[teaser_mobile]" value="1" <?php checked(!empty($branding['teaser_mobile'])); ?>><span class="mc-switch__track" aria-hidden="true"></span><span><?php esc_html_e('Auch auf kleinen Bildschirmen', 'madex-chatbot'); ?></span></label>
                        </div>
                    </div>
                </div>
            </section>

            <section class="mc-card mc-teaser-preview" aria-label="<?php esc_attr_e('Vorschau', 'madex-chatbot'); ?>">
                <div class="mc-card__head"><h2><?php esc_html_e('Vorschau', 'madex-chatbot'); ?></h2></div>
                <div class="mc-teaser-stage">
                    <div class="mc-teaser-bubble">
                        <span class="mc-teaser-name"><span class="mc-teaser-mark"><?php echo Madex_Chat_Widget::sparkle_svg(14, 'mc-sparkle'); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><?php echo esc_html($branding['chat_title']); ?></span>
                        <p data-mc-teaser-preview><?php echo esc_html($branding['teaser_message']); ?></p>
                    </div>
                    <span class="mc-teaser-launcher" aria-hidden="true"><?php echo Madex_Chat_Widget::chat_icon_svg(28, 'mc-launcher-icon'); // phpcs:ignore WordPress.Security.EscapeOutput ?><span>1</span></span>
                </div>
            </section>
        </div>

        <section class="mc-card">
            <div class="mc-card__head"><h2><?php esc_html_e('Chatfenster', 'madex-chatbot'); ?></h2></div>
            <div class="mc-fields">
                <label class="mc-field"><span><?php esc_html_e('Name des Assistenten', 'madex-chatbot'); ?></span>
                    <input type="text" name="branding[chat_title]" maxlength="60" value="<?php echo esc_attr($branding['chat_title']); ?>">
                    <small><?php esc_html_e('Steht oben im Chatfenster.', 'madex-chatbot'); ?></small>
                </label>
                <label class="mc-field"><span><?php esc_html_e('Erste Nachricht im Gespräch', 'madex-chatbot'); ?></span>
                    <input type="text" name="branding[welcome_message]" maxlength="300" value="<?php echo esc_attr($branding['welcome_message']); ?>">
                    <small><?php esc_html_e('Erscheint, wenn ein Besucher ein Gespräch beginnt.', 'madex-chatbot'); ?></small>
                </label>
            </div>
        </section>
        <?php
    }

    private function data_source_options() {
        $sources = array(
            'pages' => array(__('Seiten', 'madex-chatbot'), __('Titel und Inhalte veröffentlichter Seiten.', 'madex-chatbot'), false),
            'posts' => array(__('Blogbeiträge', 'madex-chatbot'), __('Titel und Inhalte veröffentlichter Beiträge.', 'madex-chatbot'), false),
            'faqs' => array(__('FAQ-Beiträge', 'madex-chatbot'), __('Falls ein FAQ-Beitragstyp vorhanden ist.', 'madex-chatbot'), false),
            'menus' => array(__('Navigationsmenüs', 'madex-chatbot'), __('Menüstruktur und Links, damit der Assistent auf Seiten verweisen kann.', 'madex-chatbot'), false),
            'site_info' => array(__('Website-Informationen', 'madex-chatbot'), __('Name, Untertitel und Adresse der Website.', 'madex-chatbot'), false),
            'woo_products' => array(__('WooCommerce-Produkte', 'madex-chatbot'), __('Namen, Beschreibungen, Preise.', 'madex-chatbot'), true),
            'woo_categories' => array(__('Produktkategorien', 'madex-chatbot'), __('Kategoriestruktur des Shops.', 'madex-chatbot'), true),
            'woo_shipping' => array(__('Versandarten', 'madex-chatbot'), __('Versandzonen und -methoden.', 'madex-chatbot'), true),
            'woo_coupons' => array(__('Gutscheine', 'madex-chatbot'), __('Aktive Gutscheincodes und Bedingungen.', 'madex-chatbot'), true),
            'woo_orders' => array(__('Bestellstatistik', 'madex-chatbot'), __('Nur anonyme Zahlen pro Status.', 'madex-chatbot'), true),
            'users_customers' => array(__('Kundenstatistik', 'madex-chatbot'), __('Nur die anonyme Anzahl.', 'madex-chatbot'), false),
        );
        return $sources;
    }

    private function render_datasources_tab() {
        $enabled = (array) get_option('madex_chatbot_data_sources', array());
        $has_woo = class_exists('WooCommerce');
        ?>
        <section class="mc-card">
            <div class="mc-card__head"><div><h2><?php esc_html_e('Inhalte der Website', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Zusätzlich zum Unternehmenswissen darf der Assistent diese WordPress-Inhalte lesen. Persönliche Daten von Kunden werden nie weitergegeben.', 'madex-chatbot'); ?></p></div></div>
            <input type="hidden" name="data_sources_present" value="1">
            <div class="mc-optionlist">
                <?php foreach ($this->data_source_options() as $key => $source) :
                    if ($source[2] && !$has_woo) {
                        if (in_array($key, $enabled, true)) {
                            echo '<input type="hidden" name="data_sources[]" value="' . esc_attr($key) . '">';
                        }
                        continue;
                    }
                    ?>
                    <label class="mc-option">
                        <input type="checkbox" name="data_sources[]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key, $enabled, true)); ?>>
                        <span><b><?php echo esc_html($source[0]); ?></b><small><?php echo esc_html($source[1]); ?></small></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <?php if (!$has_woo) : ?><p class="mc-help"><?php esc_html_e('Shop-Daten erscheinen hier, sobald WooCommerce aktiv ist.', 'madex-chatbot'); ?></p><?php endif; ?>
        </section>
        <?php
    }

    private function render_security_tab() {
        $security = wp_parse_args(get_option('madex_chatbot_security', array()), self::security_defaults());
        $blocked_ips = (array) get_option('madex_chatbot_blocked_ips', array());
        $stats = Madex_Security_Service::get_security_stats();
        $number = function ($name, $label, $min, $max, $suffix, $help) use ($security) {
            ?>
            <label class="mc-field"><span><?php echo esc_html($label); ?></span>
                <span class="mc-suffix"><input type="number" name="security[<?php echo esc_attr($name); ?>]" min="<?php echo esc_attr($min); ?>" max="<?php echo esc_attr($max); ?>" value="<?php echo esc_attr((int) $security[$name]); ?>"><span><?php echo esc_html($suffix); ?></span></span>
                <small><?php echo esc_html($help); ?></small>
            </label>
            <?php
        };
        ?>
        <div class="mc-kpis mc-kpis--three">
            <article class="mc-kpi"><span class="mc-kpi__label"><?php esc_html_e('Blockiert heute', 'madex-chatbot'); ?></span><strong class="mc-kpi__value"><?php echo esc_html(number_format_i18n((int) $stats['blocked_today'])); ?></strong><span class="mc-kpi__hint"><?php esc_html_e('Abgewiesene Anfragen', 'madex-chatbot'); ?></span></article>
            <article class="mc-kpi"><span class="mc-kpi__label"><?php esc_html_e('Gebremst heute', 'madex-chatbot'); ?></span><strong class="mc-kpi__value"><?php echo esc_html(number_format_i18n((int) $stats['rate_limited_today'])); ?></strong><span class="mc-kpi__hint"><?php esc_html_e('Zu viele Nachrichten', 'madex-chatbot'); ?></span></article>
            <article class="mc-kpi"><span class="mc-kpi__label"><?php esc_html_e('Gesperrte IPs', 'madex-chatbot'); ?></span><strong class="mc-kpi__value"><?php echo esc_html(number_format_i18n((int) $stats['total_blocked_ips'])); ?></strong><span class="mc-kpi__hint"><?php esc_html_e('Manuell gesperrt', 'madex-chatbot'); ?></span></article>
        </div>

        <section class="mc-card">
            <div class="mc-card__head"><div><h2><?php esc_html_e('Missbrauchsschutz', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Schützt vor Spam und unnötigen KI-Kosten. Gilt pro Besucher bzw. IP-Adresse.', 'madex-chatbot'); ?></p></div></div>
            <div class="mc-fields">
                <?php
                $number('rate_limit_per_minute', __('Nachrichten pro Minute', 'madex-chatbot'), 1, 60, __('max.', 'madex-chatbot'), __('Höchstzahl pro Minute.', 'madex-chatbot'));
                $number('guest_messages_per_day', __('Nachrichten pro Tag (Gäste)', 'madex-chatbot'), 0, 1000, __('max.', 'madex-chatbot'), __('0 = unbegrenzt. Angemeldete Benutzer sind nicht begrenzt.', 'madex-chatbot'));
                $number('message_cooldown', __('Pause zwischen Nachrichten', 'madex-chatbot'), 0, 30, __('Sek.', 'madex-chatbot'), __('0 = keine Pause.', 'madex-chatbot'));
                $number('max_message_length', __('Maximale Nachrichtenlänge', 'madex-chatbot'), 100, 5000, __('Zeichen', 'madex-chatbot'), __('Längere Nachrichten werden abgewiesen.', 'madex-chatbot'));
                ?>
                <input type="hidden" name="security[min_message_length]" value="<?php echo esc_attr((int) $security['min_message_length']); ?>">
                <div class="mc-field mc-field--wide">
                    <input type="hidden" name="security[block_spam]" value="0">
                    <label class="mc-switch"><input type="checkbox" name="security[block_spam]" value="1" <?php checked(!empty($security['block_spam'])); ?>><span class="mc-switch__track" aria-hidden="true"></span><span><?php esc_html_e('Spam-Nachrichten automatisch erkennen und blockieren', 'madex-chatbot'); ?></span></label>
                </div>
            </div>
        </section>

        <section class="mc-card">
            <div class="mc-card__head"><div><h2><?php esc_html_e('Gesperrte IP-Adressen', 'madex-chatbot'); ?></h2><p class="mc-help"><?php esc_html_e('Eine Adresse pro Zeile. Bereiche in CIDR-Schreibweise sind möglich, z. B. 192.168.1.0/24.', 'madex-chatbot'); ?></p></div></div>
            <label class="mc-field"><span class="screen-reader-text"><?php esc_html_e('Gesperrte IP-Adressen', 'madex-chatbot'); ?></span>
                <textarea name="blocked_ips" rows="5" class="mc-code" placeholder="192.168.1.100&#10;10.0.0.0/8"><?php echo esc_textarea(implode("\n", $blocked_ips)); ?></textarea>
            </label>
        </section>
        <?php
    }

    /**
     * Save one settings tab.
     */
    public function handle_save() {
        $this->require_admin();
        check_admin_referer('madex_save_settings');

        $tab = isset($_POST['tab']) ? sanitize_key(wp_unslash($_POST['tab'])) : 'general';
        if (!isset($this->tabs()[$tab])) {
            $tab = 'general';
        }
        $notice = 'saved';

        if (isset($_POST['branding']) && is_array($_POST['branding'])) {
            $this->save_branding(wp_unslash($_POST['branding']));
        }

        if ($tab === 'general' || $tab === 'ai') {
            $notice = $this->save_ai_settings($tab);
        }

        if ($tab === 'ai') {
            if (!empty($_POST['reset_knowledge'])) {
                Madex_Company_Knowledge::save('');
            } elseif (isset($_POST['company_knowledge'])) {
                Madex_Company_Knowledge::save(wp_unslash($_POST['company_knowledge']));
            }
            if (isset($_POST['directive']['system_prompt'])) {
                update_option('madex_chatbot_directive', array(
                    'system_prompt' => mb_substr(sanitize_textarea_field(wp_unslash($_POST['directive']['system_prompt'])), 0, 4000),
                ), false);
            }
        }

        if ($tab === 'datasources' && isset($_POST['data_sources_present'])) {
            $allowed = array_keys($this->data_source_options());
            $sources = isset($_POST['data_sources']) ? array_map('sanitize_key', (array) wp_unslash($_POST['data_sources'])) : array();
            update_option('madex_chatbot_data_sources', array_values(array_intersect($allowed, $sources)), false);
        }

        if ($tab === 'security' && isset($_POST['security']) && is_array($_POST['security'])) {
            update_option('madex_chatbot_security', $this->sanitize_security(wp_unslash($_POST['security'])), false);
            $ips = preg_split('/[\r\n]+/', (string) wp_unslash($_POST['blocked_ips'] ?? ''));
            $ips = array_values(array_unique(array_filter(array_map(function ($ip) {
                $ip = trim(sanitize_text_field($ip));
                return preg_match('#^[0-9a-fA-F:.]+(/\d{1,3})?$#', $ip) ? $ip : '';
            }, $ips))));
            update_option('madex_chatbot_blocked_ips', $ips, false);
        }

        $this->redirect(self::PAGE, array('tab' => $tab, 'madex_notice' => $notice));
    }

    /**
     * Enabled flag, API key and model.
     *
     * @param string $tab Tab being saved.
     * @return string Notice key.
     */
    private function save_ai_settings($tab) {
        $settings = get_option('madex_chatbot_settings', array());
        $notice = 'saved';
        $input = isset($_POST['settings']) && is_array($_POST['settings']) ? wp_unslash($_POST['settings']) : array();

        if ($tab === 'general') {
            $settings['enabled'] = !empty($input['enabled']);
        }

        if ($tab === 'ai') {
            // Pasted keys often carry spaces, line breaks or quotes.
            $new_key = isset($input['api_key']) ? preg_replace('/[\s"\'<>]+/', '', (string) $input['api_key']) : '';

            if (!empty($_POST['remove_api_key']) && $new_key === '') {
                $settings['api_key'] = '';
                $notice = 'key_removed';
            } elseif ($new_key !== '' && strpos($new_key, '*') === false) {
                if (strpos($new_key, 'sk-') !== 0 || strlen($new_key) < 20) {
                    $notice = 'key_format';
                } else {
                    $encrypted = Madex_Encryption::encrypt($new_key);
                    if ($encrypted === false || $encrypted === '') {
                        $notice = 'key_encrypt';
                    } else {
                        $settings['api_key'] = $encrypted;
                        $notice = 'key_saved';
                    }
                }
            }

            $model = isset($input['model']) ? sanitize_text_field($input['model']) : '';
            if ($model !== '' && preg_match('/^[a-z0-9.\-]+$/i', $model)) {
                $settings['model'] = $model;
            }
        }

        $settings += array('enabled' => false, 'api_key' => '', 'model' => 'gpt-4o-mini');
        update_option('madex_chatbot_settings', $settings, false);

        return $notice;
    }

    /**
     * Merge submitted greeting/contact fields into the stored branding.
     *
     * @param array $input Submitted values.
     */
    private function save_branding($input) {
        $branding = wp_parse_args(get_option('madex_chatbot_branding', array()), self::branding_defaults());

        foreach (array('chat_title' => 60, 'welcome_message' => 300, 'teaser_message' => 180) as $field => $max) {
            if (isset($input[$field])) {
                $value = trim(sanitize_text_field($input[$field]));
                $branding[$field] = $value === '' ? self::branding_defaults()[$field] : mb_substr($value, 0, $max);
            }
        }
        if (isset($input['contact_phone'])) {
            $phones = array_filter(array_map(function ($phone) {
                return trim(preg_replace('/[^0-9+()\s\/.-]/', '', $phone));
            }, preg_split('/[\r\n,;]+/', (string) $input['contact_phone'])));
            $branding['contact_phone'] = implode("\n", array_slice($phones, 0, 4));
        }
        if (isset($input['contact_email'])) {
            $email = sanitize_email($input['contact_email']);
            $branding['contact_email'] = is_email($email) ? $email : '';
        }
        if (isset($input['mail_from_name'])) {
            $name = trim(preg_replace('/[\r\n<>"]+/', '', sanitize_text_field($input['mail_from_name'])));
            $branding['mail_from_name'] = $name === '' ? self::branding_defaults()['mail_from_name'] : mb_substr($name, 0, 80);
        }
        if (isset($input['mail_from_email'])) {
            $email = sanitize_email($input['mail_from_email']);
            $branding['mail_from_email'] = is_email($email) ? $email : self::branding_defaults()['mail_from_email'];
        }
        foreach (array('teaser_enabled', 'teaser_mobile') as $field) {
            if (isset($input[$field])) {
                $branding[$field] = !empty($input[$field]);
            }
        }
        if (isset($input['teaser_delay'])) {
            $branding['teaser_delay'] = max(0, min(120, (int) $input['teaser_delay']));
        }

        update_option('madex_chatbot_branding', $branding);
    }

    /**
     * @param array $input Submitted values.
     * @return array
     */
    public function sanitize_security($input) {
        $current = wp_parse_args(get_option('madex_chatbot_security', array()), self::security_defaults());
        $limits = array(
            'rate_limit_per_minute' => array(1, 60),
            'guest_messages_per_day' => array(0, 1000),
            'message_cooldown' => array(0, 30),
            'min_message_length' => array(1, 50),
            'max_message_length' => array(100, 5000),
        );
        foreach ($limits as $field => $range) {
            if (isset($input[$field])) {
                $current[$field] = max($range[0], min($range[1], (int) $input[$field]));
            }
        }
        if (isset($input['block_spam'])) {
            $current['block_spam'] = !empty($input['block_spam']);
        }
        return $current;
    }

    /* ==================================================================
     * Knowledge base
     * ================================================================== */

    private function knowledge_types() {
        return array(
            'faq' => __('FAQ', 'madex-chatbot'),
            'product' => __('Leistung / Angebot', 'madex-chatbot'),
            'policy' => __('Konditionen / AGB', 'madex-chatbot'),
            'tutorial' => __('Anleitung', 'madex-chatbot'),
            'brochure' => __('Referenz / Projekt', 'madex-chatbot'),
            'other' => __('Sonstiges', 'madex-chatbot'),
        );
    }

    public function render_knowledge_page() {
        $this->require_admin();
        global $wpdb;
        $table = $wpdb->prefix . 'madex_knowledge_base';
        $items = (array) $wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC");
        $types = $this->knowledge_types();
        $edit_id = isset($_GET['edit']) ? absint($_GET['edit']) : 0;
        $editing = null;
        foreach ($items as $item) {
            if ((int) $item->id === $edit_id) {
                $editing = $item;
            }
        }

        $this->header(__('Wissensdatenbank', 'madex-chatbot'), __('Zusätzliches Wissen für den Assistenten: häufige Fragen, Aktionen, Referenzen oder Abläufe. Das Unternehmensprofil pflegen Sie unter Einstellungen → KI & Wissen.', 'madex-chatbot'));
        ?>
        <div class="mc-split">
            <section class="mc-card">
                <div class="mc-card__head"><h2><?php echo $editing ? esc_html__('Eintrag bearbeiten', 'madex-chatbot') : esc_html__('Neuer Eintrag', 'madex-chatbot'); ?></h2></div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mc-stack" data-mc-dirty>
                    <input type="hidden" name="action" value="madex_knowledge">
                    <input type="hidden" name="kb_action" value="<?php echo $editing ? 'update' : 'add'; ?>">
                    <?php if ($editing) : ?><input type="hidden" name="item_id" value="<?php echo esc_attr($editing->id); ?>"><?php endif; ?>
                    <?php wp_nonce_field('madex_knowledge'); ?>
                    <div class="mc-fields">
                        <label class="mc-field"><span><?php esc_html_e('Titel', 'madex-chatbot'); ?></span>
                            <input type="text" name="kb_name" required maxlength="191" value="<?php echo esc_attr($editing ? $editing->name : ''); ?>" placeholder="<?php esc_attr_e('z. B. Wie lange dauert eine neue Website?', 'madex-chatbot'); ?>">
                        </label>
                        <label class="mc-field"><span><?php esc_html_e('Art', 'madex-chatbot'); ?></span>
                            <select name="kb_type">
                                <?php foreach ($types as $value => $label) : ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected($editing ? $editing->type : 'faq', $value); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    </div>
                    <label class="mc-field"><span><?php esc_html_e('Inhalt', 'madex-chatbot'); ?></span>
                        <textarea name="kb_content" rows="10" required maxlength="50000"><?php echo esc_textarea($editing ? $editing->content : ''); ?></textarea>
                        <small><?php esc_html_e('Kurze, klare Sätze funktionieren am besten. Bis 50 000 Zeichen; pro Eintrag nutzt der Assistent die ersten 3 000.', 'madex-chatbot'); ?></small>
                    </label>
                    <div class="mc-inline">
                        <button type="submit" class="button button-primary"><?php echo $editing ? esc_html__('Änderungen speichern', 'madex-chatbot') : esc_html__('Eintrag hinzufügen', 'madex-chatbot'); ?></button>
                        <?php if ($editing) : ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=madex-chatbot-knowledge')); ?>"><?php esc_html_e('Abbrechen', 'madex-chatbot'); ?></a><?php endif; ?>
                    </div>
                </form>
            </section>

            <section class="mc-card mc-card--flush">
                <div class="mc-card__head mc-card__head--pad"><h2><?php esc_html_e('Einträge', 'madex-chatbot'); ?></h2><span class="mc-muted"><?php echo esc_html(number_format_i18n(count($items))); ?></span></div>
                <?php if (empty($items)) : ?>
                    <div class="mc-empty"><p><?php esc_html_e('Noch keine zusätzlichen Einträge. Das Unternehmensprofil von madex-it.ch ist bereits aktiv.', 'madex-chatbot'); ?></p></div>
                <?php else : ?>
                    <table class="mc-table">
                        <thead><tr><th scope="col"><?php esc_html_e('Titel', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Art', 'madex-chatbot'); ?></th><th scope="col"><?php esc_html_e('Hinzugefügt', 'madex-chatbot'); ?></th><th scope="col"><span class="screen-reader-text"><?php esc_html_e('Aktionen', 'madex-chatbot'); ?></span></th></tr></thead>
                        <tbody>
                            <?php foreach ($items as $item) : ?>
                                <tr>
                                    <td><b><?php echo esc_html($item->name); ?></b><small class="mc-muted mc-block"><?php echo esc_html(wp_trim_words(wp_strip_all_tags($item->content), 16)); ?></small></td>
                                    <td><span class="mc-chip"><?php echo esc_html($types[$item->type] ?? $item->type); ?></span></td>
                                    <td class="mc-num"><?php echo esc_html(mysql2date('d.m.Y', $item->created_at)); ?></td>
                                    <td class="mc-actions"><div class="mc-actions__inner">
                                        <a href="<?php echo esc_url(add_query_arg(array('page' => 'madex-chatbot-knowledge', 'edit' => $item->id), admin_url('admin.php'))); ?>"><?php esc_html_e('Bearbeiten', 'madex-chatbot'); ?></a>
                                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-mc-confirm="<?php esc_attr_e('Diesen Eintrag löschen?', 'madex-chatbot'); ?>">
                                            <input type="hidden" name="action" value="madex_knowledge"><input type="hidden" name="kb_action" value="delete"><input type="hidden" name="item_id" value="<?php echo esc_attr($item->id); ?>"><?php wp_nonce_field('madex_knowledge'); ?>
                                            <button class="button-link button-link-delete"><?php esc_html_e('Löschen', 'madex-chatbot'); ?></button>
                                        </form>
                                    </div></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>
        </div>
        </div>
        <?php
    }

    public function handle_knowledge() {
        $this->require_admin();
        check_admin_referer('madex_knowledge');
        global $wpdb;
        $table = $wpdb->prefix . 'madex_knowledge_base';
        $action = isset($_POST['kb_action']) ? sanitize_key(wp_unslash($_POST['kb_action'])) : '';
        $id = isset($_POST['item_id']) ? absint($_POST['item_id']) : 0;

        if ($action === 'delete' && $id) {
            $wpdb->delete($table, array('id' => $id), array('%d'));
            $this->redirect('madex-chatbot-knowledge', array('madex_notice' => 'kb_deleted'));
        }

        $name = mb_substr(sanitize_text_field(wp_unslash($_POST['kb_name'] ?? '')), 0, 191);
        $type = sanitize_key(wp_unslash($_POST['kb_type'] ?? 'other'));
        $content = mb_substr(sanitize_textarea_field(wp_unslash($_POST['kb_content'] ?? '')), 0, 50000);
        if ($name === '' || $content === '') {
            $this->redirect('madex-chatbot-knowledge', array('madex_notice' => 'error'));
        }
        if (!isset($this->knowledge_types()[$type])) {
            $type = 'other';
        }

        if ($action === 'update' && $id) {
            $wpdb->update($table, array('name' => $name, 'type' => $type, 'content' => $content), array('id' => $id), array('%s', '%s', '%s'), array('%d'));
            $this->redirect('madex-chatbot-knowledge', array('madex_notice' => 'kb_updated'));
        }

        $wpdb->insert($table, array('name' => $name, 'type' => $type, 'content' => $content), array('%s', '%s', '%s'));
        $this->redirect('madex-chatbot-knowledge', array('madex_notice' => 'kb_added'));
    }

    /* ==================================================================
     * Chat history
     * ================================================================== */

    public function render_sessions_page() {
        $this->require_admin();
        global $wpdb;
        $sessions_table = $wpdb->prefix . 'madex_chat_sessions';
        $messages_table = $wpdb->prefix . 'madex_chat_messages';

        $total_sessions = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$sessions_table}");
        $total_messages = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$messages_table}");
        $active_sessions = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$sessions_table} WHERE status = 'active'");
        $sessions = (array) $wpdb->get_results("
            SELECT s.*,
                   (SELECT COUNT(*) FROM {$messages_table} WHERE session_id = s.id) AS message_count,
                   (SELECT content FROM {$messages_table} WHERE session_id = s.id AND sender_type = 'user' ORDER BY id DESC LIMIT 1) AS last_user_message
            FROM {$sessions_table} s
            ORDER BY s.updated_at DESC
            LIMIT 100
        ");

        $selected_id = isset($_GET['session']) ? absint($_GET['session']) : 0;
        $selected = null;
        $messages = array();
        if ($selected_id) {
            $selected = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$sessions_table} WHERE id = %d", $selected_id));
            $messages = (array) $wpdb->get_results($wpdb->prepare("SELECT * FROM {$messages_table} WHERE session_id = %d ORDER BY id ASC", $selected_id));
        }
        $name = function ($session) {
            return ($session->user_name && $session->user_name !== 'Guest') ? $session->user_name : Madex_Business_Service::visitor_label((string) $session->public_id);
        };

        $this->header(__('Chatverläufe', 'madex-chatbot'), __('Alle Gespräche mit dem Assistenten, neueste zuerst.', 'madex-chatbot'));
        ?>
        <div class="mc-kpis mc-kpis--three">
            <article class="mc-kpi"><span class="mc-kpi__label"><?php esc_html_e('Gespräche', 'madex-chatbot'); ?></span><strong class="mc-kpi__value"><?php echo esc_html(number_format_i18n($total_sessions)); ?></strong><span class="mc-kpi__hint"><?php esc_html_e('Gesamt', 'madex-chatbot'); ?></span></article>
            <article class="mc-kpi"><span class="mc-kpi__label"><?php esc_html_e('Nachrichten', 'madex-chatbot'); ?></span><strong class="mc-kpi__value"><?php echo esc_html(number_format_i18n($total_messages)); ?></strong><span class="mc-kpi__hint"><?php esc_html_e('Gesamt', 'madex-chatbot'); ?></span></article>
            <article class="mc-kpi"><span class="mc-kpi__label"><?php esc_html_e('Offen', 'madex-chatbot'); ?></span><strong class="mc-kpi__value"><?php echo esc_html(number_format_i18n($active_sessions)); ?></strong><span class="mc-kpi__hint"><?php esc_html_e('Nicht beendet', 'madex-chatbot'); ?></span></article>
        </div>

        <div class="mc-split mc-split--chat">
            <section class="mc-card mc-card--flush">
                <div class="mc-card__head mc-card__head--pad">
                    <h2><?php esc_html_e('Gespräche', 'madex-chatbot'); ?></h2>
                    <?php if ($total_sessions > 0) : ?><button type="button" class="button-link button-link-delete" data-madex-delete-all><?php esc_html_e('Alle löschen', 'madex-chatbot'); ?></button><?php endif; ?>
                </div>
                <?php if (empty($sessions)) : ?>
                    <div class="mc-empty"><p><?php esc_html_e('Noch keine Gespräche. Sie erscheinen hier, sobald Besucher den Chat nutzen.', 'madex-chatbot'); ?></p></div>
                <?php else : ?>
                    <ul class="mc-convlist">
                        <?php foreach ($sessions as $session) : ?>
                            <li class="<?php echo (int) $session->id === $selected_id ? 'is-active' : ''; ?>">
                                <a href="<?php echo esc_url(add_query_arg(array('page' => 'madex-chatbot-sessions', 'session' => $session->id), admin_url('admin.php'))); ?>">
                                    <span class="mc-convlist__top"><b><?php echo esc_html($name($session)); ?></b><time><?php echo esc_html(sprintf(__('vor %s', 'madex-chatbot'), human_time_diff(strtotime($session->updated_at), current_time('timestamp')))); ?></time></span>
                                    <span class="mc-convlist__preview"><?php echo esc_html($session->last_user_message ? wp_trim_words($session->last_user_message, 12) : __('Keine Besucher-Nachricht', 'madex-chatbot')); ?></span>
                                    <span class="mc-convlist__meta"><?php echo esc_html(sprintf(_n('%d Nachricht', '%d Nachrichten', (int) $session->message_count, 'madex-chatbot'), (int) $session->message_count)); ?><?php echo $session->topic ? ' · ' . esc_html(Madex_Business_Service::service_label($session->topic)) : ''; ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>

            <section class="mc-card mc-card--flush mc-transcript">
                <?php if ($selected) : ?>
                    <div class="mc-card__head mc-card__head--pad">
                        <div><h2><?php echo esc_html($name($selected)); ?></h2><p class="mc-help"><?php echo esc_html(trim(($selected->user_email ? $selected->user_email . ' · ' : '') . mysql2date('d.m.Y, H:i', $selected->created_at))); ?></p></div>
                        <button type="button" class="button-link button-link-delete" data-madex-delete-session="<?php echo esc_attr($selected->id); ?>"><?php esc_html_e('Gespräch löschen', 'madex-chatbot'); ?></button>
                    </div>
                    <div class="mc-transcript__body">
                        <?php foreach ($messages as $message) : ?>
                            <div class="mc-bubble mc-bubble--<?php echo $message->sender_type === 'user' ? 'user' : 'ai'; ?>">
                                <p><?php echo nl2br(esc_html($message->content)); ?></p>
                                <time><?php echo esc_html(mysql2date('H:i', $message->created_at)); ?></time>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($messages)) : ?><div class="mc-empty"><p><?php esc_html_e('Dieses Gespräch enthält keine Nachrichten.', 'madex-chatbot'); ?></p></div><?php endif; ?>
                    </div>
                <?php else : ?>
                    <div class="mc-empty"><p><?php esc_html_e('Wählen Sie links ein Gespräch aus.', 'madex-chatbot'); ?></p></div>
                <?php endif; ?>
            </section>
        </div>
        </div>
        <script>
        jQuery(function ($) {
            var nonce = <?php echo wp_json_encode(wp_create_nonce('madex_admin_nonce')); ?>;
            var listUrl = <?php echo wp_json_encode(admin_url('admin.php?page=madex-chatbot-sessions')); ?>;
            function post(data, message) {
                if (!window.confirm(message)) { return; }
                data.nonce = nonce;
                $.post(ajaxurl, data).done(function (response) {
                    if (response && response.success) { window.location.href = listUrl; }
                    else { window.alert((response && response.data && response.data.message) || <?php echo wp_json_encode(__('Löschen fehlgeschlagen.', 'madex-chatbot')); ?>); }
                });
            }
            $('[data-madex-delete-session]').on('click', function () {
                post({ action: 'madex_delete_session', session_id: $(this).data('madex-delete-session') }, <?php echo wp_json_encode(__('Dieses Gespräch und alle Nachrichten löschen?', 'madex-chatbot')); ?>);
            });
            $('[data-madex-delete-all]').on('click', function () {
                post({ action: 'madex_delete_all_sessions' }, <?php echo wp_json_encode(__('Wirklich ALLE Gespräche endgültig löschen? Dies kann nicht rückgängig gemacht werden.', 'madex-chatbot')); ?>);
            });
        });
        </script>
        <?php
    }
}
