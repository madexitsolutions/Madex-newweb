<?php
/**
 * AJAX Handler Class
 *
 * Public chat endpoints authenticate every request with an unguessable public
 * session id (UUIDv4) plus a 256-bit bearer token. Only an HMAC of the token
 * is stored, so a database leak cannot be replayed against the widget.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Ajax_Handler {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $public_actions = array(
            'madex_start_session' => 'handle_start_session',
            'madex_get_messages' => 'handle_get_messages',
            'madex_send_message' => 'handle_send_message',
            'madex_close_session' => 'handle_close_session',
            'madex_heartbeat' => 'handle_heartbeat',
            'madex_get_packages' => 'handle_get_packages',
            'madex_submit_appointment' => 'handle_submit_appointment',
        );
        foreach ($public_actions as $action => $method) {
            add_action('wp_ajax_' . $action, array($this, $method));
            add_action('wp_ajax_nopriv_' . $action, array($this, $method));
        }

        // Admin AJAX actions
        add_action('wp_ajax_madex_test_api', array($this, 'handle_test_api'));
        add_action('wp_ajax_madex_delete_session', array($this, 'handle_delete_session'));
        add_action('wp_ajax_madex_delete_all_sessions', array($this, 'handle_delete_all_sessions'));
    }

    /* ------------------------------------------------------------------
     * Session helpers
     * ------------------------------------------------------------------ */

    private function sessions_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_chat_sessions';
    }

    private function messages_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_chat_messages';
    }

    private function verify_nonce() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'madex_chatbot_nonce')) {
            wp_send_json_error(array(
                'message' => __('Die Sitzung ist abgelaufen. Bitte laden Sie die Seite neu.', 'madex-chatbot'),
                'code' => 'invalid_nonce',
            ), 403);
        }
    }

    private function hash_token($token) {
        return hash_hmac('sha256', (string) $token, wp_salt('auth') . '|madex-chat-session');
    }

    private function new_token() {
        try {
            return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        } catch (Exception $exception) {
            return '';
        }
    }

    /**
     * Resolve and authenticate the session named in the request.
     * Sends a 401 JSON response (and exits) when it is missing or invalid.
     *
     * @return object Session row.
     */
    private function require_session() {
        global $wpdb;

        $public_id = isset($_POST['session_id']) ? strtolower(sanitize_text_field(wp_unslash($_POST['session_id']))) : '';
        $token = isset($_POST['session_token']) ? (string) wp_unslash($_POST['session_token']) : '';

        $valid_format = preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $public_id)
            && preg_match('/^[A-Za-z0-9_-]{43}$/D', $token);

        $session = null;
        if ($valid_format) {
            $session = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$this->sessions_table()} WHERE public_id = %s LIMIT 1",
                $public_id
            ));
        }

        if (!$session || empty($session->visitor_token_hash) || !hash_equals($session->visitor_token_hash, $this->hash_token($token))) {
            wp_send_json_error(array(
                'message' => __('Die Chat-Sitzung ist nicht mehr gültig. Ein neues Gespräch wird gestartet.', 'madex-chatbot'),
                'code' => 'invalid_session',
            ), 401);
        }

        if ($session->status !== 'active') {
            wp_send_json_error(array(
                'message' => __('Dieses Gespräch wurde beendet. Ein neues Gespräch wird gestartet.', 'madex-chatbot'),
                'code' => 'session_expired',
            ), 401);
        }

        return $session;
    }

    private function touch_session($session_id, $extra = array()) {
        global $wpdb;
        $now = current_time('mysql');
        $data = array_merge(array('last_seen' => $now, 'updated_at' => $now), $extra);
        $wpdb->update($this->sessions_table(), $data, array('id' => (int) $session_id));
    }

    private function format_message($row) {
        $sender = in_array($row->sender_type, array('user', 'ai'), true) ? $row->sender_type : 'ai';
        return array(
            'id' => (int) $row->id,
            'content' => (string) $row->content,
            'sender_type' => $sender,
            'fallback' => !empty($row->is_fallback),
            'created_at' => $row->created_at,
        );
    }

    private function insert_message($session_id, $sender_type, $content, $is_fallback = false) {
        global $wpdb;
        $now = current_time('mysql');
        $wpdb->insert(
            $this->messages_table(),
            array(
                'session_id' => (int) $session_id,
                'content' => $content,
                'sender_type' => $sender_type,
                'sender_name' => $sender_type === 'user' ? 'Visitor' : 'Assistant',
                'is_fallback' => $is_fallback ? 1 : 0,
                'created_at' => $now,
            ),
            array('%d', '%s', '%s', '%s', '%d', '%s')
        );

        return (object) array(
            'id' => (int) $wpdb->insert_id,
            'content' => $content,
            'sender_type' => $sender_type,
            'is_fallback' => $is_fallback ? 1 : 0,
            'created_at' => $now,
        );
    }

    private function rate_limited_response($message) {
        wp_send_json_error(array('message' => $message, 'code' => 'rate_limited'), 429);
    }

    /* ------------------------------------------------------------------
     * Public endpoints
     * ------------------------------------------------------------------ */

    public function handle_start_session() {
        $this->verify_nonce();

        if (Madex_Security_Service::is_ip_blocked()) {
            Madex_Security_Service::log_security_event('blocked_attempt', array('action' => 'start_session'));
            wp_send_json_error(array('message' => __('Zugriff verweigert.', 'madex-chatbot'), 'code' => 'blocked'), 403);
        }

        $limit = Madex_Security_Service::check_rate_limit('start_session', 30, HOUR_IN_SECONDS);
        if (!$limit['allowed']) {
            $this->rate_limited_response(__('Zu viele neue Gespräche. Bitte versuchen Sie es später erneut.', 'madex-chatbot'));
        }

        $token = $this->new_token();
        if ($token === '') {
            wp_send_json_error(array('message' => __('Die Chat-Sitzung konnte nicht gestartet werden.', 'madex-chatbot')), 500);
        }

        global $wpdb;
        $user_id = get_current_user_id();
        $user = $user_id ? get_userdata($user_id) : null;
        $now = current_time('mysql');
        $public_id = wp_generate_uuid4();

        $inserted = $wpdb->insert(
            $this->sessions_table(),
            array(
                'user_id' => $user_id,
                'user_name' => $user ? $user->display_name : 'Guest',
                'user_email' => $user ? $user->user_email : '',
                'status' => 'active',
                'mode' => 'ai',
                'public_id' => $public_id,
                'visitor_token_hash' => $this->hash_token($token),
                'customer_type' => 'unknown',
                'created_at' => $now,
                'updated_at' => $now,
                'last_seen' => $now,
                'consent_at' => $now,
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if ($inserted === false) {
            wp_send_json_error(array('message' => __('Die Chat-Sitzung konnte nicht gestartet werden. Bitte laden Sie die Seite neu.', 'madex-chatbot')), 500);
        }

        $session_id = (int) $wpdb->insert_id;
        $openai = new Madex_OpenAI_Service();
        $welcome = $openai->generate_greeting($user ? $user->first_name : '');
        $message = $this->insert_message($session_id, 'ai', $welcome);

        wp_send_json_success(array(
            'session_id' => $public_id,
            'session_token' => $token,
            'messages' => array($this->format_message($message)),
            'is_new' => true,
        ));
    }

    public function handle_get_messages() {
        $this->verify_nonce();
        $session = $this->require_session();

        global $wpdb;
        $after_id = isset($_POST['after_id']) ? absint($_POST['after_id']) : 0;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, content, sender_type, is_fallback, created_at FROM {$this->messages_table()}
             WHERE session_id = %d AND id > %d ORDER BY id ASC LIMIT 200",
            (int) $session->id,
            $after_id
        ));

        $this->touch_session($session->id);
        wp_send_json_success(array('messages' => array_map(array($this, 'format_message'), (array) $rows)));
    }

    public function handle_send_message() {
        $this->verify_nonce();

        $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
        $message = trim($message);

        $security_check = Madex_Security_Service::perform_security_checks($message);
        if (!$security_check['passed']) {
            $status_code = 429;
            if (in_array($security_check['code'], array('blocked', 'ip_blocked'), true)) {
                $status_code = 403;
            } elseif ($security_check['code'] === 'validation_failed') {
                $status_code = 400;
            }
            wp_send_json_error(array('message' => $security_check['error'], 'code' => $security_check['code']), $status_code);
        }

        if ($message === '') {
            wp_send_json_error(array('message' => __('Bitte geben Sie eine Nachricht ein.', 'madex-chatbot'), 'code' => 'empty_message'), 400);
        }

        $session = $this->require_session();

        global $wpdb;
        $history = $wpdb->get_results($wpdb->prepare(
            "SELECT content, sender_type FROM (
                SELECT id, content, sender_type FROM {$this->messages_table()} WHERE session_id = %d ORDER BY id DESC LIMIT 12
             ) recent ORDER BY id ASC",
            (int) $session->id
        ));

        $user_row = $this->insert_message($session->id, 'user', $message);

        $api_messages = array();
        foreach ((array) $history as $item) {
            $api_messages[] = array(
                'role' => $item->sender_type === 'user' ? 'user' : 'assistant',
                'content' => $item->content,
            );
        }
        $api_messages[] = array('role' => 'user', 'content' => $message);

        $openai = new Madex_OpenAI_Service();
        $unavailable = false;
        $reference_reply = $this->reference_status_reply($message);
        if ($reference_reply !== null) {
            // Request references (MDX-…) are answered from the database.
            $reply = $reference_reply;
        } elseif (Madex_OpenAI_Service::identity_reply($message) !== null) {
            $reply = Madex_OpenAI_Service::identity_reply($message);
        } elseif (Madex_OpenAI_Service::is_greeting($message)) {
            // Greetings are answered locally, with or without an AI connection.
            $reply = Madex_OpenAI_Service::greeting_reply($message);
        } elseif (!$openai->is_configured()) {
            $reply = Madex_OpenAI_Service::unconfirmed_text();
            $unavailable = true;
        } else {
            $reply = $openai->generate_response($api_messages);
            if (is_wp_error($reply)) {
                $reply = __('Der Assistent ist gerade nicht erreichbar. Sie können Ihre Anfrage direkt an das Madex-Team senden.', 'madex-chatbot');
                $unavailable = true;
            }
        }

        $parsed = Madex_OpenAI_Service::extract_actions($reply);
        $reply = $parsed['text'] !== '' ? $parsed['text'] : Madex_OpenAI_Service::unconfirmed_text();
        $is_fallback = $unavailable || Madex_OpenAI_Service::is_unconfirmed_response($reply);
        $actions = Madex_OpenAI_Service::next_actions($message, $reply, $parsed['actions']);
        $ai_row = $this->insert_message($session->id, 'ai', $reply, $is_fallback);
        $this->touch_session($session->id);

        wp_send_json_success(array(
            'user_message' => $this->format_message($user_row),
            'ai_message' => $this->format_message($ai_row),
            'actions' => $is_fallback ? array() : array_slice($actions, 0, 3),
            'fallback' => $is_fallback,
            'assistant_unavailable' => $unavailable,
        ));
    }

    /**
     * Status of a request reference the visitor quotes, without personal
     * data: only that it exists, when it arrived and its state.
     *
     * @param string $message Visitor message.
     * @return string|null Reply, or null when the message has no reference.
     */
    private function reference_status_reply($message) {
        if (!preg_match('/\bMDX-?\s?([A-Z0-9]{8,20})\b/i', $message, $match)) {
            return null;
        }
        $reference = 'MDX-' . strtoupper($match[1]);
        $english = Madex_OpenAI_Service::is_english($message);
        $appointment = Madex_Business_Service::get_appointment($reference);

        if (is_wp_error($appointment)) {
            return $english
                ? sprintf("I couldn't find a request with the reference %s. Please check the number, or contact our team directly and we'll look into it.\n[[kontakt]]", $reference)
                : sprintf("Zur Referenz %s finde ich keine Anfrage. Bitte prüfen Sie die Nummer oder kontaktieren Sie unser Team direkt, wir schauen gerne nach.\n[[kontakt]]", $reference);
        }

        $status = isset($appointment['status']) ? (string) $appointment['status'] : 'new';
        $date = !empty($appointment['created_at']) ? mysql2date('d.m.Y', $appointment['created_at']) : '';
        $states = $english
            ? array('new' => 'received and waiting for our team', 'contacted' => 'in progress, our team has been in touch', 'confirmed' => 'confirmed', 'completed' => 'completed', 'cancelled' => 'cancelled')
            : array('new' => 'eingegangen und wartet auf unser Team', 'contacted' => 'in Bearbeitung, unser Team hat sich bereits gemeldet', 'confirmed' => 'bestätigt', 'completed' => 'erledigt', 'cancelled' => 'storniert');
        $state = isset($states[$status]) ? $states[$status] : $states['new'];

        if ($english) {
            $text = sprintf('Your request %s%s is %s.', $reference, $date ? ' from ' . $date : '', $state);
            if ('new' === $status) {
                $text .= " We usually get back to you within 24 hours. If it's urgent, please call or e-mail us directly.";
            }
        } else {
            $text = sprintf('Ihre Anfrage %s%s ist %s.', $reference, $date ? ' vom ' . $date : '', $state);
            if ('new' === $status) {
                $text .= ' Wir melden uns in der Regel innerhalb von 24 Stunden. Wenn es dringend ist, rufen Sie uns gerne direkt an oder schreiben Sie uns.';
            }
        }
        return $text . "\n[[kontakt]]";
    }

    public function handle_heartbeat() {
        $this->verify_nonce();
        $session = $this->require_session();

        // Throttle writes: one update per 30 seconds is enough for "live".
        if (empty($session->last_seen) || strtotime($session->last_seen) < current_time('timestamp') - 30) {
            $this->touch_session($session->id);
        }
        wp_send_json_success(array('ok' => true));
    }

    public function handle_close_session() {
        $this->verify_nonce();
        $session = $this->require_session();

        $now = current_time('mysql');
        $this->touch_session($session->id, array('status' => 'closed', 'closed_at' => $now));
        wp_send_json_success(array('closed' => true));
    }

    public function handle_get_packages() {
        $this->verify_nonce();
        $session = $this->require_session();

        $limit = Madex_Security_Service::check_rate_limit('packages', 30, HOUR_IN_SECONDS);
        if (!$limit['allowed']) {
            $this->rate_limited_response(__('Zu viele Anfragen. Bitte versuchen Sie es später erneut.', 'madex-chatbot'));
        }

        $existing = isset($_POST['existing_client']) ? sanitize_key(wp_unslash($_POST['existing_client'])) : '';
        $existing = in_array($existing, array('yes', 'no'), true) ? $existing : '';
        $services = Madex_Business_Service::service_options();
        $goals = isset($_POST['goals']) ? array_map('sanitize_key', (array) wp_unslash($_POST['goals'])) : array();
        $goals = array_values(array_unique(array_filter($goals, function ($goal) use ($services) { return isset($services[$goal]); })));
        $service = isset($_POST['service']) ? sanitize_key(wp_unslash($_POST['service'])) : '';
        if (!array_key_exists($service, $services)) {
            $service = '';
        }
        if ($service === '' && !empty($goals)) {
            $service = $goals[0];
        }
        if ($service !== '' && empty($goals)) {
            $goals = array($service);
        }
        $has_website = isset($_POST['has_website']) ? sanitize_key(wp_unslash($_POST['has_website'])) : '';
        $company_size = isset($_POST['company_size']) ? sanitize_text_field(wp_unslash($_POST['company_size'])) : '';

        $profile = array('service' => $service, 'goals' => $goals, 'request_type' => 'packages');
        if (in_array($has_website, array('yes', 'no'), true)) {
            $profile['has_website'] = $has_website;
        }
        if ($existing !== '') {
            $profile['existing_client'] = $existing;
            $profile['customer_status'] = $existing === 'yes' ? 'client' : 'prospect';
        }
        if ($company_size !== '') {
            // "11-50" → 11, "51+" → 51: the lower bound drives ≤ / ≥ rules.
            $profile['company_size'] = absint($company_size);
        }

        $update = array();
        if ($existing !== '') {
            $update['customer_type'] = $profile['customer_status'];
        }
        if ($service !== '') {
            $update['topic'] = $service;
        }
        $this->touch_session($session->id, $update);

        $packages = Madex_Business_Service::recommend_packages($profile);
        $public = array();
        foreach ((array) $packages as $package) {
            // Explicit allowlist: internal notes, rules and HTML descriptions
            // never leave the server.
            $public[] = array(
                'id' => (int) $package['id'],
                'name' => (string) $package['name'],
                'short_description' => (string) $package['short_description'],
                'features' => array_values(array_map('strval', (array) $package['features'])),
                'audience' => (string) $package['audience'],
                'cta_label' => (string) $package['cta_label'],
                'matched' => isset($package['match']) ? array_values(array_map('strval', $package['match']['matched'])) : array(),
                'missing' => isset($package['match']) ? array_values(array_map('strval', $package['match']['missing'])) : array(),
            );
        }

        wp_send_json_success(array('packages' => $public));
    }

    public function handle_submit_appointment() {
        $this->verify_nonce();

        if (Madex_Security_Service::is_ip_blocked()) {
            wp_send_json_error(array('message' => __('Zugriff verweigert.', 'madex-chatbot'), 'code' => 'blocked'), 403);
        }

        $session = $this->require_session();

        $limit = Madex_Security_Service::check_rate_limit('appointment', 5, HOUR_IN_SECONDS);
        if (!$limit['allowed']) {
            $this->rate_limited_response(__('Sie haben bereits mehrere Anfragen gesendet. Bitte versuchen Sie es später erneut oder kontaktieren Sie uns direkt.', 'madex-chatbot'));
        }

        $fields = array(
            'customer_name', 'company', 'email', 'phone', 'existing_client', 'service',
            'package_interest', 'preferred_date', 'preferred_time', 'message',
            'privacy_consent', 'idempotency_key',
        );
        $data = array();
        foreach ($fields as $field) {
            $data[$field] = isset($_POST[$field]) ? wp_unslash($_POST[$field]) : '';
        }
        if (!in_array($data['preferred_time'], array('morning', 'midday', 'afternoon', 'flexible'), true)) {
            $data['preferred_time'] = '';
        }
        if (!array_key_exists((string) $data['service'], Madex_Business_Service::service_options())) {
            $data['service'] = '';
        }
        $data['session_public_id'] = $session->public_id;
        $data['request_type'] = 'appointment';

        $result = Madex_Business_Service::create_appointment($data);
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message(), 'code' => $result->get_error_code()), 400);
        }

        $this->touch_session($session->id, array_filter(array(
            'customer_type' => $result['customer_status'] === 'client' ? 'client' : 'prospect',
            'topic' => $result['service'],
        )));

        $first_name = trim(strtok((string) $result['customer_name'], ' '));
        wp_send_json_success(array(
            'reference' => $result['reference'],
            'preferred_date' => $result['preferred_date'],
            'preferred_time' => Madex_Business_Service::time_label($result['preferred_time']),
            'message' => sprintf(
                /* translators: %s: first name */
                __('Vielen Dank, %s. Ihr Wunschtermin ist noch nicht verbindlich – das Madex-Team bestätigt ihn innerhalb eines Werktags per E-Mail.', 'madex-chatbot'),
                $first_name !== '' ? $first_name : __('für Ihre Anfrage', 'madex-chatbot')
            ),
        ));
    }

    /* ------------------------------------------------------------------
     * Admin endpoints
     * ------------------------------------------------------------------ */

    private function require_admin_ajax($nonce_action) {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'madex-chatbot')), 403);
        }
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, $nonce_action)) {
            wp_send_json_error(array('message' => __('Security check failed', 'madex-chatbot')), 403);
        }
    }

    public function handle_delete_session() {
        $this->require_admin_ajax('madex_admin_nonce');

        $session_id = isset($_POST['session_id']) ? absint($_POST['session_id']) : 0;
        if (!$session_id) {
            wp_send_json_error(array('message' => __('Invalid session ID', 'madex-chatbot')));
        }

        global $wpdb;
        $wpdb->delete($this->messages_table(), array('session_id' => $session_id), array('%d'));
        $result = $wpdb->delete($this->sessions_table(), array('id' => $session_id), array('%d'));

        if ($result) {
            wp_send_json_success(array('message' => __('Session deleted successfully', 'madex-chatbot')));
        }
        wp_send_json_error(array('message' => __('Failed to delete session', 'madex-chatbot')));
    }

    public function handle_delete_all_sessions() {
        $this->require_admin_ajax('madex_admin_nonce');

        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$this->messages_table()}");
        $wpdb->query("TRUNCATE TABLE {$this->sessions_table()}");

        wp_send_json_success(array('message' => __('All sessions deleted successfully', 'madex-chatbot')));
    }

    public function handle_test_api() {
        $this->require_admin_ajax('madex_chatbot_admin_nonce');

        $openai = new Madex_OpenAI_Service();
        $result = $openai->test_connection();

        if ($result['success']) {
            wp_send_json_success($result);
        }
        wp_send_json_error($result);
    }
}
