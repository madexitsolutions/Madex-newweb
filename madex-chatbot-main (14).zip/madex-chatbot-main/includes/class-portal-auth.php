<?php
/**
 * Authentication foundation for the standalone Madex management portal.
 *
 * The service authenticates against WordPress users without creating a
 * WordPress login cookie. It then issues a plugin-owned, opaque session only
 * after a second factor succeeds. A future /chatadm controller should call the
 * public methods in this class and must not implement parallel auth logic.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Madex_TOTP')) {
    require_once __DIR__ . '/class-totp.php';
}

class Madex_Portal_Auth {

    const CAPABILITY = 'madex_view_portal';
    const VIEWER_ROLE = 'madex_dashboard_viewer';
    const ALLOWLIST_OPTION = 'madex_portal_allowed_users';
    const PATH_OPTION = 'madex_portal_path';
    const COOKIE_NAME = 'madex_portal_session';

    const STATE_PREAUTH = 'preauth';
    const STATE_ACTIVE = 'active';

    const PREAUTH_TTL = 300;
    const ACTIVE_IDLE_TTL = 1800;
    const ACTIVE_ABSOLUTE_TTL = 28800;
    const SESSION_TOUCH_INTERVAL = 60;
    const RATE_WINDOW = 86400;

    /**
     * Create the private portal security tables and least-privilege role.
     *
     * Call from plugin activation and versioned database upgrades.
     *
     * @return void
     */
    public static function install_schema() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $security_table = self::security_table();
        $sessions_table = self::sessions_table();
        $limits_table = self::limits_table();
        $audit_table = self::audit_table();

        $sql_security = "CREATE TABLE $security_table (
            user_id bigint(20) unsigned NOT NULL,
            totp_secret longtext NULL,
            pending_secret longtext NULL,
            pending_expires_at bigint(20) unsigned NULL,
            last_totp_step bigint(20) NOT NULL DEFAULT -1,
            recovery_hashes longtext NULL,
            enrolled_at bigint(20) unsigned NULL,
            force_reenroll tinyint(1) unsigned NOT NULL DEFAULT 0,
            updated_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (user_id)
        ) $charset_collate;";

        $sql_sessions = "CREATE TABLE $sessions_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            token_hash char(64) NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            state varchar(16) NOT NULL,
            subject_hash char(64) NOT NULL,
            csrf_hash char(64) NULL,
            created_at bigint(20) unsigned NOT NULL,
            last_seen_at bigint(20) unsigned NOT NULL,
            idle_expires_at bigint(20) unsigned NOT NULL,
            absolute_expires_at bigint(20) unsigned NOT NULL,
            ip_hash char(64) NOT NULL,
            ua_hash char(64) NOT NULL,
            revoked_at bigint(20) unsigned NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            KEY user_state (user_id,state),
            KEY expiry (absolute_expires_at,idle_expires_at),
            KEY revoked_at (revoked_at)
        ) $charset_collate;";

        $sql_limits = "CREATE TABLE $limits_table (
            bucket_hash char(64) NOT NULL,
            stage varchar(20) NOT NULL,
            failure_count int(10) unsigned NOT NULL DEFAULT 0,
            window_started_at bigint(20) unsigned NOT NULL,
            locked_until bigint(20) unsigned NOT NULL DEFAULT 0,
            updated_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (bucket_hash,stage),
            KEY locked_until (locked_until),
            KEY updated_at (updated_at)
        ) $charset_collate;";

        $sql_audit = "CREATE TABLE $audit_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_type varchar(64) NOT NULL,
            result varchar(24) NOT NULL,
            user_id bigint(20) unsigned NULL,
            object_type varchar(32) NULL,
            object_id varchar(64) NULL,
            ip_hash char(64) NOT NULL,
            ua_hash char(64) NOT NULL,
            data text NULL,
            created_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (id),
            KEY event_type (event_type),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_security);
        dbDelta($sql_sessions);
        dbDelta($sql_limits);
        dbDelta($sql_audit);

        if (get_option(self::ALLOWLIST_OPTION, null) === null) {
            add_option(self::ALLOWLIST_OPTION, array(), '', 'no');
        }
        if (get_option(self::PATH_OPTION, null) === null) {
            add_option(self::PATH_OPTION, '/chatadm', '', 'no');
        }

        self::ensure_role();
    }

    /**
     * Ensure the least-privilege dashboard-viewer role and capability exist.
     *
     * Existing installations are repaired as well as new ones; add_role()
     * alone does not update the capabilities of an existing role.
     *
     * @return WP_Role|null
     */
    public static function ensure_role() {
        $role = get_role(self::VIEWER_ROLE);
        if (!$role) {
            $role = add_role(
                self::VIEWER_ROLE,
                __('Madex Dashboard Viewer', 'madex-chatbot'),
                array(
                    'read' => true,
                    self::CAPABILITY => true,
                )
            );
        } else {
            $role->add_cap('read', true);
            $role->add_cap(self::CAPABILITY, true);
        }

        return $role;
    }

    /**
     * Controller-facing alias for begin_password_auth().
     *
     * @param string $username Username or email address.
     * @param string $password WordPress password.
     * @return array|WP_Error
     */
    public static function authenticate_password($username, $password) {
        return self::begin_password_auth($username, $password);
    }

    /**
     * Authenticate a WordPress username/email and password.
     *
     * No WordPress auth cookie is created. On success this method sets a
     * five-minute pre-auth cookie and returns the required second-factor step.
     * Authentication failures deliberately use the same public response.
     *
     * @param string $identifier Username or email address.
     * @param string $password   WordPress account password.
     * @return array|WP_Error {next: enroll|totp, expires_at:int}
     */
    public static function begin_password_auth($identifier, $password) {
        if (!self::is_secure_request()) {
            return self::error('madex_portal_https_required', 403);
        }

        $identifier = trim((string) $identifier);
        $password = (string) $password;
        $subject_hash = self::subject_hash_for_identifier($identifier);
        $limit = self::check_rate_limit('password', $subject_hash);

        if (!$limit['allowed']) {
            self::audit('password_rate_limited', 'blocked', 0, array('retry_after' => $limit['retry_after']));
            return self::rate_error($limit['retry_after']);
        }

        if ($identifier === '' || $password === '' || strlen($identifier) > 254 || strlen($password) > 4096) {
            self::record_rate_failure('password', $subject_hash);
            self::audit('password_login', 'failed');
            return self::error('madex_portal_invalid_credentials', 401);
        }

        // wp_authenticate() returns early for unknown accounts. Hash once so the
        // response time does not reveal whether an account exists.
        if (!get_user_by('login', $identifier) && !(is_email($identifier) && get_user_by('email', $identifier))) {
            wp_check_password($password, self::timing_hash());
        }

        $user = wp_authenticate($identifier, $password);
        if (is_wp_error($user) || !($user instanceof WP_User)) {
            $rate = self::record_rate_failure('password', $subject_hash);
            self::audit('password_login', 'failed', 0, array('retry_after' => $rate['retry_after']));

            if (!$rate['allowed']) {
                return self::rate_error($rate['retry_after']);
            }

            return self::error('madex_portal_invalid_credentials', 401);
        }

        // Collapse username and email aliases into one account throttle bucket.
        $subject_hash = self::subject_hash_for_user((int) $user->ID);

        if (!self::is_user_allowed((int) $user->ID)) {
            $rate = self::record_rate_failure('password', $subject_hash);
            self::audit('portal_access', 'denied', (int) $user->ID, array('retry_after' => $rate['retry_after']));
            return self::error('madex_portal_invalid_credentials', 401);
        }

        self::revoke_current_cookie_session(false);
        $session = self::create_session((int) $user->ID, self::STATE_PREAUTH, $subject_hash);
        if (is_wp_error($session)) {
            return $session;
        }

        $status = self::get_2fa_status((int) $user->ID);
        $next = $status['enrolled'] && !$status['force_reenroll'] ? 'totp' : 'enroll';

        self::audit('password_login', 'verified', (int) $user->ID, array('next' => $next));

        return array(
            'success' => true,
            'next' => $next,
            'expires_at' => (int) $session['absolute_expires_at'],
        );
    }

    /**
     * Start or restart first-time TOTP enrollment for a pre-auth session.
     *
     * The returned secret/URI are sensitive and must be rendered only on the
     * no-store enrollment response. Generate the QR locally; never call a
     * third-party QR service.
     *
     * @param string $issuer Authenticator issuer label.
     * @return array|WP_Error {secret:string,otpauth_uri:string,expires_at:int}
     */
    public static function start_totp_enrollment($issuer = 'Madex Management') {
        $session = self::load_current_session(self::STATE_PREAUTH, false);
        if (is_wp_error($session)) {
            return $session;
        }

        $user_id = (int) $session['user_id'];
        $status = self::get_2fa_status($user_id);
        if ($status['enrolled'] && !$status['force_reenroll']) {
            return self::error('madex_portal_invalid_auth_state', 409);
        }

        $secret = Madex_TOTP::generate_secret();
        if (is_wp_error($secret)) {
            self::audit('totp_enrollment', 'failed', $user_id, array('reason' => 'random_generation'));
            return self::error('madex_portal_setup_failed', 500);
        }

        $encrypted = self::encrypt_totp_secret($secret);
        if (is_wp_error($encrypted)) {
            self::audit('totp_enrollment', 'failed', $user_id, array('reason' => 'encryption'));
            return self::error('madex_portal_setup_failed', 500);
        }

        self::ensure_security_row($user_id);
        $expires_at = min((int) $session['absolute_expires_at'], time() + self::PREAUTH_TTL);

        global $wpdb;
        $updated = $wpdb->update(
            self::security_table(),
            array(
                'pending_secret' => $encrypted,
                'pending_expires_at' => $expires_at,
                'updated_at' => time(),
            ),
            array('user_id' => $user_id),
            array('%s', '%d', '%d'),
            array('%d')
        );

        if ($updated === false) {
            self::audit('totp_enrollment', 'failed', $user_id, array('reason' => 'persistence'));
            return self::error('madex_portal_setup_failed', 500);
        }

        $user = get_userdata($user_id);
        $account = $user ? $user->user_login : 'user-' . $user_id;
        $uri = Madex_TOTP::build_otpauth_uri($secret, $account, $issuer);
        if (is_wp_error($uri)) {
            return self::error('madex_portal_setup_failed', 500);
        }

        self::audit('totp_enrollment', 'started', $user_id);

        return array(
            'success' => true,
            'secret' => $secret,
            'otpauth_uri' => $uri,
            'expires_at' => $expires_at,
        );
    }

    /**
     * Controller-facing alias for start_totp_enrollment().
     *
     * @param string $issuer Authenticator issuer label.
     * @return array|WP_Error
     */
    public static function begin_enrollment($issuer = 'Madex Management') {
        return self::start_totp_enrollment($issuer);
    }

    /**
     * Return the current pending enrollment payload to the same valid pre-auth
     * session. This supports a server-rendered QR page without client storage.
     * The response must always use send_security_headers() and no-store caching.
     *
     * @param string $issuer Authenticator issuer label.
     * @return array|WP_Error
     */
    public static function get_enrollment_payload($issuer = 'Madex Management') {
        $session = self::load_current_session(self::STATE_PREAUTH, false);
        if (is_wp_error($session)) {
            return $session;
        }

        $security = self::get_security_row((int) $session['user_id']);
        if (!$security || empty($security['pending_secret']) || (int) $security['pending_expires_at'] < time()) {
            self::clear_pending_enrollment((int) $session['user_id']);
            return self::error('madex_portal_setup_expired', 401);
        }

        $secret = self::decrypt_totp_secret($security['pending_secret']);
        if (is_wp_error($secret)) {
            return self::error('madex_portal_setup_failed', 500);
        }

        $user = get_userdata((int) $session['user_id']);
        $account = $user ? $user->user_login : 'user-' . (int) $session['user_id'];
        $uri = Madex_TOTP::build_otpauth_uri($secret, $account, $issuer);
        if (is_wp_error($uri)) {
            return self::error('madex_portal_setup_failed', 500);
        }

        return array(
            'success' => true,
            'secret' => $secret,
            'otpauth_uri' => $uri,
            'expires_at' => (int) $security['pending_expires_at'],
        );
    }

    /**
     * Confirm pending enrollment with a TOTP, create one-time recovery codes,
     * and rotate the pre-auth token into an active portal session.
     *
     * Recovery codes are returned exactly once. Only their independent hashes
     * are stored.
     *
     * @param string $code Six-digit authenticator code.
     * @return array|WP_Error
     */
    public static function confirm_totp_enrollment($code) {
        $session = self::load_current_session(self::STATE_PREAUTH, false);
        if (is_wp_error($session)) {
            return $session;
        }

        $user_id = (int) $session['user_id'];
        $limit = self::check_rate_limit('totp', $session['subject_hash']);
        if (!$limit['allowed']) {
            return self::rate_error($limit['retry_after']);
        }

        $security = self::get_security_row($user_id);
        if (!$security || empty($security['pending_secret']) || (int) $security['pending_expires_at'] < time()) {
            self::clear_pending_enrollment($user_id);
            return self::error('madex_portal_setup_expired', 401);
        }

        $secret = self::decrypt_totp_secret($security['pending_secret']);
        if (is_wp_error($secret)) {
            self::audit('totp_enrollment', 'failed', $user_id, array('reason' => 'decryption'));
            return self::error('madex_portal_setup_failed', 500);
        }

        $verification = Madex_TOTP::verify($secret, $code, -1, null, 1);
        if (!$verification['valid']) {
            $rate = self::record_rate_failure('totp', $session['subject_hash']);
            self::audit('totp_enrollment', 'failed', $user_id, array('reason' => 'invalid_code'));

            if (!$rate['allowed']) {
                return self::rate_error($rate['retry_after']);
            }

            return self::error('madex_portal_invalid_verification', 401);
        }

        $recovery = Madex_TOTP::generate_recovery_codes(8);
        if (is_wp_error($recovery)) {
            return self::error('madex_portal_setup_failed', 500);
        }

        $recovery_json = wp_json_encode($recovery['hashes']);
        if (!is_string($recovery_json)) {
            return self::error('madex_portal_setup_failed', 500);
        }

        global $wpdb;
        $now = time();
        $query = $wpdb->prepare(
            'UPDATE ' . self::security_table() . '
             SET totp_secret = pending_secret,
                 pending_secret = NULL,
                 pending_expires_at = NULL,
                 last_totp_step = %d,
                 recovery_hashes = %s,
                 enrolled_at = %d,
                 force_reenroll = 0,
                 updated_at = %d
             WHERE user_id = %d
               AND pending_secret = %s
               AND pending_expires_at >= %d',
            (int) $verification['counter'],
            $recovery_json,
            $now,
            $now,
            $user_id,
            $security['pending_secret'],
            $now
        );
        $updated = $wpdb->query($query);

        if ((int) $updated !== 1) {
            self::record_rate_failure('totp', $session['subject_hash']);
            return self::error('madex_portal_invalid_verification', 401);
        }

        $active = self::activate_session($session);
        if (is_wp_error($active)) {
            return $active;
        }

        self::clear_rate_limits($session['subject_hash']);
        self::audit('totp_enrollment', 'completed', $user_id, array('recovery_remaining' => count($recovery['hashes'])));

        return array(
            'success' => true,
            'recovery_codes' => $recovery['codes'],
            'recovery_codes_remaining' => count($recovery['hashes']),
            'csrf_token' => $active['csrf_token'],
            'idle_expires_at' => $active['idle_expires_at'],
            'absolute_expires_at' => $active['absolute_expires_at'],
        );
    }

    /**
     * Controller-facing alias for confirm_totp_enrollment().
     *
     * @param string $code Six-digit authenticator code.
     * @return array|WP_Error
     */
    public static function confirm_enrollment($code) {
        return self::confirm_totp_enrollment($code);
    }

    /**
     * Complete a normal login with a TOTP and rotate into an active session.
     *
     * @param string $code Six-digit authenticator code.
     * @return array|WP_Error
     */
    public static function verify_totp_challenge($code) {
        $session = self::load_current_session(self::STATE_PREAUTH, false);
        if (is_wp_error($session)) {
            return $session;
        }

        $limit = self::check_rate_limit('totp', $session['subject_hash']);
        if (!$limit['allowed']) {
            return self::rate_error($limit['retry_after']);
        }

        $user_id = (int) $session['user_id'];
        $security = self::get_security_row($user_id);
        if (!$security || empty($security['totp_secret']) || !empty($security['force_reenroll'])) {
            return self::error('madex_portal_invalid_auth_state', 409);
        }

        $secret = self::decrypt_totp_secret($security['totp_secret']);
        if (is_wp_error($secret)) {
            self::audit('totp_login', 'failed', $user_id, array('reason' => 'decryption'));
            return self::error('madex_portal_setup_failed', 500);
        }

        $verification = Madex_TOTP::verify(
            $secret,
            $code,
            (int) $security['last_totp_step'],
            null,
            1
        );

        if (!$verification['valid']) {
            $rate = self::record_rate_failure('totp', $session['subject_hash']);
            self::audit('totp_login', 'failed', $user_id, array('reason' => 'invalid_code'));

            if (!$rate['allowed']) {
                return self::rate_error($rate['retry_after']);
            }

            return self::error('madex_portal_invalid_verification', 401);
        }

        // Atomic compare-and-set enforces RFC 6238 one-time acceptance even if
        // two requests carrying the same TOTP arrive concurrently.
        global $wpdb;
        $updated = $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . self::security_table() . '
                 SET last_totp_step = %d, updated_at = %d
                 WHERE user_id = %d AND last_totp_step < %d',
                (int) $verification['counter'],
                time(),
                $user_id,
                (int) $verification['counter']
            )
        );

        if ((int) $updated !== 1) {
            self::record_rate_failure('totp', $session['subject_hash']);
            self::audit('totp_login', 'failed', $user_id, array('reason' => 'replay'));
            return self::error('madex_portal_invalid_verification', 401);
        }

        $active = self::activate_session($session);
        if (is_wp_error($active)) {
            return $active;
        }

        self::clear_rate_limits($session['subject_hash']);
        self::audit('totp_login', 'verified', $user_id);

        return array(
            'success' => true,
            'csrf_token' => $active['csrf_token'],
            'idle_expires_at' => $active['idle_expires_at'],
            'absolute_expires_at' => $active['absolute_expires_at'],
        );
    }

    /**
     * Complete login with, and atomically consume, a one-time recovery code.
     *
     * @param string $code Recovery code.
     * @return array|WP_Error
     */
    public static function verify_recovery_challenge($code) {
        $session = self::load_current_session(self::STATE_PREAUTH, false);
        if (is_wp_error($session)) {
            return $session;
        }

        $limit = self::check_rate_limit('recovery', $session['subject_hash']);
        if (!$limit['allowed']) {
            return self::rate_error($limit['retry_after']);
        }

        $user_id = (int) $session['user_id'];
        $security = self::get_security_row($user_id);
        $stored_json = $security && is_string($security['recovery_hashes']) ? $security['recovery_hashes'] : '[]';
        $hashes = json_decode($stored_json, true);
        if (!is_array($hashes)) {
            $hashes = array();
        }

        $consumed = Madex_TOTP::consume_recovery_code($code, $hashes);
        if (!$consumed['valid']) {
            $rate = self::record_rate_failure('recovery', $session['subject_hash']);
            self::audit('recovery_login', 'failed', $user_id, array('reason' => 'invalid_code'));

            if (!$rate['allowed']) {
                return self::rate_error($rate['retry_after']);
            }

            return self::error('madex_portal_invalid_verification', 401);
        }

        $remaining_json = wp_json_encode($consumed['remaining_hashes']);
        if (!is_string($remaining_json)) {
            return self::error('madex_portal_auth_failed', 500);
        }

        // Compare the exact previous JSON value so the same code cannot be
        // consumed twice by concurrent requests.
        global $wpdb;
        $updated = $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . self::security_table() . '
                 SET recovery_hashes = %s, updated_at = %d
                 WHERE user_id = %d AND recovery_hashes = %s',
                $remaining_json,
                time(),
                $user_id,
                $stored_json
            )
        );

        if ((int) $updated !== 1) {
            self::record_rate_failure('recovery', $session['subject_hash']);
            self::audit('recovery_login', 'failed', $user_id, array('reason' => 'concurrent_use'));
            return self::error('madex_portal_invalid_verification', 401);
        }

        $active = self::activate_session($session);
        if (is_wp_error($active)) {
            return $active;
        }

        self::clear_rate_limits($session['subject_hash']);
        self::audit(
            'recovery_login',
            'verified',
            $user_id,
            array('recovery_remaining' => count($consumed['remaining_hashes']))
        );

        return array(
            'success' => true,
            'recovery_codes_remaining' => count($consumed['remaining_hashes']),
            'csrf_token' => $active['csrf_token'],
            'idle_expires_at' => $active['idle_expires_at'],
            'absolute_expires_at' => $active['absolute_expires_at'],
        );
    }

    /**
     * Verify the current second-factor challenge.
     *
     * Pass a recovery code in the second argument to select recovery mode;
     * otherwise the first argument is treated as a TOTP.
     *
     * @param string $code          Six-digit authenticator code.
     * @param string $recovery_code Optional one-time recovery code.
     * @return array|WP_Error
     */
    public static function verify_challenge($code, $recovery_code = '') {
        if (trim((string) $recovery_code) !== '') {
            return self::verify_recovery_challenge($recovery_code);
        }

        return self::verify_totp_challenge($code);
    }

    /**
     * Return the required second-factor step for the current pre-auth session.
     *
     * @return array|WP_Error {type:enroll|totp,expires_at:int,user_id:int}
     */
    public static function get_current_challenge() {
        $session = self::load_current_session(self::STATE_PREAUTH, false);
        if (is_wp_error($session)) {
            return $session;
        }

        $status = self::get_2fa_status((int) $session['user_id']);

        return array(
            'type' => $status['enrolled'] && !$status['force_reenroll'] ? 'totp' : 'enroll',
            'expires_at' => (int) $session['absolute_expires_at'],
            'user_id' => (int) $session['user_id'],
        );
    }

    /**
     * Validate the current active portal session and extend its idle timeout.
     *
     * @return array|WP_Error Safe session context (never includes token hashes).
     */
    public static function get_active_session($touch = true) {
        $session = self::load_current_session(self::STATE_ACTIVE, (bool) $touch);
        if (is_wp_error($session)) {
            return $session;
        }

        return self::public_session_context($session);
    }

    /**
     * Stable per-session CSRF token derived from the opaque session cookie.
     *
     * Rotating tokens break multi-tab use; deriving from the HttpOnly session
     * secret gives an unguessable token that is valid for exactly one session.
     * Callers must have validated the active session first.
     *
     * @return string Empty string when no session cookie exists.
     */
    public static function form_token() {
        $raw = self::read_cookie_token();
        return $raw === '' ? '' : self::hash_secret('form-csrf', $raw);
    }

    /**
     * Constant-time check of a submitted form token.
     *
     * @param string $token Submitted token.
     * @return bool
     */
    public static function verify_form_token($token) {
        $expected = self::form_token();
        return $expected !== '' && is_string($token) && hash_equals($expected, $token);
    }

    /**
     * Controller-facing alias for get_active_session().
     *
     * @return array|WP_Error
     */
    public static function get_current_session() {
        return self::get_active_session();
    }

    /**
     * Return the current pre-auth state for an enrollment/challenge controller.
     *
     * @return array|WP_Error
     */
    public static function get_preauth_session() {
        $session = self::load_current_session(self::STATE_PREAUTH, false);
        if (is_wp_error($session)) {
            return $session;
        }

        return self::public_session_context($session);
    }

    /**
     * Rotate and return a CSRF token for the active session.
     *
     * @return string|WP_Error Raw token for an HTML meta tag/in-memory client.
     */
    public static function issue_csrf_token() {
        $session = self::load_current_session(self::STATE_ACTIVE, true);
        if (is_wp_error($session)) {
            return $session;
        }

        $token = self::random_token();
        if (is_wp_error($token)) {
            return $token;
        }

        $hash = self::hash_secret('csrf', $token);
        global $wpdb;
        $updated = $wpdb->update(
            self::sessions_table(),
            array('csrf_hash' => $hash),
            array('id' => (int) $session['id'], 'revoked_at' => null),
            array('%s'),
            array('%d', null)
        );

        if ($updated === false) {
            return self::error('madex_portal_auth_failed', 500);
        }

        return $token;
    }

    /**
     * Validate an active-session CSRF token in constant time.
     *
     * State-changing controllers should additionally reject cross-origin
     * Origin/Referer values and use POST/PUT/PATCH/DELETE, never GET.
     *
     * @param string $token Submitted CSRF token.
     * @return bool|WP_Error
     */
    public static function validate_csrf($token) {
        $session = self::load_current_session(self::STATE_ACTIVE, true);
        if (is_wp_error($session)) {
            return $session;
        }

        $token = (string) $token;
        if ($token === '' || empty($session['csrf_hash'])) {
            return false;
        }

        return hash_equals($session['csrf_hash'], self::hash_secret('csrf', $token));
    }

    /**
     * End the current plugin-owned portal session. Idempotent by design.
     *
     * @return bool
     */
    public static function logout() {
        $raw_token = self::read_cookie_token();
        $session = null;

        if ($raw_token !== '') {
            global $wpdb;
            $token_hash = self::hash_secret('session', $raw_token);
            $session = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT id, user_id FROM ' . self::sessions_table() . ' WHERE token_hash = %s LIMIT 1',
                    $token_hash
                ),
                ARRAY_A
            );

            $wpdb->update(
                self::sessions_table(),
                array('revoked_at' => time()),
                array('token_hash' => $token_hash),
                array('%d'),
                array('%s')
            );
        }

        self::clear_session_cookie();

        if ($session) {
            self::audit('portal_logout', 'success', (int) $session['user_id']);
        }

        return true;
    }

    /**
     * Add/remove an explicit portal allowlist entry and direct user capability.
     *
     * The caller must also use a WordPress nonce in its admin controller.
     *
     * @param int  $user_id WordPress user ID.
     * @param bool $allowed Whether portal access is enabled.
     * @return bool|WP_Error
     */
    public static function set_user_access($user_id, $allowed) {
        if (!current_user_can('manage_options')) {
            return self::error('madex_portal_forbidden', 403);
        }

        $user_id = (int) $user_id;
        $user = get_userdata($user_id);
        if (!$user) {
            return self::error('madex_portal_invalid_user', 404);
        }

        $allowlist = self::get_allowlist();
        if ($allowed) {
            $allowlist[] = $user_id;
            $allowlist = array_values(array_unique(array_map('intval', $allowlist)));
            $user->add_cap(self::CAPABILITY, true);
        } else {
            $allowlist = array_values(array_diff($allowlist, array($user_id)));
            $user->remove_cap(self::CAPABILITY);
            self::revoke_user_sessions($user_id, 'access_removed');
        }

        update_option(self::ALLOWLIST_OPTION, $allowlist, false);
        self::audit('portal_access_changed', $allowed ? 'enabled' : 'disabled', $user_id);

        return true;
    }

    /**
     * Determine whether a user has both the portal capability and explicit
     * allowlist membership. Neither condition alone grants access.
     *
     * @param int $user_id WordPress user ID.
     * @return bool
     */
    public static function is_user_allowed($user_id) {
        $user_id = (int) $user_id;
        if ($user_id <= 0 || !in_array($user_id, self::get_allowlist(), true)) {
            return false;
        }

        $user = get_userdata($user_id);
        return $user instanceof WP_User && user_can($user, self::CAPABILITY);
    }

    /**
     * Reset a user's TOTP enrollment and revoke every portal session.
     *
     * The caller must also use a WordPress nonce in its admin controller.
     *
     * @param int $user_id WordPress user ID.
     * @return bool|WP_Error
     */
    public static function reset_user_2fa($user_id) {
        if (!current_user_can('manage_options')) {
            return self::error('madex_portal_forbidden', 403);
        }

        $user_id = (int) $user_id;
        if (!get_userdata($user_id)) {
            return self::error('madex_portal_invalid_user', 404);
        }

        self::ensure_security_row($user_id);
        global $wpdb;
        $updated = $wpdb->update(
            self::security_table(),
            array(
                'totp_secret' => null,
                'pending_secret' => null,
                'pending_expires_at' => null,
                'last_totp_step' => -1,
                'recovery_hashes' => null,
                'enrolled_at' => null,
                'force_reenroll' => 1,
                'updated_at' => time(),
            ),
            array('user_id' => $user_id),
            array(null, null, null, '%d', null, null, '%d', '%d'),
            array('%d')
        );

        if ($updated === false) {
            return self::error('madex_portal_auth_failed', 500);
        }

        self::revoke_user_sessions($user_id, 'two_factor_reset');
        self::audit('two_factor_reset', 'success', $user_id);

        return true;
    }

    /**
     * Return non-secret 2FA state for an authorized admin/controller.
     *
     * @param int $user_id WordPress user ID.
     * @return array{enrolled:bool,force_reenroll:bool,recovery_codes_remaining:int,enrolled_at:int}
     */
    public static function get_2fa_status($user_id) {
        $row = self::get_security_row((int) $user_id);
        $hashes = array();

        if ($row && !empty($row['recovery_hashes'])) {
            $decoded = json_decode($row['recovery_hashes'], true);
            if (is_array($decoded)) {
                $hashes = $decoded;
            }
        }

        return array(
            'enrolled' => (bool) ($row && !empty($row['totp_secret']) && !empty($row['enrolled_at'])),
            'force_reenroll' => (bool) ($row && !empty($row['force_reenroll'])),
            'recovery_codes_remaining' => count($hashes),
            'enrolled_at' => $row ? (int) $row['enrolled_at'] : 0,
        );
    }

    /**
     * Revoke every portal session for a user.
     *
     * @param int    $user_id WordPress user ID.
     * @param string $reason  Minimal audit reason.
     * @return int|false Number of updated rows, or false on failure.
     */
    public static function revoke_user_sessions($user_id, $reason = 'revoked') {
        global $wpdb;
        $user_id = (int) $user_id;
        $now = time();
        $updated = $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . self::sessions_table() . '
                 SET revoked_at = %d
                 WHERE user_id = %d AND revoked_at IS NULL',
                $now,
                $user_id
            )
        );

        self::audit('portal_sessions_revoked', $updated === false ? 'failed' : 'success', $user_id, array('reason' => $reason));
        return $updated;
    }

    /**
     * Purge expired session/limit rows and stale pending enrollment material.
     *
     * @return void
     */
    public static function cleanup_expired() {
        global $wpdb;
        $now = time();
        $session_cutoff = $now - DAY_IN_SECONDS;
        $limit_cutoff = $now - (2 * DAY_IN_SECONDS);

        $wpdb->query(
            $wpdb->prepare(
                'DELETE FROM ' . self::sessions_table() . '
                 WHERE absolute_expires_at < %d
                    OR (revoked_at IS NOT NULL AND revoked_at < %d)',
                $session_cutoff,
                $session_cutoff
            )
        );
        $wpdb->query(
            $wpdb->prepare(
                'DELETE FROM ' . self::limits_table() . '
                 WHERE updated_at < %d AND locked_until < %d',
                $limit_cutoff,
                $now
            )
        );
        $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . self::security_table() . '
                 SET pending_secret = NULL, pending_expires_at = NULL, updated_at = %d
                 WHERE pending_expires_at IS NOT NULL AND pending_expires_at < %d',
                $now,
                $now
            )
        );
    }

    /**
     * Send privacy/security headers for every /chatadm HTML and API response.
     *
     * The CSP intentionally disallows inline and third-party assets. The portal
     * controller must enqueue bundled scripts, fonts, and QR code generation.
     * Server/PHP version-header removal and domain-wide HSTS should additionally
     * be configured at the web server or CDN.
     *
     * @return bool False when headers were already sent.
     */
    public static function send_secure_headers() {
        if (headers_sent()) {
            return false;
        }

        nocache_headers();
        header_remove('X-Powered-By');
        header('Cache-Control: no-store, no-cache, must-revalidate, private, max-age=0', true);
        header('Pragma: no-cache', true);
        header('Expires: 0', true);
        header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet', true);
        header('X-Content-Type-Options: nosniff', true);
        header('X-Frame-Options: DENY', true);
        // same-origin keeps a real Origin header on same-site POSTs (needed for
        // the CSRF origin check) while never leaking URLs to other sites.
        header('Referrer-Policy: same-origin', true);
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()', true);
        header('Cross-Origin-Opener-Policy: same-origin', true);
        header('Cross-Origin-Resource-Policy: same-origin', true);
        header(
            "Content-Security-Policy: default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data:; font-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'",
            true
        );

        if (self::is_secure_request()) {
            header('Strict-Transport-Security: max-age=31536000', true);
        }

        return true;
    }

    /**
     * Create and persist a pre-auth or active opaque session.
     *
     * @param int    $user_id      WordPress user ID.
     * @param string $state        preauth|active.
     * @param string $subject_hash Pseudonymous rate-limit subject.
     * @return array|WP_Error
     */
    private static function create_session($user_id, $state, $subject_hash) {
        if (!in_array($state, array(self::STATE_PREAUTH, self::STATE_ACTIVE), true)) {
            return self::error('madex_portal_invalid_auth_state', 500);
        }

        $token = self::random_token();
        if (is_wp_error($token)) {
            return $token;
        }

        $csrf_token = '';
        $csrf_hash = null;
        if ($state === self::STATE_ACTIVE) {
            $csrf_token = self::random_token();
            if (is_wp_error($csrf_token)) {
                return $csrf_token;
            }
            $csrf_hash = self::hash_secret('csrf', $csrf_token);
        }

        $now = time();
        $absolute_expires_at = $state === self::STATE_PREAUTH
            ? $now + self::PREAUTH_TTL
            : $now + self::ACTIVE_ABSOLUTE_TTL;
        $idle_expires_at = $state === self::STATE_PREAUTH
            ? $absolute_expires_at
            : min($absolute_expires_at, $now + self::idle_ttl());

        global $wpdb;

        if ($state === self::STATE_PREAUTH) {
            $wpdb->query(
                $wpdb->prepare(
                    'UPDATE ' . self::sessions_table() . '
                     SET revoked_at = %d
                     WHERE user_id = %d AND state = %s AND revoked_at IS NULL',
                    $now,
                    (int) $user_id,
                    self::STATE_PREAUTH
                )
            );
        }

        $inserted = $wpdb->insert(
            self::sessions_table(),
            array(
                'token_hash' => self::hash_secret('session', $token),
                'user_id' => (int) $user_id,
                'state' => $state,
                'subject_hash' => $subject_hash,
                'csrf_hash' => $csrf_hash,
                'created_at' => $now,
                'last_seen_at' => $now,
                'idle_expires_at' => $idle_expires_at,
                'absolute_expires_at' => $absolute_expires_at,
                'ip_hash' => self::network_hash(),
                'ua_hash' => self::user_agent_hash(),
                'revoked_at' => null,
            ),
            array('%s', '%d', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', null)
        );

        if ($inserted === false) {
            return self::error('madex_portal_auth_failed', 500);
        }

        $session_id = (int) $wpdb->insert_id;
        if (!self::set_session_cookie($token, $absolute_expires_at)) {
            $wpdb->delete(self::sessions_table(), array('id' => $session_id), array('%d'));
            return self::error('madex_portal_cookie_failed', 500);
        }

        return array(
            'id' => $session_id,
            'user_id' => (int) $user_id,
            'state' => $state,
            'subject_hash' => $subject_hash,
            'csrf_token' => $csrf_token,
            'idle_expires_at' => $idle_expires_at,
            'absolute_expires_at' => $absolute_expires_at,
        );
    }

    /**
     * Rotate a verified pre-auth session into a new active token.
     *
     * @param array $preauth Pre-auth database row.
     * @return array|WP_Error
     */
    private static function activate_session($preauth) {
        if (!self::is_user_allowed((int) $preauth['user_id'])) {
            self::revoke_session_id((int) $preauth['id']);
            return self::error('madex_portal_forbidden', 403);
        }

        $active = self::create_session(
            (int) $preauth['user_id'],
            self::STATE_ACTIVE,
            $preauth['subject_hash']
        );

        if (is_wp_error($active)) {
            return $active;
        }

        self::revoke_session_id((int) $preauth['id']);
        return $active;
    }

    /**
     * Load and validate the current cookie-backed session.
     *
     * @param string $required_state Required state.
     * @param bool   $touch          Extend active idle timeout.
     * @return array|WP_Error
     */
    private static function load_current_session($required_state, $touch) {
        $raw_token = self::read_cookie_token();
        if ($raw_token === '') {
            return self::error('madex_portal_auth_required', 401);
        }

        global $wpdb;
        $session = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . self::sessions_table() . ' WHERE token_hash = %s LIMIT 1',
                self::hash_secret('session', $raw_token)
            ),
            ARRAY_A
        );

        if (!$session || !empty($session['revoked_at'])) {
            self::clear_session_cookie();
            return self::error('madex_portal_auth_required', 401);
        }

        $now = time();
        if ((int) $session['absolute_expires_at'] <= $now || (int) $session['idle_expires_at'] <= $now) {
            self::revoke_session_id((int) $session['id']);
            self::clear_session_cookie();
            self::audit('portal_session', 'expired', (int) $session['user_id']);
            return self::error('madex_portal_session_expired', 401);
        }

        if (!hash_equals($session['ua_hash'], self::user_agent_hash())) {
            self::revoke_session_id((int) $session['id']);
            self::clear_session_cookie();
            self::audit('portal_session', 'revoked', (int) $session['user_id'], array('reason' => 'device_mismatch'));
            return self::error('madex_portal_auth_required', 401);
        }

        if ($session['state'] === self::STATE_PREAUTH && !hash_equals($session['ip_hash'], self::network_hash())) {
            self::revoke_session_id((int) $session['id']);
            self::clear_session_cookie();
            self::audit('portal_session', 'revoked', (int) $session['user_id'], array('reason' => 'network_mismatch'));
            return self::error('madex_portal_auth_required', 401);
        }

        if ($session['state'] !== $required_state) {
            return self::error('madex_portal_invalid_auth_state', 409);
        }

        if (!self::is_user_allowed((int) $session['user_id'])) {
            self::revoke_session_id((int) $session['id']);
            self::clear_session_cookie();
            return self::error('madex_portal_forbidden', 403);
        }

        if ($touch && $session['state'] === self::STATE_ACTIVE && ($now - (int) $session['last_seen_at']) >= self::SESSION_TOUCH_INTERVAL) {
            $new_idle = min((int) $session['absolute_expires_at'], $now + self::idle_ttl());
            $wpdb->update(
                self::sessions_table(),
                array('last_seen_at' => $now, 'idle_expires_at' => $new_idle),
                array('id' => (int) $session['id'], 'revoked_at' => null),
                array('%d', '%d'),
                array('%d', null)
            );
            $session['last_seen_at'] = $now;
            $session['idle_expires_at'] = $new_idle;
        }

        return $session;
    }

    /**
     * Reduce a database session row to controller-safe context.
     *
     * @param array $session Session row.
     * @return array
     */
    private static function public_session_context($session) {
        return array(
            'session_id' => (int) $session['id'],
            'user_id' => (int) $session['user_id'],
            'state' => $session['state'],
            'created_at' => (int) $session['created_at'],
            'last_seen_at' => (int) $session['last_seen_at'],
            'idle_expires_at' => (int) $session['idle_expires_at'],
            'absolute_expires_at' => (int) $session['absolute_expires_at'],
        );
    }

    /**
     * Check account and REMOTE_ADDR rate buckets for an authentication stage.
     *
     * @param string $stage        password|totp|recovery.
     * @param string $subject_hash Pseudonymous account identifier.
     * @return array{allowed:bool,retry_after:int}
     */
    private static function check_rate_limit($stage, $subject_hash) {
        global $wpdb;
        $stage = self::normalize_stage($stage);
        $now = time();
        $retry_after = 0;

        foreach (self::rate_bucket_hashes($stage, $subject_hash) as $bucket_hash) {
            $locked_until = $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT locked_until FROM ' . self::limits_table() . '
                     WHERE bucket_hash = %s AND stage = %s LIMIT 1',
                    $bucket_hash,
                    $stage
                )
            );
            $retry_after = max($retry_after, max(0, (int) $locked_until - $now));
        }

        return array('allowed' => $retry_after === 0, 'retry_after' => $retry_after);
    }

    /**
     * Atomically increment account and network failure counters.
     *
     * @param string $stage        Authentication stage.
     * @param string $subject_hash Pseudonymous account identifier.
     * @return array{allowed:bool,retry_after:int}
     */
    private static function record_rate_failure($stage, $subject_hash) {
        global $wpdb;
        $stage = self::normalize_stage($stage);
        $now = time();
        $cutoff = $now - self::RATE_WINDOW;
        $retry_after = 0;

        foreach (self::rate_bucket_hashes($stage, $subject_hash) as $bucket_hash) {
            $sql = $wpdb->prepare(
                'INSERT INTO ' . self::limits_table() . '
                    (bucket_hash, stage, failure_count, window_started_at, locked_until, updated_at)
                 VALUES (%s, %s, 1, %d, 0, %d)
                 ON DUPLICATE KEY UPDATE
                    failure_count = IF(updated_at < %d, 1, failure_count + 1),
                    window_started_at = IF(updated_at < %d, %d, window_started_at),
                    locked_until = IF(updated_at < %d, 0, locked_until),
                    updated_at = %d',
                $bucket_hash,
                $stage,
                $now,
                $now,
                $cutoff,
                $cutoff,
                $now,
                $cutoff,
                $now
            );
            $wpdb->query($sql);

            $row = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT failure_count, locked_until FROM ' . self::limits_table() . '
                     WHERE bucket_hash = %s AND stage = %s LIMIT 1',
                    $bucket_hash,
                    $stage
                ),
                ARRAY_A
            );

            if (!$row) {
                continue;
            }

            $delay = self::rate_delay_for_count((int) $row['failure_count']);
            if ($delay > 0) {
                $locked_until = max((int) $row['locked_until'], $now + $delay);
                $wpdb->update(
                    self::limits_table(),
                    array('locked_until' => $locked_until, 'updated_at' => $now),
                    array('bucket_hash' => $bucket_hash, 'stage' => $stage),
                    array('%d', '%d'),
                    array('%s', '%s')
                );
                $retry_after = max($retry_after, $locked_until - $now);
            }
        }

        return array('allowed' => $retry_after === 0, 'retry_after' => $retry_after);
    }

    /**
     * Clear all auth-stage counters for an account and the current network.
     *
     * @param string $subject_hash Pseudonymous account identifier.
     * @return void
     */
    private static function clear_rate_limits($subject_hash) {
        global $wpdb;

        foreach (array('password', 'totp', 'recovery') as $stage) {
            foreach (self::rate_bucket_hashes($stage, $subject_hash) as $bucket_hash) {
                $wpdb->delete(
                    self::limits_table(),
                    array('bucket_hash' => $bucket_hash, 'stage' => $stage),
                    array('%s', '%s')
                );
            }
        }
    }

    /**
     * Return progressive cooldown duration for a failed-attempt count.
     *
     * @param int $count Failure count in the 24-hour window.
     * @return int Seconds.
     */
    private static function rate_delay_for_count($count) {
        if ($count >= 20) {
            return HOUR_IN_SECONDS;
        }
        if ($count >= 10) {
            return 15 * MINUTE_IN_SECONDS;
        }
        if ($count >= 5) {
            return MINUTE_IN_SECONDS;
        }

        return 0;
    }

    /**
     * Build the account and network bucket hashes for a stage.
     *
     * @param string $stage        Authentication stage.
     * @param string $subject_hash Pseudonymous account identifier.
     * @return array
     */
    private static function rate_bucket_hashes($stage, $subject_hash) {
        return array(
            self::hash_secret('rate', $stage . '|account|' . $subject_hash),
            self::hash_secret('rate', $stage . '|network|' . self::network_hash()),
        );
    }

    /**
     * Encrypt a TOTP secret with authenticated encryption.
     *
     * @param string $secret Base32 secret.
     * @return string|WP_Error Versioned JSON envelope.
     */
    private static function encrypt_totp_secret($secret) {
        $key = self::encryption_key();
        $aad = 'madex-portal-totp:v1';

        try {
            if (function_exists('sodium_crypto_secretbox')) {
                $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
                $ciphertext = sodium_crypto_secretbox($secret, $nonce, $key);

                return wp_json_encode(
                    array(
                        'v' => 1,
                        'a' => 'sodium-secretbox',
                        'n' => base64_encode($nonce),
                        'c' => base64_encode($ciphertext),
                    )
                );
            }

            if (
                function_exists('openssl_encrypt') &&
                in_array('aes-256-gcm', openssl_get_cipher_methods(), true)
            ) {
                $nonce = random_bytes(12);
                $tag = '';
                $ciphertext = openssl_encrypt(
                    $secret,
                    'aes-256-gcm',
                    $key,
                    OPENSSL_RAW_DATA,
                    $nonce,
                    $tag,
                    $aad,
                    16
                );

                if ($ciphertext === false || strlen($tag) !== 16) {
                    return self::error('madex_portal_encryption_failed', 500);
                }

                return wp_json_encode(
                    array(
                        'v' => 1,
                        'a' => 'aes-256-gcm',
                        'n' => base64_encode($nonce),
                        't' => base64_encode($tag),
                        'c' => base64_encode($ciphertext),
                    )
                );
            }
        } catch (Exception $exception) {
            return self::error('madex_portal_encryption_failed', 500);
        }

        // Never fall back to plaintext or unauthenticated encryption.
        return self::error('madex_portal_encryption_unavailable', 500);
    }

    /**
     * Decrypt and authenticate a versioned TOTP secret envelope.
     *
     * @param string $envelope Encrypted JSON envelope.
     * @return string|WP_Error
     */
    private static function decrypt_totp_secret($envelope) {
        $data = json_decode((string) $envelope, true);
        if (!is_array($data) || (int) ($data['v'] ?? 0) !== 1 || empty($data['a'])) {
            return self::error('madex_portal_decryption_failed', 500);
        }

        $nonce = isset($data['n']) ? base64_decode($data['n'], true) : false;
        $ciphertext = isset($data['c']) ? base64_decode($data['c'], true) : false;
        if ($nonce === false || $ciphertext === false) {
            return self::error('madex_portal_decryption_failed', 500);
        }

        $key = self::encryption_key();
        $plaintext = false;

        if ($data['a'] === 'sodium-secretbox' && function_exists('sodium_crypto_secretbox_open')) {
            if (strlen($nonce) !== SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
                return self::error('madex_portal_decryption_failed', 500);
            }
            $plaintext = sodium_crypto_secretbox_open($ciphertext, $nonce, $key);
        } elseif (
            $data['a'] === 'aes-256-gcm' &&
            function_exists('openssl_decrypt') &&
            isset($data['t'])
        ) {
            $tag = base64_decode($data['t'], true);
            if ($tag === false || strlen($nonce) !== 12 || strlen($tag) !== 16) {
                return self::error('madex_portal_decryption_failed', 500);
            }
            $plaintext = openssl_decrypt(
                $ciphertext,
                'aes-256-gcm',
                $key,
                OPENSSL_RAW_DATA,
                $nonce,
                $tag,
                'madex-portal-totp:v1'
            );
        }

        if (!is_string($plaintext) || is_wp_error(Madex_TOTP::base32_decode($plaintext))) {
            return self::error('madex_portal_decryption_failed', 500);
        }

        return $plaintext;
    }

    /**
     * Derive a 256-bit encryption key from WordPress salts.
     *
     * @return string Raw 32-byte key.
     */
    private static function encryption_key() {
        $input_key_material = wp_salt('auth') . '|' . wp_salt('secure_auth') . '|' . wp_salt('nonce');

        if (function_exists('hash_hkdf')) {
            return hash_hkdf('sha256', $input_key_material, 32, 'madex-portal-totp-v1', '');
        }

        return hash_hmac('sha256', 'madex-portal-totp-v1', $input_key_material, true);
    }

    /**
     * Ensure a per-user security record exists.
     *
     * @param int $user_id WordPress user ID.
     * @return void
     */
    private static function ensure_security_row($user_id) {
        global $wpdb;
        $now = time();

        $wpdb->query(
            $wpdb->prepare(
                'INSERT INTO ' . self::security_table() . ' (user_id, last_totp_step, force_reenroll, updated_at)
                 VALUES (%d, -1, 0, %d)
                 ON DUPLICATE KEY UPDATE user_id = VALUES(user_id)',
                (int) $user_id,
                $now
            )
        );
    }

    /**
     * Get a per-user security record.
     *
     * @param int $user_id WordPress user ID.
     * @return array|null
     */
    private static function get_security_row($user_id) {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . self::security_table() . ' WHERE user_id = %d LIMIT 1',
                (int) $user_id
            ),
            ARRAY_A
        );
    }

    /**
     * Remove an expired/abandoned pending secret.
     *
     * @param int $user_id WordPress user ID.
     * @return void
     */
    private static function clear_pending_enrollment($user_id) {
        global $wpdb;
        $wpdb->update(
            self::security_table(),
            array('pending_secret' => null, 'pending_expires_at' => null, 'updated_at' => time()),
            array('user_id' => (int) $user_id),
            array(null, null, '%d'),
            array('%d')
        );
    }

    /**
     * Revoke one session row.
     *
     * @param int $session_id Session ID.
     * @return void
     */
    private static function revoke_session_id($session_id) {
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . self::sessions_table() . '
                 SET revoked_at = %d
                 WHERE id = %d AND revoked_at IS NULL',
                time(),
                (int) $session_id
            )
        );
    }

    /**
     * Revoke the token currently present in the cookie, if any.
     *
     * @param bool $clear_cookie Whether to expire the browser cookie.
     * @return void
     */
    private static function revoke_current_cookie_session($clear_cookie) {
        $token = self::read_cookie_token();
        if ($token !== '') {
            global $wpdb;
            $wpdb->update(
                self::sessions_table(),
                array('revoked_at' => time()),
                array('token_hash' => self::hash_secret('session', $token)),
                array('%d'),
                array('%s')
            );
        }

        if ($clear_cookie) {
            self::clear_session_cookie();
        }
    }

    /**
     * Set an opaque, Secure, HttpOnly, SameSite=Strict session cookie.
     *
     * @param string $token      Raw random token.
     * @param int    $expires_at Absolute expiry.
     * @return bool
     */
    private static function set_session_cookie($token, $expires_at) {
        if (headers_sent() || !self::is_secure_request()) {
            return false;
        }

        $result = setcookie(
            self::COOKIE_NAME,
            $token,
            array(
                'expires' => (int) $expires_at,
                'path' => self::cookie_path(),
                'secure' => true,
                'httponly' => true,
                'samesite' => 'Strict',
            )
        );

        if ($result) {
            $_COOKIE[self::COOKIE_NAME] = $token;
        }

        return $result;
    }

    /**
     * Expire the portal session cookie with matching attributes.
     *
     * @return void
     */
    private static function clear_session_cookie() {
        if (!headers_sent()) {
            setcookie(
                self::COOKIE_NAME,
                '',
                array(
                    'expires' => time() - HOUR_IN_SECONDS,
                    'path' => self::cookie_path(),
                    'secure' => true,
                    'httponly' => true,
                    'samesite' => 'Strict',
                )
            );
        }

        unset($_COOKIE[self::COOKIE_NAME]);
    }

    /**
     * Read and strictly validate the opaque cookie token syntax.
     *
     * @return string Empty string when absent/invalid.
     */
    private static function read_cookie_token() {
        if (empty($_COOKIE[self::COOKIE_NAME])) {
            return '';
        }

        $token = (string) wp_unslash($_COOKIE[self::COOKIE_NAME]);
        return preg_match('/^[A-Za-z0-9_-]{43}$/D', $token) ? $token : '';
    }

    /**
     * Generate a URL-safe 256-bit random token.
     *
     * @return string|WP_Error
     */
    private static function random_token() {
        try {
            return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        } catch (Exception $exception) {
            return self::error('madex_portal_random_failed', 500);
        }
    }

    /**
     * Keyed hash for tokens and pseudonymous identifiers.
     *
     * @param string $purpose Domain-separation purpose.
     * @param string $value   Value to hash.
     * @return string Lowercase hex SHA-256 HMAC.
     */
    private static function hash_secret($purpose, $value) {
        $key = hash('sha256', wp_salt('logged_in') . '|madex-portal|' . $purpose, true);
        return hash_hmac('sha256', (string) $value, $key);
    }

    /**
     * Build a stable account subject hash without storing username/email.
     *
     * Existing username/email aliases resolve to the same user-ID subject.
     *
     * @param string $identifier Username or email address.
     * @return string
     */
    private static function subject_hash_for_identifier($identifier) {
        $identifier = trim((string) $identifier);
        $user = get_user_by('login', $identifier);
        if (!$user && is_email($identifier)) {
            $user = get_user_by('email', $identifier);
        }

        if ($user instanceof WP_User) {
            return self::subject_hash_for_user((int) $user->ID);
        }

        return self::hash_secret('subject', 'unknown|' . strtolower($identifier));
    }

    /**
     * Build a stable account subject hash for a known user ID.
     *
     * @param int $user_id WordPress user ID.
     * @return string
     */
    private static function subject_hash_for_user($user_id) {
        return self::hash_secret('subject', 'user|' . (int) $user_id);
    }

    /**
     * Hash REMOTE_ADDR only. Forwarded headers are intentionally ignored.
     *
     * Reverse-proxy deployments must configure the web server to set a trusted
     * REMOTE_ADDR before PHP; request-controlled forwarding headers are unsafe.
     *
     * @return string
     */
    private static function network_hash() {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            $ip = '0.0.0.0';
        }

        $packed = @inet_pton($ip);
        $normalized = $packed !== false ? base64_encode($packed) : $ip;
        return self::hash_secret('network', $normalized);
    }

    /**
     * Return a pseudonymous user-agent binding hash.
     *
     * @return string
     */
    private static function user_agent_hash() {
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
        return self::hash_secret('user-agent', substr($user_agent, 0, 512));
    }

    /**
     * Persist a minimal, secret-free authentication audit event.
     *
     * @param string $event_type Event name.
     * @param string $result     Result label.
     * @param int    $user_id    Optional WordPress user ID.
     * @param array  $context    Whitelisted minimal metadata.
     * @return void
     */
    private static function audit($event_type, $result, $user_id = 0, $context = array()) {
        global $wpdb;

        $event_type = substr(sanitize_key($event_type), 0, 64);
        $result = substr(sanitize_key($result), 0, 24);
        $safe = array();

        foreach (array('reason', 'next') as $key) {
            if (isset($context[$key])) {
                $safe[$key] = substr(sanitize_text_field((string) $context[$key]), 0, 120);
            }
        }
        foreach (array('retry_after', 'recovery_remaining') as $key) {
            if (isset($context[$key])) {
                $safe[$key] = max(0, (int) $context[$key]);
            }
        }

        $wpdb->insert(
            self::audit_table(),
            array(
                'event_type' => $event_type,
                'result' => $result,
                'user_id' => $user_id > 0 ? (int) $user_id : null,
                'object_type' => null,
                'object_id' => null,
                'ip_hash' => self::network_hash(),
                'ua_hash' => self::user_agent_hash(),
                'data' => empty($safe) ? null : wp_json_encode($safe),
                'created_at' => time(),
            ),
            array('%s', '%s', '%d', null, null, '%s', '%s', '%s', '%d')
        );
    }

    /**
     * Return recent audit events for the trusted WordPress admin screen.
     *
     * @param int $limit Maximum rows.
     * @return array
     */
    public static function get_recent_audit($limit = 50) {
        global $wpdb;
        $limit = max(1, min(200, (int) $limit));
        return (array) $wpdb->get_results(
            $wpdb->prepare(
                'SELECT event_type, result, user_id, data, created_at FROM ' . self::audit_table() . ' ORDER BY id DESC LIMIT %d',
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Count active (non-revoked, unexpired) portal sessions for a user.
     *
     * @param int $user_id WordPress user ID.
     * @return int
     */
    public static function count_active_sessions($user_id) {
        global $wpdb;
        $now = time();
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(*) FROM ' . self::sessions_table() . '
                 WHERE user_id = %d AND state = %s AND revoked_at IS NULL
                   AND idle_expires_at > %d AND absolute_expires_at > %d',
                (int) $user_id,
                self::STATE_ACTIVE,
                $now,
                $now
            )
        );
    }

    /**
     * Public read-only view of the explicit allowlist.
     *
     * @return array<int>
     */
    public static function get_allowed_user_ids() {
        return self::get_allowlist();
    }

    /**
     * Get normalized explicit user allowlist.
     *
     * @return array<int>
     */
    private static function get_allowlist() {
        $allowlist = get_option(self::ALLOWLIST_OPTION, array());
        if (!is_array($allowlist)) {
            return array();
        }

        return array_values(array_unique(array_filter(array_map('intval', $allowlist))));
    }

    /**
     * Normalize an internal rate-limit stage.
     *
     * @param string $stage Stage name.
     * @return string
     */
    private static function normalize_stage($stage) {
        return in_array($stage, array('password', 'totp', 'recovery'), true) ? $stage : 'password';
    }

    /**
     * A real password hash (same algorithm/cost as user hashes) used only to
     * equalise response timing for unknown accounts.
     *
     * @return string
     */
    private static function timing_hash() {
        $hash = get_option('madex_portal_timing_hash', '');
        if (!is_string($hash) || $hash === '') {
            $hash = wp_hash_password(wp_generate_password(32, true, true));
            update_option('madex_portal_timing_hash', $hash, false);
        }
        return $hash;
    }

    /**
     * Return the configured portal slug without slashes, e.g. "chatadm".
     *
     * @return string
     */
    public static function get_slug() {
        $configured = (string) get_option(self::PATH_OPTION, '/chatadm');
        $slug = sanitize_title(trim($configured, '/'));
        return $slug !== '' ? $slug : 'chatadm';
    }

    /**
     * Persist a new portal slug. Reserved WordPress paths are rejected.
     *
     * @param string $slug Requested slug.
     * @return string The stored slug.
     */
    public static function set_slug($slug) {
        $slug = sanitize_title((string) $slug);
        $reserved = array('wp-admin', 'wp-login', 'wp-login-php', 'wp-json', 'wp-content', 'wp-includes', 'feed', 'xmlrpc', 'admin', 'login');
        if ($slug === '' || in_array($slug, $reserved, true)) {
            $slug = 'chatadm';
        }
        update_option(self::PATH_OPTION, '/' . $slug, false);
        return $slug;
    }

    /**
     * Absolute URL path of the portal including a subdirectory install,
     * e.g. "/chatadm" or "/site/chatadm". No trailing slash.
     *
     * @return string
     */
    public static function base_path() {
        $home_path = (string) wp_parse_url(home_url('/'), PHP_URL_PATH);
        $home_path = '/' . trim($home_path, '/');
        return rtrim($home_path, '/') . '/' . self::get_slug();
    }

    /**
     * Build a portal URL for an internal route.
     *
     * @param string $route Route without leading slash.
     * @param array  $args  Optional query arguments.
     * @return string
     */
    public static function url($route = '', $args = array()) {
        $url = home_url('/' . self::get_slug() . '/' . ltrim((string) $route, '/'));
        return empty($args) ? $url : add_query_arg($args, $url);
    }

    /**
     * Configured idle timeout in seconds (15, 30 or 60 minutes).
     *
     * @return int
     */
    public static function idle_ttl() {
        $settings = get_option('madex_portal_settings', array());
        $ttl = isset($settings['idle_timeout']) ? (int) $settings['idle_timeout'] : self::ACTIVE_IDLE_TTL;
        return in_array($ttl, array(900, 1800, 3600), true) ? $ttl : self::ACTIVE_IDLE_TTL;
    }

    /**
     * Determine the cookie path from the configured portal path.
     *
     * @return string
     */
    private static function cookie_path() {
        return self::base_path();
    }

    /**
     * Require WordPress to recognize the request as HTTPS.
     *
     * @return bool
     */
    private static function is_secure_request() {
        return function_exists('is_ssl') && is_ssl();
    }

    /**
     * Create a generic public authentication error.
     *
     * @param string $code   Machine-readable code.
     * @param int    $status Suggested HTTP status.
     * @return WP_Error
     */
    private static function error($code, $status) {
        return new WP_Error(
            $code,
            __('Unable to complete sign-in. Please try again.', 'madex-chatbot'),
            array('status' => (int) $status)
        );
    }

    /**
     * Create a generic progressive-rate-limit error.
     *
     * @param int $retry_after Seconds until retry.
     * @return WP_Error
     */
    private static function rate_error($retry_after) {
        return new WP_Error(
            'madex_portal_rate_limited',
            __('Too many attempts. Please wait before trying again.', 'madex-chatbot'),
            array(
                'status' => 429,
                'retry_after' => max(1, (int) $retry_after),
            )
        );
    }

    /** @return string */
    private static function security_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_portal_security';
    }

    /** @return string */
    private static function sessions_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_portal_sessions';
    }

    /** @return string */
    private static function limits_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_portal_auth_limits';
    }

    /** @return string */
    private static function audit_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_portal_audit';
    }
}

