<?php
/**
 * Business and persistence services for packages and appointment requests.
 *
 * This class deliberately keeps public data transfer objects separate from
 * database rows so internal rules and notes cannot leak to the chat widget.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_Business_Service {

    const APPOINTMENT_CONSENT_VERSION = '1.0';

    /**
     * Install or upgrade business tables and the secure session columns.
     */
    public static function install_schema() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $sessions_table = $wpdb->prefix . 'madex_chat_sessions';

        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $sessions_table)) === $sessions_table) {
            $columns = array(
                'public_id'          => "char(36) DEFAULT NULL",
                'visitor_token_hash' => "char(64) NOT NULL DEFAULT ''",
                'visitor_id'         => "char(64) NOT NULL DEFAULT ''",
                'customer_type'      => "varchar(32) NOT NULL DEFAULT 'unknown'",
                'topic'              => "varchar(191) NOT NULL DEFAULT ''",
                'last_seen'          => 'datetime DEFAULT NULL',
                'closed_at'          => 'datetime DEFAULT NULL',
                'consent_at'         => 'datetime DEFAULT NULL',
            );

            foreach ($columns as $name => $definition) {
                self::maybe_add_column($sessions_table, $name, $definition);
            }

            $public_index = $wpdb->get_var(
                "SHOW INDEX FROM {$sessions_table} WHERE Key_name = 'public_id'"
            );
            if (empty($public_index)) {
                $wpdb->query("ALTER TABLE {$sessions_table} ADD UNIQUE KEY public_id (public_id)");
            }

            $last_seen_index = $wpdb->get_var(
                "SHOW INDEX FROM {$sessions_table} WHERE Key_name = 'last_seen'"
            );
            if (empty($last_seen_index)) {
                $wpdb->query("ALTER TABLE {$sessions_table} ADD KEY last_seen (last_seen)");
            }
        }

        $messages_table = $wpdb->prefix . 'madex_chat_messages';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $messages_table)) === $messages_table) {
            self::maybe_add_column($messages_table, 'is_fallback', 'tinyint(1) unsigned NOT NULL DEFAULT 0');
        }

        $appointments_table = self::appointments_table();
        $events_table = self::appointment_events_table();
        $packages_table = self::packages_table();

        $sql_appointments = "CREATE TABLE {$appointments_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            reference varchar(32) NOT NULL,
            idempotency_hash char(64) NOT NULL,
            session_public_id char(36) NOT NULL,
            request_type varchar(40) NOT NULL DEFAULT 'appointment',
            customer_name varchar(191) NOT NULL,
            company varchar(191) NOT NULL DEFAULT '',
            email varchar(254) NOT NULL,
            phone varchar(40) NOT NULL DEFAULT '',
            existing_client varchar(8) NOT NULL DEFAULT 'no',
            customer_status varchar(32) NOT NULL DEFAULT 'prospect',
            service varchar(191) NOT NULL DEFAULT '',
            package_id bigint(20) unsigned DEFAULT NULL,
            package_interest varchar(191) NOT NULL DEFAULT '',
            preferred_date date DEFAULT NULL,
            preferred_time varchar(100) NOT NULL DEFAULT '',
            message text,
            privacy_consent tinyint(1) unsigned NOT NULL DEFAULT 0,
            consent_version varchar(32) NOT NULL DEFAULT '',
            consent_at datetime DEFAULT NULL,
            status varchar(32) NOT NULL DEFAULT 'new',
            email_status varchar(32) NOT NULL DEFAULT 'pending',
            email_error text,
            email_attempts smallint(5) unsigned NOT NULL DEFAULT 0,
            email_last_attempt_at datetime DEFAULT NULL,
            internal_notes longtext,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY reference (reference),
            UNIQUE KEY idempotency_hash (idempotency_hash),
            KEY session_public_id (session_public_id),
            KEY status (status),
            KEY email_status (email_status),
            KEY preferred_date (preferred_date),
            KEY package_id (package_id),
            KEY created_at (created_at)
        ) {$charset_collate};";

        $sql_events = "CREATE TABLE {$events_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            appointment_id bigint(20) unsigned NOT NULL,
            event_type varchar(50) NOT NULL,
            actor_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            old_status varchar(32) NOT NULL DEFAULT '',
            new_status varchar(32) NOT NULL DEFAULT '',
            note text,
            data longtext,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY appointment_id (appointment_id),
            KEY event_type (event_type),
            KEY actor_user_id (actor_user_id),
            KEY created_at (created_at)
        ) {$charset_collate};";

        $sql_packages = "CREATE TABLE {$packages_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(191) NOT NULL,
            slug varchar(191) NOT NULL,
            short_description text,
            description longtext,
            features_json longtext,
            audience text,
            icon varchar(255) NOT NULL DEFAULT '',
            cta_label varchar(100) NOT NULL DEFAULT '',
            cta_action varchar(255) NOT NULL DEFAULT '',
            display_order int(11) NOT NULL DEFAULT 0,
            is_active tinyint(1) unsigned NOT NULL DEFAULT 1,
            conditions_json longtext,
            internal_notes longtext,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY is_active (is_active),
            KEY display_order (display_order)
        ) {$charset_collate};";

        dbDelta($sql_appointments);
        dbDelta($sql_events);
        dbDelta($sql_packages);
    }

    private static function maybe_add_column($table, $column, $definition) {
        global $wpdb;

        $allowed_columns = array(
            'public_id', 'visitor_token_hash', 'visitor_id', 'customer_type',
            'topic', 'last_seen', 'closed_at', 'consent_at', 'is_fallback',
        );
        if (!in_array($column, $allowed_columns, true)) {
            return false;
        }

        $exists = $wpdb->get_var(
            $wpdb->prepare("SHOW COLUMNS FROM {$table} LIKE %s", $column)
        );
        if (empty($exists)) {
            return false !== $wpdb->query("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
        }

        return true;
    }

    private static function appointments_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_appointments';
    }

    private static function appointment_events_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_appointment_events';
    }

    private static function packages_table() {
        global $wpdb;
        return $wpdb->prefix . 'madex_packages';
    }

    /**
     * Return active packages that match the supplied public profile.
     */
    public static function get_public_packages($profile = array()) {
        global $wpdb;

        $profile = self::sanitize_profile($profile);
        $rows = $wpdb->get_results(
            'SELECT * FROM ' . self::packages_table() . ' WHERE is_active = 1 ORDER BY display_order ASC, name ASC',
            ARRAY_A
        );

        $packages = array();
        foreach ((array) $rows as $row) {
            $conditions = self::decode_json_array($row['conditions_json']);
            if (!self::conditions_match($conditions, $profile)) {
                continue;
            }
            $packages[] = self::public_package_dto($row);
        }

        return $packages;
    }

    /**
     * Paginated package list for trusted administration surfaces.
     */
    public static function list_packages($args = array()) {
        global $wpdb;

        $defaults = array(
            'page' => 1,
            'per_page' => 50,
            'active' => null,
            'search' => '',
        );
        $args = wp_parse_args($args, $defaults);
        $page = max(1, absint($args['page']));
        $per_page = max(1, min(100, absint($args['per_page'])));
        $offset = ($page - 1) * $per_page;
        $where = array('1=1');
        $values = array();

        if (null !== $args['active'] && '' !== $args['active']) {
            $where[] = 'is_active = %d';
            $values[] = empty($args['active']) ? 0 : 1;
        }
        if (!empty($args['search'])) {
            $where[] = '(name LIKE %s OR short_description LIKE %s)';
            $needle = '%' . $wpdb->esc_like(sanitize_text_field($args['search'])) . '%';
            $values[] = $needle;
            $values[] = $needle;
        }

        $where_sql = implode(' AND ', $where);
        $table = self::packages_table();
        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
        $items_sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY display_order ASC, name ASC LIMIT %d OFFSET %d";

        $total = empty($values)
            ? (int) $wpdb->get_var($count_sql)
            : (int) $wpdb->get_var($wpdb->prepare($count_sql, $values));

        $item_values = array_merge($values, array($per_page, $offset));
        $rows = $wpdb->get_results($wpdb->prepare($items_sql, $item_values), ARRAY_A);
        $items = array();
        foreach ((array) $rows as $row) {
            $items[] = self::normalize_package_row($row);
        }

        return array(
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $per_page,
        );
    }

    public static function get_package($id) {
        global $wpdb;

        $id = absint($id);
        if (!$id) {
            return new WP_Error('invalid_package', __('Invalid package.', 'madex-chatbot'));
        }

        $row = $wpdb->get_row(
            $wpdb->prepare('SELECT * FROM ' . self::packages_table() . ' WHERE id = %d', $id),
            ARRAY_A
        );
        if (!$row) {
            return new WP_Error('package_not_found', __('Package not found.', 'madex-chatbot'));
        }

        return self::normalize_package_row($row);
    }

    /**
     * Insert or update a package. Internal fields are never returned publicly.
     */
    public static function save_package($data, $id = 0) {
        global $wpdb;

        if (!is_array($data)) {
            return new WP_Error('invalid_package', __('Invalid package data.', 'madex-chatbot'));
        }

        $name = self::clean_text(isset($data['name']) ? $data['name'] : '', 191);
        if ('' === $name) {
            return new WP_Error('package_name_required', __('Package name is required.', 'madex-chatbot'));
        }

        $slug_source = !empty($data['slug']) ? $data['slug'] : $name;
        $slug = sanitize_title($slug_source);
        if ('' === $slug) {
            return new WP_Error('package_slug_required', __('A valid package slug is required.', 'madex-chatbot'));
        }

        $features = self::sanitize_string_list(isset($data['features']) ? $data['features'] : array(), 100, 500);
        $conditions = isset($data['conditions']) && is_array($data['conditions']) ? $data['conditions'] : array();
        $conditions = self::sanitize_conditions($conditions);
        if (is_wp_error($conditions)) {
            return $conditions;
        }

        $record = array(
            'name' => $name,
            'slug' => $slug,
            'short_description' => self::clean_textarea(isset($data['short_description']) ? $data['short_description'] : '', 2000),
            'description' => wp_kses_post(isset($data['description']) ? $data['description'] : ''),
            'features_json' => wp_json_encode($features),
            'audience' => self::clean_textarea(isset($data['audience']) ? $data['audience'] : '', 2000),
            'icon' => self::clean_url_or_icon(isset($data['icon']) ? $data['icon'] : ''),
            'cta_label' => self::clean_text(isset($data['cta_label']) ? $data['cta_label'] : '', 100),
            'cta_action' => self::clean_url_or_action(isset($data['cta_action']) ? $data['cta_action'] : ''),
            'display_order' => isset($data['display_order']) ? intval($data['display_order']) : 0,
            'is_active' => isset($data['is_active']) ? (empty($data['is_active']) ? 0 : 1) : 1,
            'conditions_json' => wp_json_encode($conditions),
            'internal_notes' => self::clean_textarea(isset($data['internal_notes']) ? $data['internal_notes'] : '', 20000),
            'updated_at' => current_time('mysql'),
        );

        $id = absint($id);
        $table = self::packages_table();
        $duplicate_id = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM {$table} WHERE slug = %s AND id != %d", $slug, $id)
        );
        if ($duplicate_id) {
            return new WP_Error('duplicate_package_slug', __('A package with this slug already exists.', 'madex-chatbot'));
        }

        if ($id) {
            $existing = self::get_package($id);
            if (is_wp_error($existing)) {
                return $existing;
            }
            $result = $wpdb->update($table, $record, array('id' => $id));
        } else {
            $record['created_at'] = current_time('mysql');
            $result = $wpdb->insert($table, $record);
            $id = (int) $wpdb->insert_id;
        }

        if (false === $result || !$id) {
            return new WP_Error('package_save_failed', __('The package could not be saved.', 'madex-chatbot'));
        }

        return self::get_package($id);
    }

    public static function delete_package($id) {
        global $wpdb;

        $id = absint($id);
        if (!$id) {
            return new WP_Error('invalid_package', __('Invalid package.', 'madex-chatbot'));
        }

        $deleted = $wpdb->delete(self::packages_table(), array('id' => $id), array('%d'));
        if (false === $deleted) {
            return new WP_Error('package_delete_failed', __('The package could not be deleted.', 'madex-chatbot'));
        }

        return (bool) $deleted;
    }

    /**
     * Validate, store, then notify. A repeated idempotency key returns the
     * original record without creating or emailing a duplicate request.
     */
    public static function create_appointment($data) {
        global $wpdb;

        $validated = self::validate_appointment($data);
        if (is_wp_error($validated)) {
            return $validated;
        }

        $table = self::appointments_table();
        $idempotency_hash = hash('sha256', $validated['session_public_id'] . '|' . $validated['idempotency_key']);
        $existing = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE idempotency_hash = %s", $idempotency_hash),
            ARRAY_A
        );
        if ($existing) {
            $existing = self::normalize_appointment_row($existing);
            $existing['idempotent_replay'] = true;
            return $existing;
        }

        $package_id = null;
        $package_interest = $validated['package_interest'];
        if (ctype_digit((string) $package_interest)) {
            $package = self::get_package((int) $package_interest);
            if (!is_wp_error($package)) {
                $package_id = (int) $package['id'];
                $package_interest = $package['name'];
            }
        }

        $now = current_time('mysql');
        $record = array(
            'reference' => self::generate_appointment_reference(),
            'idempotency_hash' => $idempotency_hash,
            'session_public_id' => $validated['session_public_id'],
            'request_type' => $validated['request_type'],
            'customer_name' => $validated['customer_name'],
            'company' => $validated['company'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'existing_client' => $validated['existing_client'],
            'customer_status' => 'yes' === $validated['existing_client'] ? 'client' : 'prospect',
            'service' => $validated['service'],
            'package_id' => $package_id,
            'package_interest' => $package_interest,
            'preferred_date' => $validated['preferred_date'],
            'preferred_time' => $validated['preferred_time'],
            'message' => $validated['message'],
            'privacy_consent' => 1,
            'consent_version' => $validated['consent_version'],
            'consent_at' => $now,
            'status' => 'new',
            'email_status' => 'pending',
            'email_error' => '',
            'email_attempts' => 0,
            'internal_notes' => '',
            'created_at' => $now,
            'updated_at' => $now,
        );

        $inserted = $wpdb->insert($table, $record);
        if (false === $inserted) {
            // A concurrent duplicate request may have won the unique-key race.
            $existing = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM {$table} WHERE idempotency_hash = %s", $idempotency_hash),
                ARRAY_A
            );
            if ($existing) {
                $existing = self::normalize_appointment_row($existing);
                $existing['idempotent_replay'] = true;
                return $existing;
            }
            return new WP_Error('appointment_save_failed', __('Die Anfrage konnte nicht gespeichert werden. Bitte versuchen Sie es erneut.', 'madex-chatbot'));
        }

        $appointment_id = (int) $wpdb->insert_id;
        self::add_appointment_event($appointment_id, 'created', 0, '', 'new', '', array(
            'request_type' => $validated['request_type'],
        ));

        // Storage succeeds independently from notification delivery.
        self::send_appointment_notification($appointment_id, 0);

        return self::get_appointment($appointment_id);
    }

    public static function list_appointments($args = array()) {
        global $wpdb;

        $defaults = array(
            'page' => 1,
            'per_page' => 25,
            'status' => '',
            'email_status' => '',
            'search' => '',
            'date_from' => '',
            'date_to' => '',
            'service' => '',
            'customer_status' => '',
            'orderby' => 'created_at',
            'order' => 'DESC',
        );
        $args = wp_parse_args($args, $defaults);
        $page = max(1, absint($args['page']));
        $per_page = max(1, min(100, absint($args['per_page'])));
        $offset = ($page - 1) * $per_page;
        $where = array('1=1');
        $values = array();

        $status = sanitize_key($args['status']);
        if ($status && in_array($status, self::appointment_statuses(), true)) {
            $where[] = 'status = %s';
            $values[] = $status;
        }
        $email_status = sanitize_key($args['email_status']);
        if ($email_status && in_array($email_status, array('pending', 'sent', 'failed'), true)) {
            $where[] = 'email_status = %s';
            $values[] = $email_status;
        }
        if (!empty($args['service'])) {
            $where[] = 'service = %s';
            $values[] = self::clean_text($args['service'], 191);
        }
        if (!empty($args['customer_status'])) {
            $where[] = 'customer_status = %s';
            $values[] = sanitize_key($args['customer_status']);
        }
        if (self::is_valid_date($args['date_from'])) {
            $where[] = 'created_at >= %s';
            $values[] = $args['date_from'] . ' 00:00:00';
        }
        if (self::is_valid_date($args['date_to'])) {
            $where[] = 'created_at <= %s';
            $values[] = $args['date_to'] . ' 23:59:59';
        }
        if (!empty($args['search'])) {
            $needle = '%' . $wpdb->esc_like(self::clean_text($args['search'], 191)) . '%';
            $where[] = '(reference LIKE %s OR customer_name LIKE %s OR company LIKE %s OR email LIKE %s OR service LIKE %s)';
            for ($i = 0; $i < 5; $i++) {
                $values[] = $needle;
            }
        }

        $allowed_orderby = array('created_at', 'updated_at', 'preferred_date', 'status', 'customer_name');
        $orderby = in_array($args['orderby'], $allowed_orderby, true) ? $args['orderby'] : 'created_at';
        $order = 'ASC' === strtoupper($args['order']) ? 'ASC' : 'DESC';
        $where_sql = implode(' AND ', $where);
        $table = self::appointments_table();

        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
        $items_sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY {$orderby} {$order}, id {$order} LIMIT %d OFFSET %d";
        $total = empty($values)
            ? (int) $wpdb->get_var($count_sql)
            : (int) $wpdb->get_var($wpdb->prepare($count_sql, $values));
        $rows = $wpdb->get_results(
            $wpdb->prepare($items_sql, array_merge($values, array($per_page, $offset))),
            ARRAY_A
        );

        $items = array();
        foreach ((array) $rows as $row) {
            $items[] = self::normalize_appointment_row($row);
        }

        return array(
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $per_page,
        );
    }

    public static function get_appointment($id_or_reference) {
        global $wpdb;

        $table = self::appointments_table();
        if (is_numeric($id_or_reference)) {
            $row = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", absint($id_or_reference)),
                ARRAY_A
            );
        } else {
            $reference = self::clean_text($id_or_reference, 32);
            $row = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM {$table} WHERE reference = %s", $reference),
                ARRAY_A
            );
        }

        if (!$row) {
            return new WP_Error('appointment_not_found', __('Appointment request not found.', 'madex-chatbot'));
        }

        $appointment = self::normalize_appointment_row($row);
        $appointment['events'] = self::get_appointment_events((int) $row['id']);
        return $appointment;
    }

    /**
     * Update allowlisted appointment fields and create an audit event.
     */
    public static function update_appointment($id, $changes, $actor_id = 0) {
        global $wpdb;

        $id = absint($id);
        $current = self::get_appointment($id);
        if (is_wp_error($current)) {
            return $current;
        }
        if (!is_array($changes)) {
            return new WP_Error('invalid_changes', __('Invalid appointment changes.', 'madex-chatbot'));
        }

        $update = array();
        if (array_key_exists('status', $changes)) {
            $status = sanitize_key($changes['status']);
            if (!in_array($status, self::appointment_statuses(), true)) {
                return new WP_Error('invalid_status', __('Invalid appointment status.', 'madex-chatbot'));
            }
            $update['status'] = $status;
        }
        if (array_key_exists('internal_notes', $changes)) {
            $update['internal_notes'] = self::clean_textarea($changes['internal_notes'], 50000);
        }
        if (array_key_exists('preferred_date', $changes)) {
            if (!self::is_valid_date($changes['preferred_date'])) {
                return new WP_Error('invalid_date', __('Invalid preferred date.', 'madex-chatbot'));
            }
            $update['preferred_date'] = $changes['preferred_date'];
        }
        if (array_key_exists('preferred_time', $changes)) {
            $update['preferred_time'] = self::clean_text($changes['preferred_time'], 100);
        }
        if (array_key_exists('service', $changes)) {
            $update['service'] = self::clean_text($changes['service'], 191);
        }

        if (empty($update)) {
            return $current;
        }

        $update['updated_at'] = current_time('mysql');
        $result = $wpdb->update(self::appointments_table(), $update, array('id' => $id));
        if (false === $result) {
            return new WP_Error('appointment_update_failed', __('The appointment request could not be updated.', 'madex-chatbot'));
        }

        $old_status = $current['status'];
        $new_status = isset($update['status']) ? $update['status'] : $old_status;
        $event_type = $old_status !== $new_status ? 'status_changed' : 'updated';
        $note = isset($changes['event_note']) ? self::clean_textarea($changes['event_note'], 5000) : '';
        self::add_appointment_event($id, $event_type, absint($actor_id), $old_status, $new_status, $note, array(
            'changed_fields' => array_keys($update),
        ));

        return self::get_appointment($id);
    }

    public static function retry_appointment_email($id, $actor_id = 0) {
        $appointment = self::get_appointment($id);
        if (is_wp_error($appointment)) {
            return $appointment;
        }

        self::add_appointment_event((int) $appointment['id'], 'email_retry_requested', absint($actor_id), '', '', '');
        $result = self::send_appointment_notification((int) $appointment['id'], absint($actor_id));
        if (is_wp_error($result)) {
            return $result;
        }

        return self::get_appointment((int) $appointment['id']);
    }

    /**
     * Dashboard summary. "Active" means a heartbeat in the last five minutes.
     */
    public static function get_dashboard_stats($days = 7) {
        global $wpdb;

        $days = max(1, min(365, absint($days)));
        $appointments = self::appointments_table();
        $sessions = $wpdb->prefix . 'madex_chat_sessions';
        $today = current_time('Y-m-d');
        // All chat timestamps are stored in site-local time (current_time('mysql')).
        $since = gmdate('Y-m-d H:i:s', current_time('timestamp') - ($days * DAY_IN_SECONDS));
        $active_since = gmdate('Y-m-d H:i:s', current_time('timestamp') - (5 * MINUTE_IN_SECONDS));
        $stale_before = gmdate('Y-m-d H:i:s', current_time('timestamp') - (2 * DAY_IN_SECONDS));
        $messages = $wpdb->prefix . 'madex_chat_messages';

        return array(
            'conversations_total' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$sessions} WHERE public_id IS NOT NULL"),
            'conversations_range' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$sessions} WHERE public_id IS NOT NULL AND created_at >= %s", $since)),
            'unresolved' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT session_id) FROM {$messages} WHERE is_fallback = 1 AND created_at >= %s", $since)),
            'appointments_range' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$appointments} WHERE created_at >= %s", $since)),
            'stale_new' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$appointments} WHERE status = 'new' AND created_at < %s", $stale_before)),
            'conversations_today' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$sessions} WHERE public_id IS NOT NULL AND created_at >= %s", $today . ' 00:00:00')),
            'active_chats' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$sessions} WHERE status = 'active' AND last_seen >= %s", $active_since)),
            'new_appointments' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$appointments} WHERE status = 'new'"),
            'confirmed_upcoming' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$appointments} WHERE status = 'confirmed' AND preferred_date >= %s", $today)),
            'email_failures' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$appointments} WHERE email_status = 'failed'"),
            'prospects' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$sessions} WHERE customer_type = 'prospect' AND created_at >= %s", $since)),
            'existing_clients' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$sessions} WHERE customer_type = 'client' AND created_at >= %s", $since)),
            'range_days' => $days,
        );
    }

    /**
     * Daily series plus operational distributions for report screens.
     */
    public static function get_report_series($days = 30) {
        global $wpdb;

        $days = max(1, min(366, absint($days)));
        $appointments = self::appointments_table();
        $sessions = $wpdb->prefix . 'madex_chat_sessions';
        $start_timestamp = current_time('timestamp') - (($days - 1) * DAY_IN_SECONDS);
        $start_date = wp_date('Y-m-d', $start_timestamp, wp_timezone());

        $conversation_rows = $wpdb->get_results(
            $wpdb->prepare("SELECT DATE(created_at) report_date, COUNT(*) total FROM {$sessions} WHERE public_id IS NOT NULL AND created_at >= %s GROUP BY DATE(created_at)", $start_date . ' 00:00:00'),
            ARRAY_A
        );
        $appointment_rows = $wpdb->get_results(
            $wpdb->prepare("SELECT DATE(created_at) report_date, COUNT(*) total FROM {$appointments} WHERE created_at >= %s GROUP BY DATE(created_at)", $start_date . ' 00:00:00'),
            ARRAY_A
        );

        $conversation_map = self::rows_to_count_map($conversation_rows, 'report_date');
        $appointment_map = self::rows_to_count_map($appointment_rows, 'report_date');
        $series = array();
        for ($i = 0; $i < $days; $i++) {
            $date = wp_date('Y-m-d', $start_timestamp + ($i * DAY_IN_SECONDS), wp_timezone());
            $series[] = array(
                'date' => $date,
                'conversations' => isset($conversation_map[$date]) ? $conversation_map[$date] : 0,
                'appointments' => isset($appointment_map[$date]) ? $appointment_map[$date] : 0,
            );
        }

        return array(
            'series' => $series,
            'appointment_statuses' => self::grouped_counts($appointments, 'status', $start_date),
            'services' => self::grouped_counts($appointments, 'service', $start_date, 20),
            'customer_statuses' => self::grouped_counts($appointments, 'customer_status', $start_date),
            'topics' => self::grouped_counts($sessions, 'topic', $start_date, 10),
            'session_types' => self::grouped_counts($sessions, 'customer_type', $start_date),
            'packages' => self::grouped_counts($appointments, 'package_interest', $start_date, 10),
            'range_days' => $days,
        );
    }

    public static function export_appointments_csv_rows($args = array()) {
        $args['page'] = 1;
        $args['per_page'] = 100;
        $rows = array(array(
            'Reference', 'Status', 'Created', 'Name', 'Company', 'Email', 'Phone',
            'Customer status', 'Service', 'Package', 'Preferred date',
            'Preferred time', 'Email status', 'Message',
        ));

        $page = 1;
        do {
            $args['page'] = $page;
            $result = self::list_appointments($args);
            foreach ($result['items'] as $item) {
                $rows[] = array(
                    self::csv_cell($item['reference']),
                    self::csv_cell($item['status']),
                    self::csv_cell($item['created_at']),
                    self::csv_cell($item['customer_name']),
                    self::csv_cell($item['company']),
                    self::csv_cell($item['email']),
                    self::csv_cell($item['phone']),
                    self::csv_cell($item['customer_status']),
                    self::csv_cell($item['service']),
                    self::csv_cell($item['package_interest']),
                    self::csv_cell($item['preferred_date']),
                    self::csv_cell($item['preferred_time']),
                    self::csv_cell($item['email_status']),
                    self::csv_cell($item['message']),
                );
            }
            $page++;
        } while (($page - 1) * $result['per_page'] < $result['total']);

        return $rows;
    }

    /**
     * Service keys shared by the widget, rule builder and dashboards.
     */
    public static function service_options() {
        return array(
            'website' => __('Neue Website / Webdesign', 'madex-chatbot'),
            'wartung' => __('Website-Betreuung & Hosting', 'madex-chatbot'),
            'seo' => __('SEO – besser gefunden werden', 'madex-chatbot'),
            'google-ads' => __('Google Ads', 'madex-chatbot'),
            'social-media' => __('Social Media Marketing', 'madex-chatbot'),
            'foto-video' => __('Fotos & Werbevideos', 'madex-chatbot'),
            'grafik' => __('Grafikdesign & Logo', 'madex-chatbot'),
            'analyse' => __('Kostenlose Website-Analyse', 'madex-chatbot'),
            'other' => __('Anderes Anliegen', 'madex-chatbot'),
        );
    }

    /**
     * Labels for service keys used before 1.4.0, so older requests and
     * reports still read well.
     */
    private static function legacy_service_labels() {
        return array(
            'managed-it' => __('Managed IT & Support', 'madex-chatbot'),
            'cloud-backup' => __('Cloud & Backup', 'madex-chatbot'),
            'security' => __('IT-Security', 'madex-chatbot'),
            'microsoft-365' => __('Microsoft 365', 'madex-chatbot'),
        );
    }

    public static function service_label($key) {
        $options = self::service_options() + self::legacy_service_labels();
        $key = (string) $key;
        if (isset($options[$key])) {
            return $options[$key];
        }
        return '' === $key ? '–' : $key;
    }

    /**
     * Words that show a package covers a visitor goal. Matched against the
     * package's own name, summary, audience and features.
     */
    private static function goal_keywords() {
        return array(
            'website' => array('website', 'webseite', 'webdesign', 'seiten'),
            'wartung' => array('wartung', 'hosting', 'updates', 'backup', 'ssl', 'betreuung'),
            'seo' => array('seo', 'suchmaschine'),
            'google-ads' => array('google ads', 'google-ads', 'adwords'),
            'social-media' => array('social media', 'social-media', 'kanalbetreuung', 'instagram', 'facebook'),
            'foto-video' => array('foto', 'video', 'werbeclip', 'clip'),
            'grafik' => array('design', 'grafik', 'logo'),
            'analyse' => array('analyse', 'zielgruppe', 'strategie'),
        );
    }

    /**
     * Rank the packages that pass their admin rules by how well they cover
     * the visitor's goals, and say why. Packages keep their admin order when
     * the visitor gave no goals.
     *
     * @param array $profile existing_client, goals[], has_website, company_size …
     * @return array Public package DTOs with a "match" summary, best first.
     */
    public static function recommend_packages($profile = array()) {
        $packages = self::get_public_packages($profile);
        $goals = isset($profile['goals']) ? array_values(array_intersect((array) $profile['goals'], array_keys(self::goal_keywords()))) : array();
        if (empty($packages)) {
            return array();
        }

        $keywords = self::goal_keywords();
        $labels = self::service_options();
        $size = isset($profile['company_size']) ? absint($profile['company_size']) : 0;
        $marketing = array_intersect($goals, array('social-media', 'google-ads', 'foto-video', 'grafik', 'seo'));
        $max_features = 1;
        foreach ($packages as $package) {
            $max_features = max($max_features, count((array) $package['features']));
        }

        foreach ($packages as $position => &$package) {
            $title = self::lower($package['name']);
            $haystack = self::lower(implode(' ', array_merge(
                array($package['name'], $package['short_description'], $package['audience']),
                array_map('strval', (array) $package['features'])
            )));
            $matched = array();
            $missing = array();
            $named = 0;
            foreach ($goals as $goal) {
                $hit = false;
                foreach ($keywords[$goal] as $word) {
                    if (strpos($title, $word) !== false) {
                        // A package named after the goal is the specialist for it.
                        $named++;
                    }
                    if (strpos($haystack, $word) !== false) {
                        $hit = true;
                        break;
                    }
                }
                if ($hit) {
                    $matched[] = $goal;
                } else {
                    $missing[] = $goal;
                }
            }

            // Coverage decides; scope breaks ties: bigger packages for marketing
            // goals or larger teams, leaner ones for a plain website.
            $breadth = count((array) $package['features']) / $max_features;
            $score = count($matched) * 10 + min($named, 1) * 4;
            if (!empty($goals)) {
                $score += (count($marketing) >= 2 || $size >= 11) ? $breadth * 3 : -$breadth * 3;
            }
            $score -= $position * 0.01;

            $package['match'] = array(
                'score' => round($score, 2),
                'matched' => array_map(function ($goal) use ($labels) { return isset($labels[$goal]) ? $labels[$goal] : $goal; }, $matched),
                'missing' => array_map(function ($goal) use ($labels) { return isset($labels[$goal]) ? $labels[$goal] : $goal; }, $missing),
            );
        }
        unset($package);

        if (!empty($goals)) {
            usort($packages, function ($a, $b) {
                return $b['match']['score'] <=> $a['match']['score'];
            });
        }

        return $packages;
    }

    private static function lower($text) {
        return function_exists('mb_strtolower') ? mb_strtolower((string) $text, 'UTF-8') : strtolower((string) $text);
    }

    /**
     * Madex's published packages (madex-it.ch), used to fill an empty
     * package table so recommendations work right after installation.
     */
    public static function seed_default_packages() {
        global $wpdb;

        $table = self::packages_table();
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) {
            return;
        }
        if ((int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}") > 0) {
            return;
        }

        $defaults = array(
            array(
                'name' => 'Website-Wartung',
                'short_description' => 'Ihre Website in sicheren Händen: Hosting, Updates, Backups und Sicherheit aus einer Hand.',
                'audience' => 'Unternehmen, die eine bestehende oder neue Website ohne eigenen Aufwand betreuen lassen möchten.',
                'features' => array('Domain & Hosting', 'Website bis 8 Seiten', 'Kontaktformular', '1 Std. Updates pro Monat', 'SEO Basic', 'Responsive für Handy & Tablet', '1 E-Mail-Account', 'Backups, Security-Plugins & SSL', 'Google Analytics', 'Mehrsprachig (DE/EN/IT/FR)'),
                'display_order' => 10,
            ),
            array(
                'name' => 'Basic',
                'short_description' => 'Website und Social-Media-Auftritt für KMU, die online sichtbar werden möchten.',
                'audience' => 'KMU, die eine professionelle Website und einen regelmässigen Social-Media-Auftritt aufbauen möchten.',
                'features' => array('Website bis 10 Seiten inkl. Domain & Hosting', '4 Social-Media-Designs pro Monat', '1 Werbeclip pro Monat', 'Social-Media-Kanalbetreuung', 'Fotos vor Ort oder Stock-Fotos', 'Individuelle Designs & Texte', 'Zielgruppendefinition', 'Kontaktformular & SEO Basic', 'Updates, Backups, Security & SSL', 'Google Analytics'),
                'display_order' => 20,
            ),
            array(
                'name' => 'Premium',
                'short_description' => 'Das Komplettpaket für mehr Kunden: Website, Social Media, Werbevideos und Google Ads.',
                'audience' => 'Unternehmen, die mit Website, Social Media und Google Ads aktiv neue Kunden gewinnen möchten.',
                'features' => array('Website bis 15 Seiten inkl. Domain & Hosting', '6 Social-Media-Designs pro Monat', '2 Werbeclips pro Monat', 'Social-Media-Management', 'Professionelle Fotos', 'Google Ads', 'SEO Premium', 'Produkt- und Leistungstexte', '2 Std. Updates pro Monat', '2 E-Mail-Accounts', 'Backups, Security & SSL', 'Google Analytics & Ads, mehrsprachig'),
                'display_order' => 30,
            ),
        );

        foreach ($defaults as $package) {
            $package['cta_label'] = 'Beratung anfragen';
            $package['is_active'] = 1;
            self::save_package($package);
        }
    }

    public static function status_options() {
        return array(
            'new' => __('Neu', 'madex-chatbot'),
            'contacted' => __('Kontaktiert', 'madex-chatbot'),
            'confirmed' => __('Bestätigt', 'madex-chatbot'),
            'completed' => __('Erledigt', 'madex-chatbot'),
            'cancelled' => __('Storniert', 'madex-chatbot'),
        );
    }

    public static function time_label($key) {
        $labels = array(
            'morning' => __('Vormittag', 'madex-chatbot'),
            'midday' => __('Mittag', 'madex-chatbot'),
            'afternoon' => __('Nachmittag', 'madex-chatbot'),
            'flexible' => __('Flexibel', 'madex-chatbot'),
        );
        return isset($labels[$key]) ? $labels[$key] : (string) $key;
    }

    /**
     * Short pseudonymous visitor number for dashboards (no IP or location).
     */
    public static function visitor_label($public_id) {
        $hex = substr(preg_replace('/[^0-9a-f]/', '', strtolower((string) $public_id)), 0, 6);
        $number = '' === $hex ? 0 : hexdec($hex);
        return '#' . str_pad((string) ($number % 10000), 4, '0', STR_PAD_LEFT);
    }

    /**
     * Paginated, privacy-conscious conversation list for the boss portal.
     * Contact details are only exposed in the detail view.
     */
    public static function list_conversations($args = array()) {
        global $wpdb;

        $args = wp_parse_args($args, array(
            'page' => 1,
            'per_page' => 20,
            'state' => '',
            'customer_type' => '',
            'search' => '',
            'unresolved' => false,
        ));
        $page = max(1, absint($args['page']));
        $per_page = max(1, min(100, absint($args['per_page'])));
        $sessions = $wpdb->prefix . 'madex_chat_sessions';
        $messages = $wpdb->prefix . 'madex_chat_messages';
        $active_since = self::active_since();

        $where = array('s.public_id IS NOT NULL');
        $values = array();
        if ('live' === $args['state']) {
            $where[] = "s.status = 'active' AND s.last_seen >= %s";
            $values[] = $active_since;
        } elseif ('closed' === $args['state']) {
            $where[] = "(s.status <> 'active' OR s.last_seen IS NULL OR s.last_seen < %s)";
            $values[] = $active_since;
        }
        if (in_array($args['customer_type'], array('client', 'prospect'), true)) {
            $where[] = 's.customer_type = %s';
            $values[] = $args['customer_type'];
        }
        if (!empty($args['unresolved'])) {
            $where[] = "s.id IN (SELECT session_id FROM {$messages} WHERE is_fallback = 1)";
        }
        if ('' !== (string) $args['search']) {
            $needle = '%' . $wpdb->esc_like(self::clean_text($args['search'], 100)) . '%';
            $where[] = "(s.topic LIKE %s OR s.id IN (SELECT session_id FROM {$messages} WHERE content LIKE %s))";
            $values[] = $needle;
            $values[] = $needle;
        }
        $where_sql = implode(' AND ', $where);

        $count_sql = "SELECT COUNT(*) FROM {$sessions} s WHERE {$where_sql}";
        $total = empty($values) ? (int) $wpdb->get_var($count_sql) : (int) $wpdb->get_var($wpdb->prepare($count_sql, $values));

        $items_sql = "SELECT s.id, s.public_id, s.status, s.customer_type, s.topic, s.created_at, s.last_seen,
                (SELECT COUNT(*) FROM {$messages} m WHERE m.session_id = s.id AND m.sender_type = 'user') AS user_messages,
                (SELECT COUNT(*) FROM {$messages} m2 WHERE m2.session_id = s.id AND m2.is_fallback = 1) AS fallbacks,
                (SELECT m3.content FROM {$messages} m3 WHERE m3.session_id = s.id AND m3.sender_type = 'user' ORDER BY m3.id DESC LIMIT 1) AS last_user_message
            FROM {$sessions} s WHERE {$where_sql}
            ORDER BY COALESCE(s.last_seen, s.created_at) DESC, s.id DESC LIMIT %d OFFSET %d";
        $rows = $wpdb->get_results(
            $wpdb->prepare($items_sql, array_merge($values, array($per_page, ($page - 1) * $per_page))),
            ARRAY_A
        );

        $items = array();
        foreach ((array) $rows as $row) {
            $items[] = self::conversation_dto($row, $active_since);
        }

        return array('items' => $items, 'total' => $total, 'page' => $page, 'per_page' => $per_page);
    }

    /**
     * One conversation with its transcript and any linked appointment.
     */
    public static function get_conversation($public_id) {
        global $wpdb;

        $public_id = strtolower(self::clean_text($public_id, 36));
        if (!self::is_uuid($public_id)) {
            return new WP_Error('conversation_not_found', __('Gespräch nicht gefunden.', 'madex-chatbot'));
        }
        $sessions = $wpdb->prefix . 'madex_chat_sessions';
        $messages = $wpdb->prefix . 'madex_chat_messages';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, public_id, status, customer_type, topic, created_at, last_seen, user_name, user_email, user_id
                 FROM {$sessions} WHERE public_id = %s",
                $public_id
            ),
            ARRAY_A
        );
        if (!$row) {
            return new WP_Error('conversation_not_found', __('Gespräch nicht gefunden.', 'madex-chatbot'));
        }

        $message_rows = $wpdb->get_results(
            $wpdb->prepare("SELECT id, content, sender_type, is_fallback, created_at FROM {$messages} WHERE session_id = %d ORDER BY id ASC LIMIT 500", (int) $row['id']),
            ARRAY_A
        );
        $transcript = array();
        $user_messages = 0;
        $fallbacks = 0;
        foreach ((array) $message_rows as $message) {
            $is_user = 'user' === $message['sender_type'];
            $user_messages += $is_user ? 1 : 0;
            $fallbacks += empty($message['is_fallback']) ? 0 : 1;
            $transcript[] = array(
                'id' => (int) $message['id'],
                'content' => (string) $message['content'],
                'sender' => $is_user ? 'user' : 'ai',
                'is_fallback' => !empty($message['is_fallback']),
                'created_at' => $message['created_at'],
            );
        }

        $row['user_messages'] = $user_messages;
        $row['fallbacks'] = $fallbacks;
        $row['last_user_message'] = '';
        $conversation = self::conversation_dto($row, self::active_since());
        $conversation['messages'] = $transcript;

        // Contact details only exist if the visitor submitted them.
        $conversation['contact'] = null;
        $appointment = $wpdb->get_row(
            $wpdb->prepare('SELECT id, reference, customer_name, company, email, phone FROM ' . self::appointments_table() . ' WHERE session_public_id = %s ORDER BY id DESC LIMIT 1', $public_id),
            ARRAY_A
        );
        if ($appointment) {
            $conversation['contact'] = $appointment;
        } elseif (!empty($row['user_id'])) {
            $conversation['contact'] = array(
                'id' => 0,
                'reference' => '',
                'customer_name' => (string) $row['user_name'],
                'company' => '',
                'email' => (string) $row['user_email'],
                'phone' => '',
            );
        }

        return $conversation;
    }

    /**
     * Live activity feed: active chats plus the newest appointment requests.
     */
    public static function get_live_activity() {
        $live = self::list_conversations(array('state' => 'live', 'per_page' => 12));
        $recent = self::list_appointments(array('per_page' => 6));
        $events = array();
        foreach ($recent['items'] as $item) {
            $events[] = array(
                'reference' => $item['reference'],
                'label' => $item['customer_name'],
                'detail' => self::service_label($item['service']),
                'status' => $item['status'],
                'customer_status' => $item['customer_status'],
                'created_at' => $item['created_at'],
            );
        }

        return array(
            'active_count' => (int) $live['total'],
            'active' => $live['items'],
            'events' => $events,
            'generated_at' => current_time('mysql'),
        );
    }

    /**
     * Delete conversations older than the retention period. Appointment
     * requests are kept because they are business records.
     */
    public static function purge_conversations($days) {
        global $wpdb;

        $days = max(1, min(3650, absint($days)));
        $sessions = $wpdb->prefix . 'madex_chat_sessions';
        $messages = $wpdb->prefix . 'madex_chat_messages';
        $cutoff = gmdate('Y-m-d H:i:s', current_time('timestamp') - ($days * DAY_IN_SECONDS));
        $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM {$sessions} WHERE COALESCE(last_seen, updated_at, created_at) < %s LIMIT 1000", $cutoff));
        if (empty($ids)) {
            return 0;
        }
        $ids = implode(',', array_map('absint', $ids));
        $wpdb->query("DELETE FROM {$messages} WHERE session_id IN ({$ids})");
        return (int) $wpdb->query("DELETE FROM {$sessions} WHERE id IN ({$ids})");
    }

    private static function active_since() {
        return gmdate('Y-m-d H:i:s', current_time('timestamp') - (5 * MINUTE_IN_SECONDS));
    }

    private static function conversation_dto($row, $active_since) {
        $is_live = 'active' === $row['status'] && !empty($row['last_seen']) && $row['last_seen'] >= $active_since;
        $preview = isset($row['last_user_message']) ? (string) $row['last_user_message'] : '';
        if (function_exists('mb_strlen') && mb_strlen($preview) > 120) {
            $preview = mb_substr($preview, 0, 117) . '…';
        }

        return array(
            'public_id' => (string) $row['public_id'],
            'visitor' => self::visitor_label($row['public_id']),
            'is_live' => $is_live,
            'customer_type' => in_array($row['customer_type'], array('client', 'prospect'), true) ? $row['customer_type'] : 'unknown',
            'topic' => (string) $row['topic'],
            'topic_label' => '' === (string) $row['topic'] ? '' : self::service_label($row['topic']),
            'created_at' => $row['created_at'],
            'last_seen' => !empty($row['last_seen']) ? $row['last_seen'] : $row['created_at'],
            'user_messages' => (int) $row['user_messages'],
            'fallbacks' => (int) $row['fallbacks'],
            'preview' => $preview,
        );
    }

    private static function send_appointment_notification($appointment_id, $actor_id = 0) {
        global $wpdb;

        $appointment = self::get_appointment($appointment_id);
        if (is_wp_error($appointment)) {
            return $appointment;
        }

        $recipients = self::get_notification_recipients();
        if (empty($recipients)) {
            return new WP_Error('no_notification_recipient', __('No appointment notification recipient is configured.', 'madex-chatbot'));
        }

        // Strip CR/LF from the subject to prevent header injection via names.
        $subject = sprintf(
            /* translators: 1: reference, 2: customer name */
            __('Neue Terminanfrage %1$s – %2$s', 'madex-chatbot'),
            $appointment['reference'],
            preg_replace('/[\r\n]+/', ' ', $appointment['customer_name'])
        );
        $date = $appointment['preferred_date'] ? wp_date('D, d.m.Y', strtotime($appointment['preferred_date'] . ' 12:00:00')) : '–';
        $mail = array(
            'heading' => __('Neue Terminanfrage', 'madex-chatbot'),
            'intro' => __('Über den Madex Chatbot ist eine neue Terminanfrage eingegangen. Der Termin ist noch nicht bestätigt.', 'madex-chatbot'),
            'rows' => array(
                __('Referenz', 'madex-chatbot') => $appointment['reference'],
                __('Name', 'madex-chatbot') => $appointment['customer_name'],
                __('Unternehmen', 'madex-chatbot') => (string) $appointment['company'],
                __('E-Mail', 'madex-chatbot') => (string) $appointment['email'],
                __('Telefon', 'madex-chatbot') => (string) $appointment['phone'],
                __('Kunde', 'madex-chatbot') => 'yes' === $appointment['existing_client'] ? __('Bestehender Kunde', 'madex-chatbot') : __('Interessent', 'madex-chatbot'),
                __('Leistung', 'madex-chatbot') => self::service_label($appointment['service']),
                __('Paket', 'madex-chatbot') => (string) $appointment['package_interest'],
                __('Wunschtermin', 'madex-chatbot') => $date . ' · ' . self::time_label($appointment['preferred_time']),
            ),
            'note_title' => __('Anliegen', 'madex-chatbot'),
            'note' => (string) ($appointment['message'] ?: '–'),
            'footer' => __('Diese E-Mail wurde vom Madex Chatbot gesendet. Antworten gehen direkt an den Kunden.', 'madex-chatbot'),
        );
        if (class_exists('Madex_Portal_Auth')) {
            $mail['button_label'] = __('Im Portal öffnen', 'madex-chatbot');
            $mail['button_url'] = Madex_Portal_Auth::url('appointments', array('ref' => $appointment['reference']));
        }

        $headers = array();
        if (is_email($appointment['email'])) {
            $headers[] = 'Reply-To: ' . preg_replace('/[\r\n<>",]+/', '', $appointment['customer_name']) . ' <' . $appointment['email'] . '>';
        }

        $mail_error = '';
        $capture = function ($error) use (&$mail_error) {
            if (is_wp_error($error)) {
                $mail_error = substr(sanitize_text_field($error->get_error_message()), 0, 500);
            }
        };
        add_action('wp_mail_failed', $capture);
        $sent = Madex_Mailer::send($recipients, $subject, $mail, $headers);
        remove_action('wp_mail_failed', $capture);
        $now = current_time('mysql');
        $email_status = $sent ? 'sent' : 'failed';
        $email_error = $sent ? '' : ($mail_error !== '' ? $mail_error : 'wp_mail returned false');

        $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . self::appointments_table() . ' SET email_status = %s, email_error = %s, email_attempts = email_attempts + 1, email_last_attempt_at = %s, updated_at = %s WHERE id = %d',
                $email_status,
                $email_error,
                $now,
                $now,
                absint($appointment_id)
            )
        );
        self::add_appointment_event(
            absint($appointment_id),
            $sent ? 'email_sent' : 'email_failed',
            absint($actor_id),
            '',
            '',
            '',
            array('email_status' => $email_status)
        );

        if (!$sent) {
            return new WP_Error('notification_failed', __('The request was saved, but its notification email could not be sent.', 'madex-chatbot'));
        }

        return true;
    }

    private static function get_notification_recipients() {
        $settings = get_option('madex_chatbot_appointment_settings', array());
        $raw = array();
        foreach (array('notification_recipients', 'email_recipients', 'recipients') as $key) {
            if (!empty($settings[$key])) {
                $raw = $settings[$key];
                break;
            }
        }
        if (empty($raw)) {
            $raw = get_option('madex_chatbot_appointment_recipients', array());
        }
        if (!is_array($raw)) {
            $raw = preg_split('/[,;\r\n]+/', (string) $raw);
        }

        $recipients = array();
        foreach ((array) $raw as $email) {
            $email = sanitize_email(trim($email));
            if ($email && is_email($email)) {
                $recipients[] = $email;
            }
        }
        if (empty($recipients)) {
            $admin_email = sanitize_email(get_option('admin_email'));
            if ($admin_email && is_email($admin_email)) {
                $recipients[] = $admin_email;
            }
        }

        return array_values(array_unique(apply_filters('madex_chatbot_appointment_recipients', $recipients)));
    }

    private static function validate_appointment($data) {
        if (!is_array($data)) {
            return new WP_Error('invalid_appointment', __('Ungültige Anfrage.', 'madex-chatbot'));
        }

        $session_public_id = isset($data['session_public_id']) ? strtolower(self::clean_text($data['session_public_id'], 36)) : '';
        if (!self::is_uuid($session_public_id)) {
            return new WP_Error('invalid_session', __('Die Chat-Sitzung ist ungültig. Bitte starten Sie ein neues Gespräch.', 'madex-chatbot'));
        }

        $idempotency_key = isset($data['idempotency_key']) ? self::clean_text($data['idempotency_key'], 128) : '';
        if (strlen($idempotency_key) < 16 || !preg_match('/^[A-Za-z0-9._:-]+$/', $idempotency_key)) {
            return new WP_Error('invalid_idempotency_key', __('Die Anfrage konnte nicht zugeordnet werden. Bitte versuchen Sie es erneut.', 'madex-chatbot'));
        }

        $customer_name = self::clean_text(isset($data['customer_name']) ? $data['customer_name'] : '', 191);
        if (strlen($customer_name) < 2) {
            return new WP_Error('customer_name_required', __('Bitte geben Sie Ihren vollständigen Namen ein.', 'madex-chatbot'));
        }

        $email = sanitize_email(isset($data['email']) ? $data['email'] : '');
        if (!$email || !is_email($email)) {
            return new WP_Error('invalid_email', __('Bitte geben Sie eine gültige E-Mail-Adresse ein.', 'madex-chatbot'));
        }

        $existing_client = self::normalize_yes_no(isset($data['existing_client']) ? $data['existing_client'] : '');
        if (false === $existing_client) {
            return new WP_Error('invalid_customer_status', __('Bitte geben Sie an, ob Sie bereits Kunde sind.', 'madex-chatbot'));
        }

        $preferred_date = self::clean_text(isset($data['preferred_date']) ? $data['preferred_date'] : '', 10);
        if (!self::is_valid_date($preferred_date) || $preferred_date < current_time('Y-m-d')) {
            return new WP_Error('invalid_preferred_date', __('Bitte wählen Sie ein gültiges Datum in der Zukunft.', 'madex-chatbot'));
        }
        $preferred_time = self::clean_text(isset($data['preferred_time']) ? $data['preferred_time'] : '', 100);
        if ('' === $preferred_time) {
            return new WP_Error('preferred_time_required', __('Bitte wählen Sie ein Zeitfenster.', 'madex-chatbot'));
        }

        $privacy_consent = isset($data['privacy_consent']) ? $data['privacy_consent'] : 0;
        if (!in_array((string) $privacy_consent, array('1', 'true', 'yes', 'on'), true)) {
            return new WP_Error('privacy_consent_required', __('Bitte stimmen Sie der Datenverarbeitung zu.', 'madex-chatbot'));
        }

        return array(
            'session_public_id' => $session_public_id,
            'idempotency_key' => $idempotency_key,
            'request_type' => self::clean_text(isset($data['request_type']) ? $data['request_type'] : 'appointment', 40),
            'customer_name' => $customer_name,
            'company' => self::clean_text(isset($data['company']) ? $data['company'] : '', 191),
            'email' => $email,
            'phone' => self::sanitize_phone(isset($data['phone']) ? $data['phone'] : ''),
            'existing_client' => $existing_client,
            'service' => self::clean_text(isset($data['service']) ? $data['service'] : '', 191),
            'package_interest' => self::clean_text(isset($data['package_interest']) ? $data['package_interest'] : '', 191),
            'preferred_date' => $preferred_date,
            'preferred_time' => $preferred_time,
            'message' => self::clean_textarea(isset($data['message']) ? $data['message'] : '', 5000),
            'consent_version' => self::clean_text(isset($data['consent_version']) ? $data['consent_version'] : self::APPOINTMENT_CONSENT_VERSION, 32),
        );
    }

    private static function add_appointment_event($appointment_id, $event_type, $actor_user_id = 0, $old_status = '', $new_status = '', $note = '', $data = array()) {
        global $wpdb;

        return false !== $wpdb->insert(
            self::appointment_events_table(),
            array(
                'appointment_id' => absint($appointment_id),
                'event_type' => sanitize_key($event_type),
                'actor_user_id' => absint($actor_user_id),
                'old_status' => sanitize_key($old_status),
                'new_status' => sanitize_key($new_status),
                'note' => self::clean_textarea($note, 5000),
                'data' => wp_json_encode(is_array($data) ? $data : array()),
                'created_at' => current_time('mysql'),
            )
        );
    }

    private static function get_appointment_events($appointment_id) {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, event_type, actor_user_id, old_status, new_status, note, data, created_at FROM ' . self::appointment_events_table() . ' WHERE appointment_id = %d ORDER BY id ASC',
                absint($appointment_id)
            ),
            ARRAY_A
        );
        foreach ((array) $rows as &$row) {
            $row['id'] = (int) $row['id'];
            $row['actor_user_id'] = (int) $row['actor_user_id'];
            $row['data'] = self::decode_json_array($row['data']);
        }
        unset($row);
        return (array) $rows;
    }

    private static function appointment_statuses() {
        return array('new', 'contacted', 'confirmed', 'completed', 'cancelled');
    }

    private static function public_package_dto($row) {
        return array(
            'id' => (int) $row['id'],
            'name' => $row['name'],
            'slug' => $row['slug'],
            'short_description' => $row['short_description'],
            'description' => $row['description'],
            'features' => self::decode_json_array($row['features_json']),
            'audience' => $row['audience'],
            'icon' => $row['icon'],
            'cta_label' => $row['cta_label'],
            'cta_action' => $row['cta_action'],
        );
    }

    private static function normalize_package_row($row) {
        $row['id'] = (int) $row['id'];
        $row['display_order'] = (int) $row['display_order'];
        $row['is_active'] = (bool) $row['is_active'];
        $row['features'] = self::decode_json_array($row['features_json']);
        $row['conditions'] = self::decode_json_array($row['conditions_json']);
        unset($row['features_json'], $row['conditions_json']);
        return $row;
    }

    private static function normalize_appointment_row($row) {
        $row['id'] = (int) $row['id'];
        $row['package_id'] = null === $row['package_id'] ? null : (int) $row['package_id'];
        $row['privacy_consent'] = (bool) $row['privacy_consent'];
        $row['email_attempts'] = (int) $row['email_attempts'];
        unset($row['idempotency_hash']);
        return $row;
    }

    private static function sanitize_profile($profile) {
        $clean = array();
        $allowed = array('existing_client', 'service', 'company_size', 'customer_status', 'request_type', 'goals', 'has_website');
        foreach ($allowed as $field) {
            if (!isset($profile[$field])) {
                continue;
            }
            if ('goals' === $field) {
                $clean[$field] = array_values(array_intersect(
                    array_map('sanitize_key', (array) $profile[$field]),
                    array_keys(self::service_options())
                ));
            } elseif ('has_website' === $field) {
                $value = self::normalize_yes_no($profile[$field]);
                if (false !== $value) {
                    $clean[$field] = $value;
                }
            } elseif ('company_size' === $field) {
                $clean[$field] = max(0, absint($profile[$field]));
            } elseif ('existing_client' === $field) {
                $value = self::normalize_yes_no($profile[$field]);
                if (false !== $value) {
                    $clean[$field] = $value;
                }
            } else {
                $clean[$field] = strtolower(self::clean_text($profile[$field], 191));
            }
        }
        return $clean;
    }

    private static function sanitize_conditions($conditions) {
        if (empty($conditions)) {
            return array();
        }

        // Group format: { relation: and|or, rules: [...] }.
        if (isset($conditions['rules'])) {
            if (!is_array($conditions['rules'])) {
                return new WP_Error('invalid_conditions', __('Invalid package conditions.', 'madex-chatbot'));
            }
            $rules = self::sanitize_conditions($conditions['rules']);
            if (is_wp_error($rules)) {
                return $rules;
            }
            return array(
                'relation' => isset($conditions['relation']) && 'or' === strtolower($conditions['relation']) ? 'or' : 'and',
                'rules' => $rules,
            );
        }

        // Single rule format.
        if (isset($conditions['field'])) {
            $field = sanitize_key($conditions['field']);
            $operator = isset($conditions['operator']) ? sanitize_key($conditions['operator']) : 'equals';
            $allowed_fields = array('existing_client', 'service', 'company_size', 'customer_status', 'request_type');
            $allowed_operators = array('equals', 'is', 'not_equals', 'is_not', 'contains', 'not_contains', 'in', 'not_in', 'gte', 'lte', 'greater_than', 'less_than', 'truthy', 'falsy');
            if (!in_array($field, $allowed_fields, true) || !in_array($operator, $allowed_operators, true)) {
                return new WP_Error('invalid_condition_rule', __('Invalid package condition rule.', 'madex-chatbot'));
            }
            $value = isset($conditions['value']) ? $conditions['value'] : '';
            if (is_array($value)) {
                $value = self::sanitize_string_list($value, 50, 191);
            } elseif ('company_size' === $field) {
                $value = absint($value);
            } else {
                $value = strtolower(self::clean_text($value, 191));
            }
            return array('field' => $field, 'operator' => $operator, 'value' => $value);
        }

        // Plain list of rules.
        $sanitized = array();
        foreach ($conditions as $condition) {
            if (!is_array($condition)) {
                return new WP_Error('invalid_condition_rule', __('Invalid package condition rule.', 'madex-chatbot'));
            }
            $rule = self::sanitize_conditions($condition);
            if (is_wp_error($rule)) {
                return $rule;
            }
            $sanitized[] = $rule;
        }
        return $sanitized;
    }

    private static function conditions_match($conditions, $profile) {
        if (empty($conditions)) {
            return true;
        }
        if (isset($conditions['rules'])) {
            $relation = isset($conditions['relation']) && 'or' === $conditions['relation'] ? 'or' : 'and';
            foreach ((array) $conditions['rules'] as $rule) {
                $matches = self::conditions_match($rule, $profile);
                if ('and' === $relation && !$matches) {
                    return false;
                }
                if ('or' === $relation && $matches) {
                    return true;
                }
            }
            return 'and' === $relation;
        }
        if (!isset($conditions['field'])) {
            foreach ($conditions as $rule) {
                if (!self::conditions_match($rule, $profile)) {
                    return false;
                }
            }
            return true;
        }

        $field = $conditions['field'];
        $operator = isset($conditions['operator']) ? $conditions['operator'] : 'equals';
        $expected = isset($conditions['value']) ? $conditions['value'] : '';
        $actual = isset($profile[$field]) ? $profile[$field] : null;

        // Visitors can pick several goals: "Interesse ist X" matches when X is
        // one of them.
        if ('service' === $field && !empty($profile['goals']) && is_array($profile['goals'])) {
            $goals = array_map('strval', $profile['goals']);
            switch ($operator) {
                case 'not_equals':
                case 'is_not':
                    return !in_array((string) $expected, $goals, true);
                case 'in':
                    return (bool) array_intersect($goals, array_map('strval', (array) $expected));
                case 'not_in':
                    return !array_intersect($goals, array_map('strval', (array) $expected));
                case 'equals':
                case 'is':
                    return in_array((string) $expected, $goals, true);
            }
        }

        switch ($operator) {
            case 'truthy':
                return !empty($actual);
            case 'falsy':
                return empty($actual);
            case 'not_equals':
            case 'is_not':
                return (string) $actual !== (string) $expected;
            case 'contains':
                return null !== $actual && false !== stripos((string) $actual, (string) $expected);
            case 'not_contains':
                return null === $actual || false === stripos((string) $actual, (string) $expected);
            case 'in':
                return in_array((string) $actual, array_map('strval', (array) $expected), true);
            case 'not_in':
                return !in_array((string) $actual, array_map('strval', (array) $expected), true);
            case 'gte':
                return is_numeric($actual) && (float) $actual >= (float) $expected;
            case 'lte':
                return is_numeric($actual) && (float) $actual <= (float) $expected;
            case 'greater_than':
                return is_numeric($actual) && (float) $actual > (float) $expected;
            case 'less_than':
                return is_numeric($actual) && (float) $actual < (float) $expected;
            case 'equals':
            case 'is':
            default:
                return null !== $actual && (string) $actual === (string) $expected;
        }
    }

    private static function grouped_counts($table, $column, $start_date, $limit = 10) {
        global $wpdb;

        $allowed = array('status', 'service', 'customer_status', 'topic', 'customer_type', 'package_interest');
        if (!in_array($column, $allowed, true)) {
            return array();
        }
        $limit = max(1, min(50, absint($limit)));
        return (array) $wpdb->get_results(
            $wpdb->prepare("SELECT {$column} label, COUNT(*) total FROM {$table} WHERE created_at >= %s AND {$column} <> '' GROUP BY {$column} ORDER BY total DESC LIMIT %d", $start_date . ' 00:00:00', $limit),
            ARRAY_A
        );
    }

    private static function rows_to_count_map($rows, $key) {
        $map = array();
        foreach ((array) $rows as $row) {
            $map[$row[$key]] = (int) $row['total'];
        }
        return $map;
    }

    private static function generate_appointment_reference() {
        global $wpdb;

        $table = self::appointments_table();
        for ($attempt = 0; $attempt < 5; $attempt++) {
            try {
                $random = strtoupper(bin2hex(random_bytes(6)));
            } catch (Exception $exception) {
                $random = strtoupper(wp_generate_password(12, false, false));
            }
            $reference = 'MDX-' . $random;
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE reference = %s", $reference));
            if (!$exists) {
                return $reference;
            }
        }
        return 'MDX-' . strtoupper(wp_generate_password(16, false, false));
    }

    private static function sanitize_string_list($values, $max_items, $max_length) {
        if (is_string($values)) {
            $decoded = json_decode($values, true);
            $values = is_array($decoded) ? $decoded : preg_split('/\r\n|\r|\n/', $values);
        }
        $clean = array();
        foreach (array_slice((array) $values, 0, $max_items) as $value) {
            $value = self::clean_text($value, $max_length);
            if ('' !== $value) {
                $clean[] = $value;
            }
        }
        return array_values($clean);
    }

    private static function decode_json_array($json) {
        if (is_array($json)) {
            return $json;
        }
        $decoded = json_decode((string) $json, true);
        return is_array($decoded) ? $decoded : array();
    }

    private static function clean_text($value, $max_length) {
        $value = sanitize_text_field(wp_unslash((string) $value));
        return function_exists('mb_substr') ? mb_substr($value, 0, $max_length) : substr($value, 0, $max_length);
    }

    private static function clean_textarea($value, $max_length) {
        $value = sanitize_textarea_field(wp_unslash((string) $value));
        return function_exists('mb_substr') ? mb_substr($value, 0, $max_length) : substr($value, 0, $max_length);
    }

    private static function sanitize_phone($value) {
        $value = preg_replace('/[^0-9+().\-\s]/', '', wp_unslash((string) $value));
        return self::clean_text($value, 40);
    }

    private static function clean_url_or_icon($value) {
        $value = trim(wp_unslash((string) $value));
        if (preg_match('#^https?://#i', $value)) {
            return esc_url_raw($value, array('http', 'https'));
        }
        return self::clean_text($value, 255);
    }

    private static function clean_url_or_action($value) {
        $value = trim(wp_unslash((string) $value));
        if (preg_match('#^(https?://|/)#i', $value)) {
            return esc_url_raw($value, array('http', 'https'));
        }
        return self::clean_text($value, 255);
    }

    private static function normalize_yes_no($value) {
        $value = strtolower(trim((string) $value));
        if (in_array($value, array('yes', '1', 'true', 'on', 'ja'), true)) {
            return 'yes';
        }
        if (in_array($value, array('no', '0', 'false', 'off', 'nein'), true)) {
            return 'no';
        }
        return false;
    }

    private static function is_uuid($value) {
        return is_string($value) && 1 === preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value);
    }

    private static function is_valid_date($date) {
        if (!is_string($date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return false;
        }
        $parsed = DateTime::createFromFormat('!Y-m-d', $date);
        return $parsed && $parsed->format('Y-m-d') === $date;
    }

    private static function csv_cell($value) {
        $value = (string) $value;
        // Prevent spreadsheet formula execution when the caller writes CSV.
        if (preg_match('/^[=+\-@\t\r]/', $value)) {
            $value = "'" . $value;
        }
        return $value;
    }
}
