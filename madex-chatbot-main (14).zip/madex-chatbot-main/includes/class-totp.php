<?php
/**
 * RFC 6238 TOTP and one-time recovery-code primitives.
 *
 * This class deliberately contains no HTTP or persistence logic. Callers are
 * responsible for atomically persisting the accepted TOTP counter and the
 * remaining recovery-code hashes returned by this class.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Madex_TOTP {

    const ALGORITHM = 'sha1';
    const DIGITS = 6;
    const PERIOD = 30;
    const DEFAULT_WINDOW = 1;
    const SECRET_BYTES = 20;
    const RECOVERY_CODE_BYTES = 10;

    /**
     * Generate a 160-bit Base32-encoded TOTP secret.
     *
     * @return string|WP_Error
     */
    public static function generate_secret() {
        try {
            return self::base32_encode(random_bytes(self::SECRET_BYTES));
        } catch (Exception $exception) {
            return new WP_Error(
                'madex_totp_random_failed',
                __('Secure random number generation is unavailable.', 'madex-chatbot')
            );
        }
    }

    /**
     * Encode binary data using RFC 4648 Base32 without padding.
     *
     * @param string $binary Binary input.
     * @return string
     */
    public static function base32_encode($binary) {
        if ($binary === '') {
            return '';
        }

        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $buffer = 0;
        $bits_left = 0;
        $output = '';
        $length = strlen($binary);

        for ($index = 0; $index < $length; $index++) {
            $buffer = ($buffer << 8) | ord($binary[$index]);
            $bits_left += 8;

            while ($bits_left >= 5) {
                $bits_left -= 5;
                $output .= $alphabet[($buffer >> $bits_left) & 31];
            }

            // Only the unconsumed bits are needed on the next iteration.
            if ($bits_left > 0) {
                $buffer &= (1 << $bits_left) - 1;
            } else {
                $buffer = 0;
            }
        }

        if ($bits_left > 0) {
            $output .= $alphabet[($buffer << (5 - $bits_left)) & 31];
        }

        return $output;
    }

    /**
     * Decode an RFC 4648 Base32 string.
     *
     * Spaces and hyphens are accepted for manual-entry usability. Padding is
     * optional. Invalid input returns a WP_Error instead of partial output.
     *
     * @param string $encoded Base32 input.
     * @return string|WP_Error Binary output on success.
     */
    public static function base32_decode($encoded) {
        $encoded = strtoupper((string) $encoded);
        $encoded = preg_replace('/[\s-]+/', '', $encoded);
        $encoded = rtrim($encoded, '=');

        if ($encoded === '' || !preg_match('/^[A-Z2-7]+$/', $encoded)) {
            return new WP_Error(
                'madex_totp_invalid_secret',
                __('The authenticator secret is invalid.', 'madex-chatbot')
            );
        }

        $alphabet = array_flip(str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'));
        $buffer = 0;
        $bits_left = 0;
        $output = '';
        $length = strlen($encoded);

        for ($index = 0; $index < $length; $index++) {
            $value = $alphabet[$encoded[$index]];
            $buffer = ($buffer << 5) | $value;
            $bits_left += 5;

            if ($bits_left >= 8) {
                $bits_left -= 8;
                $output .= chr(($buffer >> $bits_left) & 255);
            }

            if ($bits_left > 0) {
                $buffer &= (1 << $bits_left) - 1;
            } else {
                $buffer = 0;
            }
        }

        return $output;
    }

    /**
     * Return the RFC 6238 time-step counter for a timestamp.
     *
     * @param int|null $timestamp Unix timestamp; current time when omitted.
     * @return int
     */
    public static function current_step($timestamp = null) {
        if ($timestamp === null) {
            $timestamp = time();
        }

        return (int) floor(((int) $timestamp) / self::PERIOD);
    }

    /**
     * Generate a six-digit TOTP for a given timestamp.
     *
     * @param string   $secret    Base32 secret.
     * @param int|null $timestamp Unix timestamp; current time when omitted.
     * @return string|WP_Error
     */
    public static function generate_code($secret, $timestamp = null) {
        return self::generate_code_for_counter($secret, self::current_step($timestamp));
    }

    /**
     * Generate a six-digit HOTP value for a specific counter.
     *
     * Exposed for deterministic verification and RFC test-vector testing.
     *
     * @param string $secret  Base32 secret.
     * @param int    $counter Non-negative counter.
     * @return string|WP_Error
     */
    public static function generate_code_for_counter($secret, $counter) {
        $counter = (int) $counter;
        if ($counter < 0) {
            return new WP_Error(
                'madex_totp_invalid_counter',
                __('The authenticator counter is invalid.', 'madex-chatbot')
            );
        }

        $key = self::base32_decode($secret);
        if (is_wp_error($key)) {
            return $key;
        }

        // RFC 4226 uses an unsigned 64-bit, network-byte-order counter.
        $high = (int) floor($counter / 4294967296);
        $low = (int) ($counter % 4294967296);
        $binary_counter = pack('N2', $high, $low);
        $digest = hash_hmac(self::ALGORITHM, $binary_counter, $key, true);
        $offset = ord($digest[strlen($digest) - 1]) & 0x0f;
        $binary = unpack('Nvalue', substr($digest, $offset, 4));
        $value = $binary['value'] & 0x7fffffff;
        $modulus = (int) pow(10, self::DIGITS);

        return str_pad((string) ($value % $modulus), self::DIGITS, '0', STR_PAD_LEFT);
    }

    /**
     * Verify a TOTP and reject counters already accepted for this user.
     *
     * The caller must atomically persist result['counter'] only when valid is
     * true. A compare-and-set update is required to prevent concurrent replay.
     *
     * @param string   $secret             Base32 secret.
     * @param string   $code               Six-digit user code.
     * @param int      $last_accepted_step Last successfully accepted counter.
     * @param int|null $timestamp          Unix timestamp; current time if null.
     * @param int      $window             Number of steps accepted each side.
     * @return array{valid:bool,counter:int|null,error:string}
     */
    public static function verify($secret, $code, $last_accepted_step = -1, $timestamp = null, $window = self::DEFAULT_WINDOW) {
        $code = preg_replace('/\s+/', '', (string) $code);
        $window = max(0, min(2, (int) $window));
        $last_accepted_step = (int) $last_accepted_step;

        if (!preg_match('/^\d{' . self::DIGITS . '}$/D', $code)) {
            return array('valid' => false, 'counter' => null, 'error' => 'invalid_code');
        }

        $current_step = self::current_step($timestamp);
        $matched_replay = false;

        // Prefer the current step, then adjacent steps, for predictable drift.
        $offsets = array(0);
        for ($distance = 1; $distance <= $window; $distance++) {
            $offsets[] = -$distance;
            $offsets[] = $distance;
        }

        foreach ($offsets as $offset) {
            $candidate_step = $current_step + $offset;
            if ($candidate_step < 0) {
                continue;
            }

            $candidate = self::generate_code_for_counter($secret, $candidate_step);
            if (is_wp_error($candidate)) {
                return array('valid' => false, 'counter' => null, 'error' => 'invalid_secret');
            }

            if (hash_equals($candidate, $code)) {
                if ($candidate_step <= $last_accepted_step) {
                    $matched_replay = true;
                    continue;
                }

                return array('valid' => true, 'counter' => $candidate_step, 'error' => '');
            }
        }

        return array(
            'valid' => false,
            'counter' => null,
            'error' => $matched_replay ? 'replayed_code' : 'invalid_code',
        );
    }

    /**
     * Build a Google Authenticator-compatible otpauth URI.
     *
     * The URI contains the secret and must only be shown during an authenticated
     * pending-enrollment flow. Never log it or send it to a third-party QR API.
     *
     * @param string $secret  Base32 secret.
     * @param string $account Account label (usually the WordPress login/email).
     * @param string $issuer  Display name in the authenticator app.
     * @return string|WP_Error
     */
    public static function build_otpauth_uri($secret, $account, $issuer = 'Madex Management') {
        $decoded = self::base32_decode($secret);
        if (is_wp_error($decoded)) {
            return $decoded;
        }

        $account = trim(wp_strip_all_tags((string) $account));
        $issuer = trim(wp_strip_all_tags((string) $issuer));

        if ($account === '' || $issuer === '') {
            return new WP_Error(
                'madex_totp_invalid_label',
                __('The authenticator account label is invalid.', 'madex-chatbot')
            );
        }

        $label = rawurlencode($issuer . ':' . $account);
        $query = http_build_query(
            array(
                'secret' => strtoupper(preg_replace('/[\s-]+/', '', $secret)),
                'issuer' => $issuer,
                'algorithm' => strtoupper(self::ALGORITHM),
                'digits' => self::DIGITS,
                'period' => self::PERIOD,
            ),
            '',
            '&',
            PHP_QUERY_RFC3986
        );

        return 'otpauth://totp/' . $label . '?' . $query;
    }

    /**
     * Generate one-time recovery codes and independent WordPress password hashes.
     *
     * @param int $count Number of codes (between 4 and 20).
     * @return array{codes:array,hashes:array}|WP_Error
     */
    public static function generate_recovery_codes($count = 8) {
        $count = max(4, min(20, (int) $count));
        $codes = array();
        $hashes = array();

        try {
            for ($index = 0; $index < $count; $index++) {
                $raw = self::base32_encode(random_bytes(self::RECOVERY_CODE_BYTES));
                $normalized = strtolower($raw);
                $display = implode('-', str_split($normalized, 4));
                $codes[] = $display;
                $hashes[] = wp_hash_password($normalized);
            }
        } catch (Exception $exception) {
            return new WP_Error(
                'madex_recovery_random_failed',
                __('Secure recovery-code generation is unavailable.', 'madex-chatbot')
            );
        }

        return array('codes' => $codes, 'hashes' => $hashes);
    }

    /**
     * Normalize a recovery code for verification.
     *
     * @param string $code User-supplied code.
     * @return string
     */
    public static function normalize_recovery_code($code) {
        return strtolower(preg_replace('/[^A-Za-z2-7]/', '', (string) $code));
    }

    /**
     * Verify and consume one recovery code in memory.
     *
     * The returned remaining_hashes value must be persisted with an atomic
     * compare-and-set by the caller before treating the code as consumed.
     *
     * @param string $code   User-supplied recovery code.
     * @param array  $hashes Stored independent password hashes.
     * @return array{valid:bool,matched_index:int|null,remaining_hashes:array}
     */
    public static function consume_recovery_code($code, $hashes) {
        $normalized = self::normalize_recovery_code($code);
        $hashes = array_values(array_filter((array) $hashes, 'is_string'));

        if (strlen($normalized) !== 16) {
            return array('valid' => false, 'matched_index' => null, 'remaining_hashes' => $hashes);
        }

        foreach ($hashes as $index => $hash) {
            if (wp_check_password($normalized, $hash)) {
                $remaining = $hashes;
                unset($remaining[$index]);

                return array(
                    'valid' => true,
                    'matched_index' => (int) $index,
                    'remaining_hashes' => array_values($remaining),
                );
            }
        }

        return array('valid' => false, 'matched_index' => null, 'remaining_hashes' => $hashes);
    }
}

