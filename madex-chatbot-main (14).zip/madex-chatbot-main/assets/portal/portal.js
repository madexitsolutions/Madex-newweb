/**
 * Madex Management Portal - progressive enhancement.
 * Loaded with a strict CSP: no inline handlers, no third-party requests.
 * Every page works without JavaScript; this file only adds comfort.
 */
(function () {
    'use strict';

    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function $(selector, root) {
        return (root || document).querySelector(selector);
    }

    function $all(selector, root) {
        return Array.prototype.slice.call((root || document).querySelectorAll(selector));
    }

    function text(node, value) {
        if (node) {
            node.textContent = value;
        }
    }

    /* ------------------------------------------------ Auth helpers */

    function initPasswordToggle() {
        $all('[data-toggle-password]').forEach(function (button) {
            var input = button.parentNode.querySelector('[data-password]');
            if (!input) {
                return;
            }
            var showLabel = button.textContent;
            button.addEventListener('click', function () {
                var visible = input.type === 'text';
                input.type = visible ? 'password' : 'text';
                button.textContent = visible ? showLabel : 'Verbergen';
                button.setAttribute('aria-pressed', visible ? 'false' : 'true');
                input.focus();
            });
        });
    }

    function initBusyButtons() {
        $all('form').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                var submitter = event.submitter || form.querySelector('[type="submit"]');
                if (form.dataset.submitted === '1') {
                    event.preventDefault();
                    return;
                }
                form.dataset.submitted = '1';
                if (submitter && submitter.dataset && submitter.dataset.submitLabel) {
                    // Do not disable: a disabled submitter would drop its name/value.
                    submitter.classList.add('is-busy');
                    submitter.setAttribute('aria-busy', 'true');
                    submitter.textContent = submitter.dataset.submitLabel;
                }
                window.setTimeout(function () {
                    form.dataset.submitted = '';
                }, 8000);
            });
        });
    }

    function initOtp() {
        $all('[data-otp]').forEach(function (input) {
            input.addEventListener('input', function () {
                var digits = input.value.replace(/\D+/g, '').slice(0, 6);
                if (digits !== input.value) {
                    input.value = digits;
                }
                input.classList.remove('is-invalid');
                input.removeAttribute('aria-invalid');
                if (digits.length === 6 && input.form && input.form.dataset.submitted !== '1') {
                    if (typeof input.form.requestSubmit === 'function') {
                        input.form.requestSubmit();
                    } else {
                        input.form.submit();
                    }
                }
            });
        });
    }

    function initQr() {
        $all('[data-qr]').forEach(function (figure) {
            var canvas = figure.querySelector('canvas');
            var value = figure.getAttribute('data-qr');
            if (!canvas || !value || typeof window.qrcode !== 'function') {
                figure.hidden = !canvas;
                return;
            }
            var qr = window.qrcode(0, 'M');
            qr.addData(value);
            qr.make();
            var count = qr.getModuleCount();
            var margin = 2;
            var scale = Math.max(4, Math.floor(200 / (count + margin * 2)));
            var size = (count + margin * 2) * scale;
            canvas.width = size;
            canvas.height = size;
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, size, size);
            ctx.fillStyle = '#1f2a31';
            for (var row = 0; row < count; row++) {
                for (var col = 0; col < count; col++) {
                    if (qr.isDark(row, col)) {
                        ctx.fillRect((col + margin) * scale, (row + margin) * scale, scale, scale);
                    }
                }
            }
        });
    }

    function copyText(value) {
        if (navigator.clipboard && window.isSecureContext) {
            return navigator.clipboard.writeText(value);
        }
        return new Promise(function (resolve, reject) {
            var area = document.createElement('textarea');
            area.value = value;
            area.setAttribute('readonly', '');
            area.className = 'visually-hidden';
            document.body.appendChild(area);
            area.select();
            try {
                document.execCommand('copy');
                resolve();
            } catch (error) {
                reject(error);
            }
            document.body.removeChild(area);
        });
    }

    function initCopy() {
        $all('[data-copy]').forEach(function (button) {
            var label = button.innerHTML;
            button.addEventListener('click', function () {
                var scope = button.closest('.copy-field, .auth-form') || document;
                var source = scope.querySelector('[data-copy-source]');
                if (!source) {
                    return;
                }
                var value = source.tagName === 'UL'
                    ? $all('li', source).map(function (li) { return li.textContent.trim(); }).join('\n')
                    : source.textContent.replace(/\s+/g, '');
                copyText(value).then(function () {
                    button.textContent = button.dataset.copiedLabel || 'Kopiert ✓';
                    window.setTimeout(function () { button.innerHTML = label; }, 2200);
                });
            });
        });

        $all('[data-download]').forEach(function (button) {
            button.addEventListener('click', function () {
                var source = $('[data-download-text]');
                if (!source) {
                    return;
                }
                var blob = new Blob([source.getAttribute('data-download-text')], { type: 'text/plain;charset=utf-8' });
                var url = URL.createObjectURL(blob);
                var link = document.createElement('a');
                link.href = url;
                link.download = source.getAttribute('data-download-name') || 'codes.txt';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
            });
        });

        var confirm = $('[data-confirm-codes]');
        var finish = $('[data-finish-setup]');
        if (confirm && finish) {
            var sync = function () {
                finish.classList.toggle('is-disabled', !confirm.checked);
                finish.setAttribute('aria-disabled', confirm.checked ? 'false' : 'true');
            };
            confirm.addEventListener('change', sync);
            finish.addEventListener('click', function (event) {
                if (!confirm.checked) {
                    event.preventDefault();
                    confirm.focus();
                }
            });
            sync();
        }
    }

    function initCountdown() {
        $all('[data-countdown]').forEach(function (node) {
            var remaining = parseInt(node.getAttribute('data-countdown'), 10) || 0;
            if (remaining <= 0 || remaining > 120) {
                return;
            }
            var form = node.closest('form');
            var submit = form ? form.querySelector('[type="submit"]') : null;
            if (submit) {
                submit.disabled = true;
            }
            var tick = function () {
                if (remaining <= 0) {
                    text(node, node.getAttribute('data-countdown-done') || '');
                    if (submit) {
                        submit.disabled = false;
                    }
                    return;
                }
                var m = Math.floor(remaining / 60);
                var s = remaining % 60;
                text(node, 'Erneut möglich in ' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s);
                remaining -= 1;
                window.setTimeout(tick, 1000);
            };
            tick();
        });
    }

    /* ------------------------------------------------- App helpers */

    function initMoreSheet() {
        var toggle = $('[data-more-toggle]');
        var sheet = $('[data-more-sheet]');
        if (!toggle || !sheet) {
            return;
        }
        var open = function () {
            sheet.hidden = false;
            toggle.setAttribute('aria-expanded', 'true');
            var first = sheet.querySelector('a, button');
            if (first) {
                first.focus();
            }
        };
        var close = function () {
            sheet.hidden = true;
            toggle.setAttribute('aria-expanded', 'false');
            toggle.focus();
        };
        toggle.addEventListener('click', open);
        sheet.addEventListener('click', function (event) {
            if (event.target === sheet || event.target.closest('[data-more-close]')) {
                close();
            }
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !sheet.hidden) {
                close();
            }
        });
    }

    function initPrint() {
        $all('[data-print]').forEach(function (button) {
            button.addEventListener('click', function () { window.print(); });
        });
    }

    function initDirtyForms() {
        $all('[data-dirty-form]').forEach(function (form) {
            var dirty = false;
            form.addEventListener('input', function () { dirty = true; });
            form.addEventListener('submit', function () { dirty = false; });
            window.addEventListener('beforeunload', function (event) {
                if (dirty) {
                    event.preventDefault();
                    event.returnValue = '';
                }
            });
        });
    }

    function cleanUrl() {
        if (!window.history || !window.history.replaceState) {
            return;
        }
        var url = new URL(window.location.href);
        if (url.searchParams.has('notice')) {
            url.searchParams.delete('notice');
            window.history.replaceState(null, '', url.toString());
        }
    }

    /* ----------------------------------- Session + live auto-refresh */

    function initApp() {
        var app = $('[data-app]');
        if (!app) {
            return;
        }

        var idle = (parseInt(app.getAttribute('data-idle'), 10) || 1800) * 1000;
        var expiredUrl = app.getAttribute('data-expired-url');
        var liveUrl = app.getAttribute('data-live-url');
        var page = app.getAttribute('data-page');
        var lastTouch = Date.now();
        var lastInteraction = Date.now();
        var dialog = $('[data-session-dialog]');
        var countdown = $('[data-session-countdown]');
        var warnTimer = null;

        function expire() {
            window.location.href = expiredUrl;
        }

        function request(active) {
            var url = liveUrl + (liveUrl.indexOf('?') === -1 ? '?' : '&') + (active ? 'active=1' : 'active=0');
            return fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' })
                .then(function (response) {
                    if (response.status === 401) {
                        expire();
                        throw new Error('expired');
                    }
                    if (!response.ok) {
                        throw new Error('http');
                    }
                    if (active) {
                        lastTouch = Date.now();
                    }
                    return response.json();
                });
        }

        function renderLive(data) {
            $all('[data-live-count]').forEach(function (node) { text(node, String(data.active_count)); });
            $all('[data-live-stamp]').forEach(function (node) { text(node, 'aktualisiert ' + data.stamp); });
            var badge = $('[data-nav-new]');
            if (badge) {
                text(badge, String(data.new_appointments));
                badge.hidden = !data.new_appointments;
            }
            $all('[data-live-list]').forEach(function (list) {
                var limit = list.classList.contains('live-chips--stack') ? 50 : 3;
                list.textContent = '';
                if (!data.active.length) {
                    var empty = document.createElement('li');
                    empty.className = 'live-chips__empty';
                    empty.textContent = 'Gerade keine aktiven Gespräche.';
                    list.appendChild(empty);
                    return;
                }
                data.active.slice(0, limit).forEach(function (item) {
                    var li = document.createElement('li');
                    var a = document.createElement('a');
                    var dot = document.createElement('span');
                    dot.className = 'dot';
                    dot.setAttribute('aria-hidden', 'true');
                    a.href = item.url;
                    a.appendChild(dot);
                    a.appendChild(document.createTextNode(item.text));
                    li.appendChild(a);
                    list.appendChild(li);
                });
            });
            $all('[data-live-events]').forEach(function (list) {
                if (!data.events.length) {
                    return;
                }
                var template = list.querySelector('.event-list__icon');
                var iconHtml = template ? template.innerHTML : '';
                list.textContent = '';
                data.events.forEach(function (event) {
                    var li = document.createElement('li');
                    var a = document.createElement('a');
                    var icon = document.createElement('span');
                    var body = document.createElement('span');
                    var title = document.createElement('b');
                    var small = document.createElement('small');
                    icon.className = 'event-list__icon';
                    icon.innerHTML = iconHtml; // static SVG copied from server markup
                    title.textContent = event.title;
                    small.textContent = event.text;
                    body.appendChild(title);
                    body.appendChild(small);
                    a.href = event.url;
                    a.appendChild(icon);
                    a.appendChild(body);
                    li.appendChild(a);
                    list.appendChild(li);
                });
            });
        }

        // Live refresh only on pages that show live data.
        if (page === 'overview' || page === 'live') {
            window.setInterval(function () {
                if (document.hidden) {
                    return;
                }
                var active = Date.now() - lastInteraction < 60000;
                request(active).then(renderLive).catch(function () {});
            }, 15000);
        }

        function scheduleWarning() {
            window.clearTimeout(warnTimer);
            var warnAt = Math.max(5000, idle - (Date.now() - lastTouch) - 120000);
            warnTimer = window.setTimeout(showWarning, warnAt);
        }

        function showWarning() {
            var remaining = idle - (Date.now() - lastTouch);
            if (remaining > 125000) {
                scheduleWarning();
                return;
            }
            if (remaining <= 0) {
                expire();
                return;
            }
            dialog.hidden = false;
            var button = $('[data-session-extend]');
            if (button) {
                button.focus();
            }
            var tick = function () {
                if (dialog.hidden) {
                    return;
                }
                var left = Math.round((idle - (Date.now() - lastTouch)) / 1000);
                if (left <= 0) {
                    expire();
                    return;
                }
                text(countdown, 'Abmeldung in ' + left + ' s.');
                window.setTimeout(tick, 1000);
            };
            tick();
        }

        if (dialog) {
            $('[data-session-extend]').addEventListener('click', function () {
                request(true).then(function (data) {
                    dialog.hidden = true;
                    renderLive(data);
                    scheduleWarning();
                }).catch(function () {});
            });
            scheduleWarning();
        }

        ['pointerdown', 'keydown', 'scroll', 'touchstart'].forEach(function (type) {
            window.addEventListener(type, function () {
                lastInteraction = Date.now();
                // Keep an active user signed in on pages without polling.
                if (dialog && dialog.hidden && Date.now() - lastTouch > 300000) {
                    request(true).then(function () { scheduleWarning(); }).catch(function () {});
                }
            }, { passive: true });
        });
    }

    /* ----------------------------------------- Decorative dot spheres */

    function fibonacci(count, radius) {
        var points = [];
        var golden = Math.PI * (3 - Math.sqrt(5));
        for (var i = 0; i < count; i++) {
            var y = 1 - (i / (count - 1)) * 2;
            var r = Math.sqrt(1 - y * y);
            var theta = golden * i;
            points.push([Math.cos(theta) * r * radius, y * radius, Math.sin(theta) * r * radius]);
        }
        return points;
    }

    function sphereScene(canvas, options) {
        var ctx = canvas.getContext('2d');
        if (!ctx) {
            return;
        }
        var dpr = Math.min(window.devicePixelRatio || 1, 2);
        var points = fibonacci(options.count, 1);
        var highlights = options.highlights || [];
        var visible = true;
        var t = 0;
        var last = performance.now();

        function resize() {
            var rect = canvas.getBoundingClientRect();
            canvas.width = Math.max(1, Math.round(rect.width * dpr));
            canvas.height = Math.max(1, Math.round(rect.height * dpr));
        }

        function draw() {
            var w = canvas.width;
            var h = canvas.height;
            var radius = Math.min(w, h) * options.scale;
            var cx = w * options.cx;
            var cy = h * options.cy;
            var cosY = Math.cos(t * options.speed);
            var sinY = Math.sin(t * options.speed);
            var tilt = options.tilt;
            ctx.clearRect(0, 0, w, h);

            if (options.ring) {
                ctx.strokeStyle = 'rgba(54, 69, 79, 0.18)';
                ctx.lineWidth = 1 * dpr;
                ctx.beginPath();
                ctx.ellipse(cx, cy, radius * 1.45, radius * 0.38, -0.25 + Math.sin(t * 0.2) * 0.05, 0, Math.PI * 2);
                ctx.stroke();
            }

            for (var i = 0; i < points.length; i++) {
                var p = points[i];
                var x = p[0] * cosY - p[2] * sinY;
                var z = p[0] * sinY + p[2] * cosY;
                var y = p[1] * Math.cos(tilt) - z * Math.sin(tilt);
                z = p[1] * Math.sin(tilt) + z * Math.cos(tilt);
                var depth = (z + 1) / 2;
                var isHighlight = highlights.indexOf(i) !== -1;
                var size = (isHighlight ? 3.2 + Math.sin(t * 2.4) * 0.8 : 1.1 + depth * 1.1) * dpr;
                ctx.globalAlpha = isHighlight ? 0.55 + depth * 0.45 : 0.12 + depth * 0.55;
                ctx.fillStyle = isHighlight ? '#028D86' : options.color;
                ctx.beginPath();
                ctx.arc(cx + x * radius, cy + y * radius, size, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.globalAlpha = 1;
        }

        function loop(now) {
            var dt = Math.min(0.05, (now - last) / 1000);
            last = now;
            if (visible && !document.hidden) {
                t += dt;
                draw();
            }
            window.requestAnimationFrame(loop);
        }

        resize();
        if ('ResizeObserver' in window) {
            new ResizeObserver(function () { resize(); draw(); }).observe(canvas);
        }
        if ('IntersectionObserver' in window) {
            new IntersectionObserver(function (entries) { visible = entries[0].isIntersecting; }).observe(canvas);
        }
        draw();
        if (!reduceMotion) {
            window.requestAnimationFrame(loop);
        }
    }

    function initScenes() {
        $all('[data-crystal]').forEach(function (canvas) {
            sphereScene(canvas, { count: 900, scale: 0.3, cx: 0.55, cy: 0.48, speed: 0.22, tilt: 0.35, color: '#36454F', ring: true });
        });
        $all('[data-globe]').forEach(function (canvas) {
            sphereScene(canvas, { count: 650, scale: 0.42, cx: 0.78, cy: 0.62, speed: 0.15, tilt: 0.3, color: '#36454F', highlights: [40, 210, 377, 520] });
        });
    }

    function init() {
        initPasswordToggle();
        initBusyButtons();
        initOtp();
        initQr();
        initCopy();
        initCountdown();
        initMoreSheet();
        initPrint();
        initDirtyForms();
        initApp();
        initScenes();
        cleanUrl();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
