/**
 * Madex AI Chatbot - Admin JavaScript
 */

(function($) {
    'use strict';

    /**
     * Initialize admin functionality
     */
    function init() {
        bindEvents();
    }

    /**
     * Bind event handlers
     */
    function bindEvents() {
        // Toggle password visibility
        $('.madex-toggle-visibility').on('click', toggleVisibility);

        // Insert directive templates
        $('.madex-insert-directive').on('click', insertDirective);

        // View knowledge base item
        $('.madex-view-kb').on('click', viewKnowledgeItem);

        // Close modal
        $('.madex-modal-close').on('click', closeModal);
        $('.madex-modal').on('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // Test API connection
        $('#madex-test-api, #madex-test-connection').on('click', testApiConnection);

        // Close modal on escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    }

    /**
     * Toggle password field visibility
     */
    function toggleVisibility() {
        const targetId = $(this).data('target');
        const $input = $('#' + targetId);
        const $icon = $(this).find('.dashicons');

        if ($input.attr('type') === 'password') {
            $input.attr('type', 'text');
            $icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
        } else {
            $input.attr('type', 'password');
            $icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
        }
    }

    /**
     * Insert directive template
     */
    function insertDirective() {
        const directiveType = $(this).data('directive');
        let directive = '';

        switch (directiveType) {
            case 'customer_support':
                directive = `You are a helpful customer support assistant for our company. Your role is to assist customers with their questions and concerns.

GUIDELINES:
- Be professional, friendly, and empathetic
- Keep responses concise (2-3 sentences unless more detail is needed)
- If you don't know something, admit it and offer to connect them with a human agent
- Never share sensitive customer data or make promises about refunds/changes you can't verify
- Always thank the customer for their patience

CAPABILITIES:
- Answer questions about products and services
- Explain policies and procedures
- Help troubleshoot common issues
- Provide general information

LIMITATIONS:
- Cannot process orders, payments, or refunds
- Cannot access or modify customer account data
- Cannot make commitments on behalf of the company`;
                break;

            case 'sales':
                directive = `You are a knowledgeable sales assistant for our company. Your goal is to help potential customers understand our products and guide them toward the right solutions.

GUIDELINES:
- Be enthusiastic but not pushy
- Focus on understanding customer needs first
- Highlight benefits, not just features
- Be honest about limitations
- Offer to schedule calls with sales team for complex inquiries

CAPABILITIES:
- Explain product features and benefits
- Compare product options
- Discuss pricing tiers (if public)
- Answer pre-sales questions

LIMITATIONS:
- Cannot negotiate custom pricing
- Cannot process transactions
- Cannot guarantee specific delivery dates`;
                break;

            case 'technical':
                directive = `You are a technical support specialist for our company. Your role is to help users troubleshoot issues and get the most out of our products.

GUIDELINES:
- Be patient and clear in explanations
- Use simple language, avoid jargon when possible
- Provide step-by-step instructions when needed
- Ask clarifying questions to understand the issue
- Document solutions that might help other users

CAPABILITIES:
- Troubleshoot common technical issues
- Explain how features work
- Guide users through setup and configuration
- Suggest best practices and tips

LIMITATIONS:
- Cannot access user systems remotely
- Cannot perform administrative actions
- Escalate complex issues to human support when needed`;
                break;
        }

        if (directive) {
            $('#system_prompt').val(directive);
            // Scroll to the textarea
            $('html, body').animate({
                scrollTop: $('#system_prompt').offset().top - 100
            }, 300);
        }
    }

    /**
     * View knowledge base item in modal
     */
    function viewKnowledgeItem() {
        const name = $(this).data('name');
        const content = $(this).data('content');

        $('#madex-kb-modal-title').text(name);
        $('#madex-kb-modal-content').text(content);
        $('#madex-kb-modal').show();
    }

    /**
     * Close modal
     */
    function closeModal() {
        $('.madex-modal').hide();
    }

    /**
     * Test API connection
     */
    function testApiConnection() {
        const $button = $(this);
        const $result = $('#madex-api-test-result, #madex-test-result');
        const label = $button.text();

        $button.prop('disabled', true).text('Wird getestet …');
        $result.removeClass('is-ok is-error').text('');

        $.ajax({
            url: madexChatbotAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'madex_test_api',
                nonce: madexChatbotAdmin.nonce
            }
        }).done(function(response) {
            if (response && response.success) {
                $result.addClass('is-ok').text('✓ Verbindung funktioniert.');
            } else {
                $result.addClass('is-error').text('✕ ' + (response && response.data && response.data.message ? response.data.message : 'Test fehlgeschlagen.'));
            }
        }).fail(function(xhr) {
            const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
            $result.addClass('is-error').text('✕ ' + (message || 'Verbindung fehlgeschlagen.'));
        }).always(function() {
            $button.prop('disabled', false).text(label);
        });
    }

    /**
     * Initialize Data Sources drag & drop
     */
    function initDataSources() {
        if (!$('.madex-datasources-list').length) {
            return;
        }

        // Click to move items between lists
        $('.madex-datasources-list').on('click', '.madex-datasource-item', function() {
            const $item = $(this);
            const $currentList = $item.closest('.madex-datasources-list');
            const currentStatus = $currentList.data('status');
            
            // Determine target list
            let $targetList;
            if (currentStatus === 'disabled') {
                $targetList = $('#madex-enabled-sources');
            } else {
                $targetList = $('#madex-disabled-sources');
            }
            
            // Animate and move
            $item.fadeOut(150, function() {
                $item.appendTo($targetList).fadeIn(150);
                updateDataSourcesInput();
            });
        });

        // Initialize the hidden input value on load
        updateDataSourcesInput();
    }

    /**
     * Update the hidden input with enabled data sources
     */
    function updateDataSourcesInput() {
        const $enabledList = $('#madex-enabled-sources');
        const $hiddenInput = $('#madex-data-sources-input');

        if (!$enabledList.length || !$hiddenInput.length) {
            return;
        }

        const enabledSources = [];
        $enabledList.find('.madex-datasource-item').each(function() {
            enabledSources.push($(this).data('source'));
        });

        $hiddenInput.val(JSON.stringify(enabledSources));
    }

    // Initialize when DOM is ready
    $(document).ready(function() {
        init();
        initDataSources();
    });

})(jQuery);
