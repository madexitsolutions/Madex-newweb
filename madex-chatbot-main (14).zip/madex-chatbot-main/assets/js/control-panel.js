/**
 * Madex control panel (WordPress Admin): rule builder, package preview,
 * media picker, unsaved-change indicator and confirmations.
 */
(function () {
    'use strict';

    function $all(selector, root) {
        return Array.prototype.slice.call((root || document).querySelectorAll(selector));
    }

    /* ------------------------------------------------- Rule builder */

    function syncRule(row) {
        var field = row.querySelector('[data-mc-rule-field]').value;
        var operator = row.querySelector('[data-mc-rule-operator]');

        $all('[data-mc-rule-value] [data-for]', row).forEach(function (control) {
            var active = control.getAttribute('data-for') === field;
            control.hidden = !active;
            control.disabled = !active;
        });

        $all('option', operator).forEach(function (option) {
            var allowed = (option.getAttribute('data-for') || '').split(' ').indexOf(field) !== -1;
            option.hidden = !allowed;
            option.disabled = !allowed;
        });
        if (operator.selectedOptions[0] && operator.selectedOptions[0].disabled) {
            operator.value = field === 'company_size' ? 'lte' : 'equals';
        }
    }

    function syncLabels(builder) {
        var relation = builder.querySelector('select[name="relation"]');
        var word = relation && relation.value === 'or' ? 'ODER' : 'UND';
        var rows = $all('[data-mc-rule]', builder.querySelector('[data-mc-rule-list]'));
        rows.forEach(function (row, index) {
            row.querySelector('[data-mc-rule-op]').textContent = index === 0 ? 'WENN' : word;
        });
        var empty = builder.querySelector('[data-mc-rule-empty]');
        if (empty) {
            empty.hidden = rows.length > 0;
        }
    }

    function initRules() {
        $all('[data-mc-rules]').forEach(function (builder) {
            var list = builder.querySelector('[data-mc-rule-list]');
            var template = builder.querySelector('[data-mc-rule-template]');
            var counter = $all('[data-mc-rule]', list).length + 1;

            $all('[data-mc-rule]', list).forEach(syncRule);
            syncLabels(builder);

            builder.addEventListener('change', function (event) {
                if (event.target.matches('[data-mc-rule-field]')) {
                    syncRule(event.target.closest('[data-mc-rule]'));
                }
                if (event.target.matches('select[name="relation"]')) {
                    syncLabels(builder);
                }
            });

            builder.addEventListener('click', function (event) {
                var remove = event.target.closest('[data-mc-remove-rule]');
                if (remove) {
                    remove.closest('[data-mc-rule]').remove();
                    syncLabels(builder);
                    markDirty(builder.closest('form'));
                    return;
                }
                if (event.target.closest('[data-mc-add-rule]') && template) {
                    var html = template.innerHTML.replace(/__INDEX__/g, 'n' + (counter++));
                    var holder = document.createElement('div');
                    holder.innerHTML = html.trim();
                    var row = holder.firstElementChild;
                    list.appendChild(row);
                    syncRule(row);
                    syncLabels(builder);
                    markDirty(builder.closest('form'));
                    row.querySelector('[data-mc-rule-field]').focus();
                }
            });
        });
    }

    /* --------------------------------------------- Package preview */

    function initPreview() {
        var form = document.querySelector('[data-mc-package-form]');
        if (!form) {
            return;
        }
        var targets = {};
        $all('[data-preview-target]', form).forEach(function (node) {
            targets[node.getAttribute('data-preview-target')] = node;
        });

        function update(input) {
            var key = input.getAttribute('data-preview');
            var target = targets[key];
            if (!target) {
                return;
            }
            if (key === 'features') {
                target.textContent = '';
                input.value.split(/\r?\n/).map(function (line) { return line.trim(); }).filter(Boolean).slice(0, 8).forEach(function (line) {
                    var li = document.createElement('li');
                    li.textContent = line;
                    target.appendChild(li);
                });
                return;
            }
            target.textContent = input.value.trim() || (key === 'name' ? 'Paketname' : '');
        }

        $all('[data-preview]', form).forEach(function (input) {
            input.addEventListener('input', function () { update(input); });
        });
    }

    /* ------------------------------------------------- Media picker */

    function initMedia() {
        $all('[data-mc-media]').forEach(function (button) {
            button.addEventListener('click', function () {
                if (!window.wp || !window.wp.media) {
                    return;
                }
                var input = button.parentNode.querySelector('[data-mc-media-input]');
                var frame = window.wp.media({ title: 'Bild auswählen', button: { text: 'Übernehmen' }, multiple: false, library: { type: 'image' } });
                frame.on('select', function () {
                    var attachment = frame.state().get('selection').first().toJSON();
                    input.value = attachment.url;
                    markDirty(input.form);
                });
                frame.open();
            });
        });
    }

    /* ------------------------------------- Unsaved changes + confirm */

    var dirtyForms = [];

    function markDirty(form) {
        if (!form || !form.hasAttribute('data-mc-dirty')) {
            return;
        }
        if (dirtyForms.indexOf(form) === -1) {
            dirtyForms.push(form);
        }
        var indicator = document.querySelector('[data-mc-dirty-indicator]');
        if (indicator) {
            indicator.hidden = false;
        }
    }

    function initDirty() {
        $all('form[data-mc-dirty]').forEach(function (form) {
            form.addEventListener('input', function () { markDirty(form); });
            form.addEventListener('change', function () { markDirty(form); });
            form.addEventListener('submit', function () {
                dirtyForms = dirtyForms.filter(function (item) { return item !== form; });
            });
        });
        // External submit buttons (form="...") also clear the state.
        $all('button[form]').forEach(function (button) {
            button.addEventListener('click', function () {
                var form = document.getElementById(button.getAttribute('form'));
                dirtyForms = dirtyForms.filter(function (item) { return item !== form; });
            });
        });
        window.addEventListener('beforeunload', function (event) {
            if (dirtyForms.length) {
                event.preventDefault();
                event.returnValue = '';
            }
        });
    }

    function initConfirm() {
        $all('form[data-mc-confirm]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!window.confirm(form.getAttribute('data-mc-confirm'))) {
                    event.preventDefault();
                }
            });
        });
    }

    /* ----------------------------------------------- Settings page */

    function initSettings() {
        $all('[data-mc-reveal]').forEach(function (button) {
            var input = document.getElementById(button.getAttribute('data-mc-reveal'));
            button.addEventListener('click', function () {
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                button.textContent = show ? 'Verbergen' : 'Anzeigen';
                button.setAttribute('aria-pressed', show ? 'true' : 'false');
            });
        });

        var teaser = document.querySelector('[data-mc-teaser-input]');
        var preview = document.querySelector('[data-mc-teaser-preview]');
        if (teaser && preview) {
            teaser.addEventListener('input', function () {
                preview.textContent = teaser.value.trim();
            });
        }
    }

    function init() {
        initSettings();
        initRules();
        initPreview();
        initMedia();
        initDirty();
        initConfirm();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
