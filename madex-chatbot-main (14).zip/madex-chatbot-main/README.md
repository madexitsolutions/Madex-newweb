# Madex AI Chatbot - WordPress Plugin

A powerful AI chatbot plugin for WordPress powered by OpenAI. Features an admin panel for configuring the chatbot directive and managing a knowledge base.

**Author:** Madex IT Solutions - Emir Gjerqeku  
**Website:** [https://madex-it.ch/](https://madex-it.ch/)

## Requirements

- WordPress 6.0 or higher
- PHP 7.4 or higher
- OpenAI API key

## Features

- **AI-Powered Conversations**: Uses OpenAI's GPT models for intelligent responses
- **Customizable Directive**: Set up your chatbot's personality, tone, and behavior
- **Knowledge Base Management**: Add documents, FAQs, and product info that the AI will reference
- **Session Management**: View and manage chat conversations
- **Customizable Branding**: Set chat title, welcome message, and colors
- **Responsive Design**: Works on desktop and mobile devices
- **Embedded or Floating Widget**: Use as a floating button or embed with shortcode
- **Security & Rate Limiting**: Protect against spam and API abuse with configurable limits

## Installation

1. Upload the `madex-chatbot` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **Madex Chatbot** in the admin menu
4. Configure your settings

## Configuration

### General Settings
- Enable/disable the chatbot on your site

### AI Configuration
1. Get an API key from [OpenAI](https://platform.openai.com/api-keys)
2. Enter your API key in the AI Configuration tab
3. Select your preferred model (GPT-4o-mini recommended for cost-efficiency)
4. Set up your **System Prompt (Directive)** - this tells the AI how to behave

### Chatbot Directive (System Prompt)
The directive is crucial for your chatbot's behavior. Include:
- Your company name and what you do
- The tone and personality (professional, friendly, casual)
- What the bot can and cannot do
- Any specific instructions or rules

Example:
```
You are a helpful assistant for ABC Company. Be professional but friendly.

You can:
- Answer questions about our products
- Explain our services
- Provide general support

You cannot:
- Process orders or payments
- Make commitments about pricing
- Access customer account data

Always be helpful and if you don't know something, offer to connect them with a human.
```

### Knowledge Base
Add information that the AI should know about:
1. Go to **Madex Chatbot > Knowledge Base**
2. Click "Add Knowledge Item"
3. Enter a name, select a type (FAQ, Product, Policy, etc.)
4. Add the content
5. Click "Add Knowledge Item"

The AI will automatically reference this information when answering related questions.

### Branding
- **Chat Title**: The name shown in the chat header
- **Welcome Message**: First message shown when the chat opens
- **Primary Color**: Main color theme for the widget

### Security Settings
The Security tab provides protection against spam and excessive API usage:

#### Rate Limiting
- **Messages per Minute**: Maximum messages a user can send per minute (default: 5)
- **Messages per Day**: Daily message limit per user (default: 50, set to 0 for unlimited)
- **New Sessions per Hour**: Maximum new chat sessions a user can start per hour (default: 3)
- **Cooldown**: Minimum seconds between messages (default: 2 seconds)

#### Message Validation
- **Minimum/Maximum Length**: Control message size limits
- **Block Spam Messages**: Automatic detection and blocking of spam-like content including:
  - Excessive URLs
  - All-caps messages
  - Repetitive content
  - Known spam patterns

#### IP Blocking
- Block specific IP addresses or CIDR ranges
- View security statistics (blocked attempts, rate-limited requests)

#### How Rate Limiting Works
- For logged-in users: Based on user ID
- For guests: Based on the connecting IP (`REMOTE_ADDR`). Behind Cloudflare or another trusted proxy, opt in with `add_filter('madex_chatbot_trust_proxy_headers', '__return_true');`
- Uses WordPress transients for efficient, non-database rate limiting
- All limits are configurable through the admin panel

## Usage

### Floating Widget
The chatbot automatically appears as a floating button in the bottom-right corner of your site (when enabled).

### Shortcode
To embed the chatbot directly in a page or post:
```
[madex_chatbot]
```

### Viewing Conversations
Go to **Madex Chatbot > Chat Sessions** to view past conversations.

### Packages and appointment requests
- **Madex Chatbot > Pakete & Regeln**: service packages (never with prices) and visual display rules
  (customer status, interest, company size). Rules and internal notes never reach visitors or the AI.
- **Madex Chatbot > Terminanfragen**: every appointment request is stored first, then emailed to the
  recipients set under *Portal & 2FA*. Failed emails stay visible and can be re-sent.

### Management portal (`/chatadm`)
A separate, branded dashboard for management (chats, appointment requests, reports, live activity).
It never shows API keys, prompts, models, costs or WordPress settings.

1. The site must run on **HTTPS** (the portal refuses plain HTTP).
2. Create a WordPress user (e.g. role *Madex Dashboard Viewer*) and enable it under
   **Madex Chatbot > Portal & 2FA > Benutzer & Rechte**.
3. The user opens `https://your-domain/chatadm`, signs in with the WordPress username/email and password,
   then scans the QR code with Google Authenticator (or any TOTP app) and saves the 8 recovery codes.
   Later logins only ask for the 6-digit code.

Security: separate HttpOnly/Secure/SameSite=Strict sessions (no WordPress login cookie), progressive lockout
(5 failures → 1 min, 10 → 15 min, 20 → 60 min per account and network), generic error messages, strict CSP,
`noindex`, no WordPress paths or admin bar. Path, idle timeout and chat retention are configurable;
2FA can be reset and sessions revoked per user. Recommended server hardening: hide the `Server` header.

## Database Tables

- `wp_madex_chat_sessions` / `wp_madex_chat_messages` - Conversations (token-protected public sessions)
- `wp_madex_knowledge_base` - Knowledge base items
- `wp_madex_security_log` - Chat security events (blocked attempts, rate limiting)
- `wp_madex_packages` - Service packages and display rules
- `wp_madex_appointments` / `wp_madex_appointment_events` - Appointment requests and their history
- `wp_madex_portal_security` / `wp_madex_portal_sessions` / `wp_madex_portal_auth_limits` / `wp_madex_portal_audit` - Portal 2FA, sessions, lockouts and audit log

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- OpenAI API key

## Frequently Asked Questions

**Q: How much does OpenAI cost?**
A: OpenAI charges based on usage. GPT-4o-mini is the most cost-effective option at about $0.15 per million input tokens. For a typical chatbot, this works out to a few cents per conversation.

**Q: Can I use a different AI provider?**
A: Currently, only OpenAI is supported. Support for other providers may be added in future versions.

**Q: How do I make the chatbot appear only on certain pages?**
A: You can use WordPress conditional logic by adding custom code, or disable the floating widget and use the shortcode only where needed.

## Support

For issues or feature requests, please contact the development team.

## Version History

### 1.5.7
- Orion introduces itself as the AI assistant of Madex IT Solutions in the greeting bubble, the start view ("Hallo, ich bin Orion") and the first message; texts still on the old defaults are updated.
- The settings preview uses the same stars and launcher icon as the live widget.

### 1.5.6
- The assistant is named Orion, the AI assistant of Madex IT Solutions (directive and company profile); "who are you" is answered directly.

### 1.5.5
- Plugin e-mails are sent from "Madex IT Solutions <info@madex-it.ch>" (Einstellungen → Allgemein → Direkter Kontakt), only for the plugin's own mails.
- Branded HTML template for the appointment notification with a details table, an "Im Portal öffnen" button and a plain-text alternative; replies go to the customer.

### 1.5.4
- Buttons under each answer depend on the question: when the assistant cannot help or a person is needed (request status, call back, problems, invoices, contracts), call and e-mail buttons are shown.
- Request references (MDX-…) are looked up: the visitor sees whether the request arrived and its state, without personal data.
- Answers follow the language of the visitor's last message.

### 1.5.3
- Phones: zoom is locked while the chat is open (viewport maximum-scale=1 plus pinch blocking for iOS); the site's viewport tag is restored when the chat closes.

### 1.5.2
- Phones: no auto-zoom when typing (16px fields), the page behind the chat no longer scrolls, and the chat shrinks to fit above the on-screen keyboard.

### 1.5.1
- Brand colour is #028D86 in the widget, settings and portal (hover #017A74).
- Launcher icon is white on every site (fill set on the icon itself) and asset URLs carry the file time, so cached old styles no longer apply after an update.

### 1.5.0
- Launcher shows a chat bubble (60px, no shadow) with a clean unread badge; the assistant is marked with an AI sparkle instead of the logo.
- New default greeting bubble: "Fragen? Lassen Sie sich jetzt schnell und einfach über unseren Chat beraten!" (the old default is migrated).
- Softer assistant tone: appointments are only offered when the visitor asks for them, an offer or a price.
- "Passendes Paket finden" and "Kostenlose Analyse anfragen" reappear whenever the visitor talks about websites, SEO, Google, social media, services or prices.
- Back button in the chat header; earlier conversations are listed on the start view (stored in the browser) and can be continued, or a new one started.
- The chat stays in the conversation when the visitor moves to another page.
- Links in answers are shown as buttons; `[[seite:key]]` markers jump to website areas (packages scroll to "Unsere meistgebuchten Marketing-Pakete"). Areas can be changed with the `madex_chatbot_page_sections` filter.
- The assistant's role and rules follow the Madex directive: price questions get the exact monthly price (Website-Wartung CHF 250, Basic CHF 500, Premium CHF 750), no automatic referral to a free consultation, 2–5 sentences. The company profile carries the full package descriptions and model answers to typical questions (editable under KI & Wissen).
- The chat greeting no longer uses the account's first name.

### 1.4.0
- Settings fixed and rebuilt: the API key is saved reliably (it was previously discarded by a second sanitize pass), errors are shown instead of a false "saved" message, and a connection test explains failures (invalid key, no credit, model unavailable, server blocked)
- New German settings screen in the control-panel design: Allgemein, KI & Wissen, Begrüssung, Datenquellen, Sicherheit; Wissensdatenbank and Chatverläufe redesigned to match
- The assistant knows Madex: a built-in company profile from madex-it.ch (services, packages, conditions, team, contact, free analysis), editable under KI & Wissen
- New system prompt: advises like a consultant, asks one clarifying question when needed, recommends a package with a reason, and offers next steps as buttons (package finder, appointment, free analysis, direct contact)
- Package finder asks for goals (multi-select), existing website and company size, ranks packages by fit and says what each covers; Madex's packages (Website-Wartung, Basic, Premium) are added when the package list is empty
- Service list matches Madex's real offer (Website, Betreuung & Hosting, SEO, Google Ads, Social Media, Foto & Video, Grafikdesign, kostenlose Analyse)
- Proactive greeting bubble beside the launcher with a "1" badge, once per visit, configurable text, delay and mobile behaviour
- Larger chat window (412 × 700 px)
- Portal styles, script, fonts and logo load from the plugin's real files, so hosts that answer .css/.png requests themselves (nginx, LiteSpeed, CDN) no longer show an unstyled portal
- Greetings ("Hallo", "Hello", "Grüezi" …) get a friendly answer even without an AI connection, instead of the hand-off

### 1.3.3
- Escalation: when the assistant has no confirmed answer it offers Madex's phone lines and e-mail as tap-to-call and mailto links, next to the appointment request (defaults: 052 589 67 59, 076 507 33 32, info@madex-it.ch; branding `contact_phone` / `contact_email` override them)
- Chat composer shows focus through its border only, and the disclaimer under it was removed
- Smaller chat launcher; the header minimize button is an icon without a filled box
- Portal "Berichte": the hidden screen-reader table no longer stretches the page, so the page stops at its content and the sidebar stays in place

### 1.3.2
- Calmer, lighter neutral palette: canvas #FCFCFC instead of the warm #FAF9F5, softer lines and tints
- Corner radii reduced throughout the widget, portal and control panel
- Thinner focus rings, lighter shadows and no hover lift on buttons and cards
- Dashboard: slimmer bars with square ends, thinner chart lines and a thinner donut ring
- Chat launcher simplified to the mark on a solid teal circle, without the inner white disc

### 1.3.1
- Chat widget renders inside a Shadow DOM: theme, page builder and plugin CSS can no longer restyle it, and the widget no longer leaks styles into the site
- `chatbot.css` is loaded inside that shadow root instead of being enqueued into the page
- Full reset of inherited typography and browser defaults inside the widget
- Spacing rebuilt on the 4pt scale from the design system (header, welcome, messages, forms, package cards, success state)
- Status messages appear as a banner under the header instead of floating over the composer
- Stepper labels, review table and input disclaimer made legible at small panel widths

### 1.3.0
- Madex design system (Manrope, teal #028D86) for widget, control panel and portal
- Appointment requests with email notification, status workflow and CSV export
- Service packages with server-side conditional display rules (no prices)
- Separate `/chatadm` management portal with mandatory TOTP 2FA and recovery codes
- Grounded AI answers with human handoff when no confirmed information exists
- Token-protected chat sessions, authenticated encryption, proxy-header spoofing fix

### 1.0.0
- Initial release
- OpenAI integration
- Admin panel with directive and knowledge base management
- Floating chat widget
- Session management
