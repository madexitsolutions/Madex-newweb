<?php
/**
 * Plugin Name: Madex AI Chatbot
 * Plugin URI: https://madex-it.ch/
 * Description: Madex AI chatbot with grounded answers, service packages, appointment requests and a separate 2FA-protected management portal.
 * Version: 1.5.7
 * Author: Madex IT Solutions - Emir Gjerqeku
 * Author URI: https://madex-it.ch/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: madex-chatbot
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('MADEX_CHATBOT_VERSION', '1.5.7');
define('MADEX_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MADEX_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MADEX_CHATBOT_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Plugin Class
 */
class Madex_Chatbot {
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required files
     */
    private function load_dependencies() {
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-encryption.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-security-service.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-company-knowledge.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-openai-service.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-admin-settings.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-chat-widget.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-ajax-handler.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-totp.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-portal-auth.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-mailer.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-business-service.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-management-admin.php';
        require_once MADEX_CHATBOT_PLUGIN_DIR . 'includes/class-portal.php';
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Initialize components
        add_action('plugins_loaded', array($this, 'init_components'));
        
        // Register assets
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Cron job for cleaning up old guest sessions
        add_action('madex_chatbot_cleanup_guest_sessions', array($this, 'cleanup_guest_sessions'));
    }
    
    /**
     * Initialize plugin components
     */
    public function init_components() {
        // Run database upgrades if needed
        $this->maybe_upgrade_database();
        
        // Ensure cleanup cron is scheduled (for existing installations)
        if (!wp_next_scheduled('madex_chatbot_cleanup_guest_sessions')) {
            wp_schedule_event(time(), 'hourly', 'madex_chatbot_cleanup_guest_sessions');
        }
        
        // Initialize admin settings
        if (is_admin()) {
            Madex_Admin_Settings::get_instance();
            Madex_Management_Admin::get_instance();
        }

        // Standalone management portal (/chatadm by default)
        Madex_Portal::get_instance();
        
        // Initialize chat widget
        Madex_Chat_Widget::get_instance();
        
        // Initialize AJAX handler
        Madex_Ajax_Handler::get_instance();
    }
    
    /**
     * Check and run database upgrades if needed
     */
    private function maybe_upgrade_database() {
        $db_version = get_option('madex_chatbot_db_version', '1.0.0');
        
        // Upgrade to 1.1.0: Add user_email column to sessions
        if (version_compare($db_version, '1.1.0', '<')) {
            global $wpdb;
            $table_sessions = $wpdb->prefix . 'madex_chat_sessions';
            
            // Check if column exists
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_sessions LIKE 'user_email'");
            
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $table_sessions ADD COLUMN user_email varchar(255) DEFAULT '' AFTER user_name");
                $wpdb->query("ALTER TABLE $table_sessions ADD INDEX user_email (user_email)");
            }
            
            update_option('madex_chatbot_db_version', '1.1.0');
        }

        // Upgrade to 1.3.0: secure public sessions, packages, appointments, portal
        if (version_compare($db_version, '1.3.0', '<')) {
            $this->install_business_schema();
            update_option('madex_chatbot_db_version', '1.3.0');
        }

        // Upgrade to 1.4.0: Madex's published packages fill an empty package list.
        if (version_compare($db_version, '1.4.0', '<')) {
            Madex_Business_Service::seed_default_packages();
            // The old default directive forbade all prices and is now built in.
            $directive = get_option('madex_chatbot_directive', array());
            if (!empty($directive['system_prompt']) && strpos($directive['system_prompt'], 'Du bist der digitale Assistent von Madex IT Solutions (madex-it.ch). Antworte freundlich') === 0) {
                update_option('madex_chatbot_directive', array('system_prompt' => ''), false);
            }
            update_option('madex_chatbot_db_version', '1.4.0');
        }

        // Upgrade to 1.5.0: the old default teaser text gets the new one.
        if (version_compare($db_version, '1.5.0', '<')) {
            $branding = get_option('madex_chatbot_branding', array());
            if (is_array($branding) && isset($branding['teaser_message']) && strpos($branding['teaser_message'], 'Suchen Sie eine neue Website oder mehr Kunden') !== false) {
                $defaults = Madex_Admin_Settings::branding_defaults();
                $branding['teaser_message'] = $defaults['teaser_message'];
                update_option('madex_chatbot_branding', $branding);
            }
            update_option('madex_chatbot_db_version', '1.5.0');
        }

        // Upgrade to 1.5.7: the assistant introduces itself as Orion. Texts
        // still on an earlier default get the new one; own texts stay.
        if (version_compare($db_version, '1.5.7', '<')) {
            $branding = get_option('madex_chatbot_branding', array());
            if (is_array($branding)) {
                $defaults = Madex_Admin_Settings::branding_defaults();
                $old = array(
                    'chat_title' => array('Madex Assistent'),
                    'welcome_message' => array('Guten Tag! Wie kann ich Ihnen helfen?'),
                    'teaser_message' => array('Fragen? Lassen Sie sich jetzt schnell und einfach über unseren Chat beraten!'),
                );
                foreach ($old as $field => $values) {
                    if (isset($branding[$field]) && in_array(trim($branding[$field]), $values, true)) {
                        $branding[$field] = $defaults[$field];
                    }
                }
                update_option('madex_chatbot_branding', $branding);
            }
            update_option('madex_chatbot_db_version', '1.5.7');
        }
    }

    /**
     * Create/upgrade package, appointment and portal tables.
     */
    private function install_business_schema() {
        Madex_Business_Service::install_schema();
        Madex_Portal_Auth::install_schema();
    }
    
    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets() {
        // Only load if chatbot is enabled
        $settings = get_option('madex_chatbot_settings', array());
        if (empty($settings['enabled'])) {
            return;
        }
        
        // chatbot.css is not enqueued into the page: chatbot.js loads it inside
        // the widget's Shadow DOM so the theme cannot override it (and it
        // cannot leak into the theme either).
        wp_enqueue_script(
            'madex-chatbot-script',
            MADEX_CHATBOT_PLUGIN_URL . 'assets/js/chatbot.js',
            array('jquery'),
            MADEX_CHATBOT_VERSION . '.' . (int) @filemtime(MADEX_CHATBOT_PLUGIN_DIR . 'assets/js/chatbot.js'),
            true
        );
        
        // Pass data to JS
        $branding = wp_parse_args(get_option('madex_chatbot_branding', array()), Madex_Admin_Settings::branding_defaults());
        $current_user = wp_get_current_user();
        $privacy_url = get_privacy_policy_url();
        wp_localize_script('madex-chatbot-script', 'madexChatbot', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('madex_chatbot_nonce'),
            // The file time busts browser and CDN caches whenever the stylesheet changes.
            'stylesheetUrl' => add_query_arg('ver', MADEX_CHATBOT_VERSION . '.' . (int) @filemtime(MADEX_CHATBOT_PLUGIN_DIR . 'assets/css/chatbot.css'), MADEX_CHATBOT_PLUGIN_URL . 'assets/css/chatbot.css'),
            'fontsUrl' => MADEX_CHATBOT_PLUGIN_URL . 'assets/fonts/',
            'title' => !empty($branding['chat_title']) ? $branding['chat_title'] : 'Madex Assistent',
            'welcomeMessage' => !empty($branding['welcome_message']) ? $branding['welcome_message'] : 'Hallo, ich bin Orion, der KI-Assistent von Madex IT Solutions. Wie kann ich Ihnen helfen?',
            'privacyUrl' => $privacy_url ? $privacy_url : '',
            'contactEmail' => !empty($branding['contact_email']) ? $branding['contact_email'] : '',
            'contactPhone' => !empty($branding['contact_phone']) ? $branding['contact_phone'] : '',
            'contacts' => $this->escalation_contacts($branding),
            'services' => Madex_Business_Service::service_options(),
            'teaser' => $this->teaser_config($branding),
            'assistantName' => !empty($branding['chat_title']) ? (string) $branding['chat_title'] : 'Orion',
            'sections' => Madex_Admin_Settings::page_sections(),
            'userName' => is_user_logged_in() ? $current_user->display_name : '',
            'userEmail' => is_user_logged_in() ? $current_user->user_email : '',
            'isLoggedIn' => is_user_logged_in()
        ));
    }
    
    /**
     * Direct contact details offered when the assistant hands a visitor over
     * to the team. Branding settings win; Madex's own lines are the default.
     *
     * @param array $branding Branding option.
     * @return array{phones: string[], email: string}
     */
    private function escalation_contacts($branding) {
        $phones = array('052 589 67 59', '076 507 33 32');
        if (!empty($branding['contact_phone'])) {
            $phones = array_values(array_filter(array_map('trim', preg_split('/[\r\n,;]+/', (string) $branding['contact_phone']))));
        }

        $email = !empty($branding['contact_email']) ? sanitize_email($branding['contact_email']) : 'info@madex-it.ch';

        return array(
            'phones' => array_map('sanitize_text_field', $phones),
            'email' => $email,
        );
    }

    /**
     * Proactive greeting shown next to the launcher.
     *
     * @param array $branding Branding option merged with defaults.
     * @return array
     */
    private function teaser_config($branding) {
        return array(
            'enabled' => !empty($branding['teaser_enabled']),
            'message' => (string) $branding['teaser_message'],
            'delay' => max(0, min(120, (int) $branding['teaser_delay'])),
            'mobile' => !empty($branding['teaser_mobile']),
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        // Only load on our admin pages
        if (strpos($hook, 'madex-chatbot') === false) {
            return;
        }
        
        wp_enqueue_style(
            'madex-chatbot-admin-style',
            MADEX_CHATBOT_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            MADEX_CHATBOT_VERSION
        );
        
        wp_enqueue_script(
            'madex-chatbot-admin-script',
            MADEX_CHATBOT_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            MADEX_CHATBOT_VERSION,
            true
        );
        
        wp_enqueue_media();

        wp_enqueue_style(
            'madex-chatbot-control-panel',
            MADEX_CHATBOT_PLUGIN_URL . 'assets/css/control-panel.css',
            array('madex-chatbot-admin-style'),
            MADEX_CHATBOT_VERSION
        );

        wp_enqueue_script(
            'madex-chatbot-control-panel',
            MADEX_CHATBOT_PLUGIN_URL . 'assets/js/control-panel.js',
            array(),
            MADEX_CHATBOT_VERSION,
            true
        );

        wp_localize_script('madex-chatbot-admin-script', 'madexChatbotAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('madex_chatbot_admin_nonce')
        ));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create necessary database tables
        $this->create_tables();
        $this->install_business_schema();
        Madex_Business_Service::seed_default_packages();
        update_option('madex_chatbot_db_version', '1.5.7');
        
        // Set default options
        $this->set_default_options();
        
        // Schedule cleanup cron job (every hour)
        if (!wp_next_scheduled('madex_chatbot_cleanup_guest_sessions')) {
            wp_schedule_event(time(), 'hourly', 'madex_chatbot_cleanup_guest_sessions');
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Unschedule cleanup cron job
        wp_clear_scheduled_hook('madex_chatbot_cleanup_guest_sessions');
        
        flush_rewrite_rules();
    }
    
    /**
     * Hourly maintenance: purge conversations past the configured retention
     * period and expired portal sessions/lockouts.
     */
    public function cleanup_guest_sessions() {
        $portal_settings = get_option('madex_portal_settings', array());
        $retention_days = isset($portal_settings['retention_days']) ? (int) $portal_settings['retention_days'] : 90;
        Madex_Business_Service::purge_conversations(max(1, $retention_days));
        Madex_Portal_Auth::cleanup_expired();
    }

    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Chat sessions table
        $table_sessions = $wpdb->prefix . 'madex_chat_sessions';
        $sql_sessions = "CREATE TABLE IF NOT EXISTS $table_sessions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned DEFAULT NULL,
            user_name varchar(255) DEFAULT 'Guest',
            user_email varchar(255) DEFAULT '',
            status varchar(20) DEFAULT 'active',
            mode varchar(20) DEFAULT 'ai',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY user_email (user_email),
            KEY status (status)
        ) $charset_collate;";
        
        // Chat messages table
        $table_messages = $wpdb->prefix . 'madex_chat_messages';
        $sql_messages = "CREATE TABLE IF NOT EXISTS $table_messages (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id bigint(20) unsigned NOT NULL,
            content text NOT NULL,
            sender_type varchar(20) NOT NULL,
            sender_name varchar(255) DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Knowledge base table
        $table_knowledge = $wpdb->prefix . 'madex_knowledge_base';
        $sql_knowledge = "CREATE TABLE IF NOT EXISTS $table_knowledge (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            type varchar(50) DEFAULT 'other',
            content longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Security log table
        $table_security = $wpdb->prefix . 'madex_security_log';
        $sql_security = "CREATE TABLE IF NOT EXISTS $table_security (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_type varchar(50) NOT NULL,
            ip_address varchar(45) DEFAULT '',
            user_id bigint(20) unsigned DEFAULT NULL,
            data text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY event_type (event_type),
            KEY ip_address (ip_address),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_sessions);
        dbDelta($sql_messages);
        dbDelta($sql_knowledge);
        dbDelta($sql_security);
    }
    
    /**
     * Set default options
     */
    private function set_default_options() {
        $default_settings = array(
            'enabled' => true,
            'api_key' => '',
            'model' => 'gpt-4o-mini'
        );
        
        // Behaviour and company knowledge are built in (Madex_OpenAI_Service,
        // Madex_Company_Knowledge); the directive only holds the admin's extras.
        $default_directive = array(
            'system_prompt' => ''
        );
        
        $default_branding = Madex_Admin_Settings::branding_defaults();
        
        if (!get_option('madex_chatbot_settings')) {
            add_option('madex_chatbot_settings', $default_settings, '', 'no'); // No autoload for security
        }
        
        if (!get_option('madex_chatbot_directive')) {
            add_option('madex_chatbot_directive', $default_directive, '', 'no');
        }
        
        if (!get_option('madex_chatbot_branding')) {
            add_option('madex_chatbot_branding', $default_branding);
        }
        
        // Default security settings
        $default_security = array(
            'rate_limit_per_minute' => 10,        // Max messages per minute (prevents rapid spam)
            'guest_messages_per_day' => 100,      // Daily limit for guests (logged-in = unlimited)
            'message_cooldown' => 1,              // Seconds between messages
            'min_message_length' => 1,
            'max_message_length' => 1000,
            'block_spam' => true,
            'log_security_events' => true
        );
        
        if (!get_option('madex_chatbot_security')) {
            add_option('madex_chatbot_security', $default_security, '', 'no');
        }
        
        // Initialize blocked IPs option
        if (!get_option('madex_chatbot_blocked_ips')) {
            add_option('madex_chatbot_blocked_ips', array(), '', 'no');
        }
        
        // Initialize data sources with sensible defaults (products and pages enabled by default)
        if (!get_option('madex_chatbot_data_sources')) {
            add_option('madex_chatbot_data_sources', array(
                'woo_products',
                'woo_categories',
                'pages',
                'site_info'
            ), '', 'no');
        }
        
        // Migrate existing unencrypted API keys
        $this->maybe_encrypt_api_key();
    }
    
    /**
     * Encrypt existing API key if not already encrypted
     */
    private function maybe_encrypt_api_key() {
        $settings = get_option('madex_chatbot_settings', array());
        
        if (!empty($settings['api_key']) && class_exists('Madex_Encryption')) {
            // Check if the key is not already encrypted
            if (!Madex_Encryption::is_encrypted($settings['api_key'])) {
                // Encrypt the existing key
                $encrypted = Madex_Encryption::encrypt($settings['api_key']);
                if ($encrypted !== false) {
                    $settings['api_key'] = $encrypted;
                    update_option('madex_chatbot_settings', $settings);
                    error_log('Madex Chatbot: API key encrypted successfully');
                }
            }
        }
    }
}

// Initialize the plugin
Madex_Chatbot::get_instance();
